﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    Guard.cs
* File Desc   :    This file contains code pertaining to class for validating values.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 07-Jul-2021                                Initial Creation
*********************************************************************************************/

using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Constants;
using Collins.PLM.Common.ExceptionHandler.Exception;
using System;

namespace Collins.PLM.Common.ExceptionHandler.Utilities
{
    public static class Guard
    {
        /// <summary>
        /// Determines not allowing null value.
        /// </summary>
        /// <param name="value">Determines the specified object instances</param>
        /// <param name="parameterName">Determines name of the parameter</param>
        public static void GuardNull(this object value, string parameterName = "")
        {
            if (null == value)
            {
                throw new CollinsPLMException(MessageCode.ObjectNull, string.Format(parameterName));
            }
        }

        /// <summary>
        /// Determines not allowing NullEmpty values.
        /// </summary>
        /// <param name="value">Determines the specified object instances</param>
        /// <param name="parameterName">Determines name of the parameter</param>
        public static void GuardNullEmpty(this string value, string parameterName = "")
        {
            if (string.IsNullOrEmpty(value) || string.IsNullOrEmpty(value.Trim()))
            {
                throw new CollinsPLMException(MessageCode.StringNullEmpty, string.Format(parameterName));
            }
        }

        /// <summary>
        /// Rounds up.
        /// </summary>
        /// <param name="datetime">The DATETIME.</param>
        /// <param name="timespan">The timespan.</param>
        /// <returns>DateTime with rounding off to nearest time by the provided timespan</returns>
        public static DateTime RoundUp(DateTime datetime, TimeSpan timespan)
        {
            return new DateTime(((datetime.Ticks + timespan.Ticks - 1) / timespan.Ticks) * timespan.Ticks);
        }

        /// <summary>
        /// Determines not allowing any NonNegative values.
        /// </summary>
        /// <param name="value">Determines the specified object instances</param>
        /// <param name="parameterName">Determines name of the parameter</param>
        public static void GuardNonNegativeInt(this int value, string parameterName = "")
        {
            if (value < 0)
            {
                throw new CollinsPLMException(MessageCode.NonNegative, string.Format(CollinsPLMConstants.GenericGaurdMsg, parameterName));
            }
        }

    }
}
