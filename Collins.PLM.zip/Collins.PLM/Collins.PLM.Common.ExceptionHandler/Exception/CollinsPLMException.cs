﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    CollinsPLMException.cs
* File Desc   :    This file contains code pertaining to class for GOSPAException.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 07-Jul-2021                                Initial Creation
*********************************************************************************************/

using Collins.PLM.Common.Dto;

namespace Collins.PLM.Common.ExceptionHandler.Exception
{
    public class CollinsPLMException : System.Exception
    {
        public CollinsPLMException()
        {
            Result = new OperationResult();
        }

        public CollinsPLMException(MessageCode code, string message)
            : base(message)
        {
            Result = new OperationResult { Success = false, MCode = code, Message = message };
        }

        public OperationResult Result { get; set; }
    }
}
