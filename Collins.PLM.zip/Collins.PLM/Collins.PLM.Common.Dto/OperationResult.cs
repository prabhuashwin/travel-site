﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    OperationResult.cs
* File Desc   :    This file contains code pertaining to DTO for Operation Result class.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 07-Jul-2021                                Initial Creation
*********************************************************************************************/

namespace Collins.PLM.Common.Dto
{
    public class OperationResult
    {
        public bool Success { get; set; }
        public MessageCode MCode { get; set; }
        public string Message { get; set; }
        public object Data { get; set; }
    }
}
