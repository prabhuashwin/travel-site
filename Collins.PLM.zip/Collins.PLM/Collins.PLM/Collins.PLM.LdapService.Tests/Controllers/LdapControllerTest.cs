﻿using Collins.PLM.Common.Dto;
using Collins.PLM.LdapService.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System.Configuration;
using System.IO;
using System.Net;
using System.Web.Http;
using System.Web.Http.Results;
//using System.Web.Http;


namespace Collins.PLM.LdapService.Tests.Controllers
{
    [TestClass]
    public class LdapControllerTest
    {
        public string webAPIBase = ConfigurationManager.AppSettings["LdapApiUrl"];
        public string LdapUserId = ConfigurationManager.AppSettings["UserId"];
        public string LdapPassword = ConfigurationManager.AppSettings["LdapPassword"];

        public string wLdapUserId = ConfigurationManager.AppSettings["wUserId"];
        public string wLdapPassword = ConfigurationManager.AppSettings["wLdapPassword"];

        public string userName = ConfigurationManager.AppSettings["userName"];
        public string emailId = ConfigurationManager.AppSettings["emailId"];

        //LDAPLoginResult
        [TestMethod]
        public void GetDetailsFromLDAPWithValidLdapUserId()
        {
            //Arrange
            var ExpectedResult = new { userName = userName, emailId = emailId };           
            var expectedOutput = JsonConvert.SerializeObject(ExpectedResult);
            //string result2 = true;
            
            //Act
            var LdapController = new LdapController();
            IHttpActionResult result = LdapController.GetDeatilsFromLDAP(LdapUserId);
            var resultSearch = result as OkNegotiatedContentResult<string>;
            //var serializeResult = JsonConvert.SerializeObject(resultSearch.Content);         

            //Assert            
            Assert.AreEqual(resultSearch.Content, expectedOutput);
            Assert.IsNotNull(resultSearch.Content);
            Assert.IsNotNull(resultSearch.Content);         
        }
        [TestMethod]
        public void GetDetailsFromLDAPWithWrongLdapUserId()
        {
            //Arrange
            var ExpectedResult = new { userName = "", emailId = "" };            
            var expectedOutput = JsonConvert.SerializeObject(ExpectedResult);
            //Act
            var LdapController = new LdapController();
            IHttpActionResult result = LdapController.GetDeatilsFromLDAP(wLdapUserId);            
            var resultSearch = result as OkNegotiatedContentResult<string>;
            //Assert            
            Assert.AreEqual(resultSearch.Content, expectedOutput);
            Assert.IsNotNull(resultSearch.Content);
            Assert.IsNotNull(resultSearch.Content);
        }
        [TestMethod]
        public void LDAPUserExistanceTestWithValidLDAPUidAndPwd()
        {
            //Arrange
            var ExpectedResult = new { result = true };
            var expectedOutput = JsonConvert.SerializeObject(ExpectedResult);
            //string result2 = true;

            //Act
            var LdapController = new LdapController();
            IHttpActionResult result = LdapController.LDAPLoginResult(LdapUserId, LdapPassword);
            var resultSearch = result as OkNegotiatedContentResult<string>;            
            //Assert            
            Assert.AreEqual(resultSearch.Content, ExpectedResult.result.ToString().ToLower());
            Assert.IsNotNull(resultSearch.Content);
            Assert.IsNotNull(resultSearch.Content);
        }
        [TestMethod]
        public void LDAPUserExistanceTestWithWorngLDAPuIdValidpwd()
        {
            //Arrange
            var ExpectedResult = new { result = false };
            var expectedOutput = JsonConvert.SerializeObject(ExpectedResult);
            //Act
            var LdapController = new LdapController();
            IHttpActionResult result = LdapController.LDAPLoginResult(wLdapUserId, LdapPassword);
            var resultSearch = result as OkNegotiatedContentResult<string>;
            //Assert   
            Assert.IsNotNull(resultSearch.Content);
            Assert.IsNotNull(resultSearch.Content);
            Assert.AreEqual(resultSearch.Content, ExpectedResult.result.ToString().ToLower());            
        }
        [TestMethod]
        public void LDAPUserExistanceTestWithValidLDAPUidWrongPwd()
        {
            //Arrange
            var ExpectedResult = new { result = false };
            var expectedOutput = JsonConvert.SerializeObject(ExpectedResult);
            //Act
            var LdapController = new LdapController();
            IHttpActionResult result = LdapController.LDAPLoginResult(LdapUserId, wLdapPassword);
            var resultSearch = result as OkNegotiatedContentResult<string>;
            //Assert   
            Assert.IsNotNull(resultSearch.Content);
            Assert.IsNotNull(resultSearch.Content);
            Assert.AreEqual(resultSearch.Content, ExpectedResult.result.ToString().ToLower());
        }
        [TestMethod]
        public void LDAPUserExistanceTestWithWrongLDAPUidWrongPwd()
        {
            //Arrange
            var ExpectedResult = new { result = false };
            var expectedOutput = JsonConvert.SerializeObject(ExpectedResult);
            //Act
            var LdapController = new LdapController();
            IHttpActionResult result = LdapController.LDAPLoginResult(wLdapUserId, wLdapPassword);
            var resultSearch = result as OkNegotiatedContentResult<string>;
            //Assert   
            Assert.IsNotNull(resultSearch.Content);
            Assert.IsNotNull(resultSearch.Content);
            Assert.AreEqual(resultSearch.Content, ExpectedResult.result.ToString().ToLower());
        }
    }
}
