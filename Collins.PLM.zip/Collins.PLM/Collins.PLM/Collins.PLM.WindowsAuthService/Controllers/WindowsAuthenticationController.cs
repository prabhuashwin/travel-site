﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    CollinsPLMException.cs
* File Desc   :    This file contains code pertaining to class for GOSPAException.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 07-Jul-2021                                Initial Creation
*********************************************************************************************/

using Collins.PLM.Common.Dto;
using Collins.PLM.WindowsAuthService.DirectoryHelper;
using Collins.PLM.WindowsAuthService.Helpers;
using Collins.PLM.WindowsAuthService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Collins.PLM.WindowsAuthService.Controllers
{
    public class WindowsAuthenticationController : ApiController
    {
        public OperationResult operationResult = new OperationResult();

        [HttpPost]
        [Route("api/WindowsAuth/SearchAllUserDetails")]
        public IHttpActionResult SearchAllUserDetails(SearchDto req)
        {
            #region
            //OperationResult opr = new OperationResult();
            //opr = new UserManager().GetRolebased_UserList("Venkat", "123456");
            //var result = ((IEnumerable)opr.Data).Cast<StandardAPI.DataModels.tbl_UserMaster>().ToList();
            //var list = result.FirstOrDefault();            
            //string name = list.UserName;
            #endregion

            try
            {
                ActiveDirectoryHelper helper = new ActiveDirectoryHelper();
                if (string.IsNullOrEmpty(req.fname))
                {
                    return BadRequest("Please pass name...");
                }
                OrgNameSearch srch = new OrgNameSearch();

                #region
                //var identity = (ClaimsIdentity)User.Identity;
                //return Ok("Hello: " + identity.Name);
                //var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetValueStreamList>().ToList();
                #endregion

                OperationResult res = srch.SearchAllUserDetails(req.fname, req.lname);

                return Ok(res);
            }
            catch (Exception ex)
            {
                //throw ex;
                return BadRequest(ex.ToString());
            }
        }

        //This resource is For all types of role
        //[Authorize(Roles = "SuperAdmin, Admin")]

        [Authorize]
        [HttpPost]
        [Route("api/WindowsAuth/SecureSearchAllUserDetails")]
        public IHttpActionResult SecureSearchAllUserDetails(SearchDto req)
        {
            try
            {
                ActiveDirectoryHelper helper = new ActiveDirectoryHelper();
                if (string.IsNullOrEmpty(req.fname) || string.IsNullOrEmpty(req.lname))
                {
                    return BadRequest("Please Enter First Name and Last Name...");
                }
                OrgNameSearch srch = new OrgNameSearch();
                return Ok(srch.SearchAllUserDetails(req.fname, req.lname));
            }
            catch (Exception ex)
            {
                //throw ex;
                return BadRequest(ex.ToString());
            }
        }

        [HttpGet]
        [Route("api/WindowsAuth/GetWindowsId")]
        public IHttpActionResult GetWindowsId()
        {
            try
            {
                var WindowsId = new { WindowsId = User.Identity.Name };
                OperationResult res = new OperationResult();
                if (WindowsId != null)
                {
                    res.Success = true;
                    res.Message = "Success";
                    res.MCode = MessageCode.OperationSuccessful;
                    res.Data = WindowsId;
                    //res.Data = "ABC";
                }
                else
                {
                    res.Success = false;
                    res.Message = "Fail";
                    res.MCode = MessageCode.OperationFailed;
                    res.Data = null;
                }
                return Ok(res);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpGet]
        [Route("api/WindowsAuth/GetUserDetail")]
        public IHttpActionResult GetUserDetail(string WindowsId)
        {
            try
            {
                var s = @"utcain\";
                var r = s.Substring(s.IndexOf(@"\") + 1);
                OrgNameSearch srch = new OrgNameSearch();
                var result = srch.SearchUserDetails(WindowsId.Substring(s.IndexOf(@"\") + 1));
                return Ok(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("api/WindowsAuth/GetWindowsUserId")]
        public IHttpActionResult GetWindowsUserId()
        {
            string ss = User.Identity.Name;
            return Ok(User.Identity.Name);

        }
    }
}
