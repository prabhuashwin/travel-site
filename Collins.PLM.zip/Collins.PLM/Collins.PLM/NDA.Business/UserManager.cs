﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UserManager.cs
* File Desc   :    This file contains code pertaining to UserDB Business Operations.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* -----------        ----------------------  -----------------------------------------------------
* 27-July-2021                               Initial Creation
*********************************************************************************************/

using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using Collins.PLM.Common.ExceptionHandler.Utilities;
using NDA.Business.DTO;
using NDA.Business.Interfaces;
using NDA.DataAccess;
using System;
using System.Reflection;

namespace NDA.Business
{
    public class UserManager : IRegistrationHandler
    {
        /// <summary>
        /// User DB
        /// </summary>
        public readonly UserDb UserDb;

        /// <summary>
        /// User Manager
        /// </summary>
        public UserManager()
        {
            this.UserDb = new UserDb();
        }
        
        /// <summary>Users the registration.</summary>
        /// <param name="req">The req.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentNullException">req</exception>
        public OperationResult UserRegistration(UserData req)
        {
            if (req == null) throw new ArgumentNullException(nameof(req));
            try
            {
                var registrationUser = UserDb != null && UserDb.RegistrationUser(req);

                if (registrationUser == true)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User registered successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = true
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User registered Fail",
                        MCode = MessageCode.OperationFailed,
                        Data = false
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>Checks the user existence.</summary>
        /// <param name="ldapUid">The LDAP uid.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentNullException">ldapUid</exception>
        public OperationResult CheckUserExistence(string ldapUid)
        {
            if (ldapUid == null) throw new ArgumentNullException(nameof(ldapUid));
            try
            {
                var userDt = UserDb.CheckUserExistence(ldapUid);
                var userDet = UtilityMethods.ConvertDataTable<UspCheckEmailExistance>(userDt);
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Menu List Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDet
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Menu List Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = userDet
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        
        /// <summary>Gets the user identifier by email.</summary>
        /// <param name="vcEmail">The vc email.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentNullException">userDt
        /// or
        /// userIdDt</exception>
        public OperationResult GetUserIdByEmail(string vcEmail)
        {
            try
            {
                var userDt = UserDb.GetUserIdByEmail(vcEmail);
                if (userDt == null) throw new ArgumentNullException(nameof(userDt));
                var userIdDt = UtilityMethods.ConvertDataTable<UspGetUserIdByEmail>(userDt);
                if (userIdDt == null) throw new ArgumentNullException(nameof(userIdDt));
                if (userDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "UserId Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userIdDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "UserId Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = userIdDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>Navbars the items.</summary>
        /// <param name="currentRole">The current role.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentNullException">menuItemsDt
        /// or
        /// menuItems</exception>
        public OperationResult NavbarItems(int currentRole)
        {
            try
            {
                var menuItemsDt = UserDb.MenuItems(currentRole);

                if (menuItemsDt == null) throw new ArgumentNullException(nameof(menuItemsDt));
                var menuItems = UtilityMethods.ConvertDataTable<MenuListItems>(menuItemsDt);

                if (menuItems == null) throw new ArgumentNullException(nameof(menuItems));
                if (menuItemsDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Menu List Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = menuItems
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Menu List Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = menuItems
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>Gets the name of the role.</summary>
        /// <param name="iRoleId">The i role identifier.</param>
        /// <returns></returns>
        public OperationResult GetRoleName(int iRoleId)
        {
            try
            {
                var userDetails = UserDb.GetRoleName(iRoleId);
                var userDetailsList = UtilityMethods.ConvertDataTable<UspGetRoleName>(userDetails);

                if (userDetails.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User Role Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDetailsList
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User Role Details not Existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDetailsList
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        
        /// <summary>Gets the user roles.</summary>
        /// <param name="iUserId">The i user identifier.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentNullException">userDetails
        /// or
        /// userDetailsList</exception>
        public OperationResult GetUserRoles(int iUserId)
        {
            try
            {
                var userDetails = UserDb.GetUserRoles(iUserId);
                if (userDetails == null) throw new ArgumentNullException(nameof(userDetails));
                var userDetailsList = UtilityMethods.ConvertDataTable<UspGetUserRoles>(userDetails);
                if (userDetailsList == null) throw new ArgumentNullException(nameof(userDetailsList));

                if (userDetails.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User Role Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDetailsList
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User Role Details not Existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDetailsList
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}
