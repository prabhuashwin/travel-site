﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    CollinsPLMConstants.cs
* File Desc   :    This file contains code pertaining to class for Constants.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 07-Jul-2021                                Initial Creation
*********************************************************************************************/

namespace Collins.PLM.Common.ExceptionHandler.Constants
{
    public class CollinsPLMConstants
    {
        public const string GenericGaurdMsg = "{0}: Please provide proper value.";
    }
}
