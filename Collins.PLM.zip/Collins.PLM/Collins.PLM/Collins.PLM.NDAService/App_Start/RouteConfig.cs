﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    RouteConfig
* File Desc   :    This file contains code pertaining to Routes.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* -----------        ----------------------  -----------------------------------------------------
* 27-July-2021                               Initial Creation
*********************************************************************************************/

using System.Web.Mvc;
using System.Web.Routing;

namespace Collins.PLM.NDAService
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
