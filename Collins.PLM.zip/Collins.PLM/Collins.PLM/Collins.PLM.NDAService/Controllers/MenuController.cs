﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    MenuController
* File Desc   :    This file contains code pertaining to deal with Menu Items.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* -----------        ----------------------  -----------------------------------------------------
* 27-July-2021                               Initial Creation
*********************************************************************************************/


using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using NDA.Business;
using System;
using System.Reflection;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace Collins.PLM.NDAService.Controllers
{
    public class MenuController : ApiController
    {
        [HttpGet, Route("api/Menu/MenuList")]
        public IHttpActionResult MenuList(int currentRole)
        {
            try
            {
                var operationResult = new UserManager().NavbarItems(currentRole);
                var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                return Ok(serializedData);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        
        
    }
}
