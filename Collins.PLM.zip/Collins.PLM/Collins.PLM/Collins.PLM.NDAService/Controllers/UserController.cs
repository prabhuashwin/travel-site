﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UserController
* File Desc   :    This file contains code pertaining to deal with User Roles,Authentication and Authorization.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* -----------        ----------------------  -----------------------------------------------------
* 27-July-2021                               Initial Creation
*********************************************************************************************/

using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using NDA.Business;
using System;
using System.Reflection;
using System.Web.Http;
using System.Web.Script.Serialization;
using UserData = NDA.Business.DTO.UserData;

namespace Collins.PLM.NDAService.Controllers
{
    public class UserController : ApiController
    {
        [HttpPost, Route("api/User/Register")]
        public IHttpActionResult Register(UserData req)
        {             
            try
            {
                var operationResult = new UserManager().UserRegistration(req);
                if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                return Ok(serializedData);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/User/CheckUserExistence")]
        public IHttpActionResult CheckUserExistence(string ldapUid)
        {
            try
            {
                var operationResult = new UserManager().CheckUserExistence(ldapUid);               
                var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                return Ok(serializedData);                
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/User/GetUserIdByEmail")]
        public IHttpActionResult GetUserIdByEmail(string vcEmail)
        {
            try
            {
                var operationResult = new UserManager().GetUserIdByEmail(vcEmail);
                if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                return Ok(serializedData);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/User/GetUserRoles")]
        public IHttpActionResult GetUserRoles(int iUserId)
        {
            try
            {
                var operationResult = new UserManager().GetUserRoles(iUserId);
                if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                return Ok(serializedData);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet, Route("api/User/GetRoleName")]
        public IHttpActionResult GetRoleName(int iRoleId)
        {
            try
            {
                var operationResult = new UserManager().GetRoleName(iRoleId);
                if (operationResult == null) throw new ArgumentNullException(nameof(operationResult));
                var serializedData = new JavaScriptSerializer().Serialize(operationResult);
                return Ok(serializedData);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

    }
}
