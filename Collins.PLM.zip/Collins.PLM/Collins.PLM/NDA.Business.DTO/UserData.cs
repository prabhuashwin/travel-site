﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UserData.cd
* File Desc   :    This file contains code pertaining to User Models
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* -----------        ----------------------  -----------------------------------------------------
* 27-July-2021                               Initial Creation
*********************************************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NDA.Business.DTO
{
    /// <summary></summary>
    public class UserData
    {
        public string Username { get; set; }
        public string EmailId { get; set; }
        public string LdapUserId { get; set; }
    }

    /// <summary>/// </summary>
    public class MenuListItems
    {
        public int iId { get; set; }
        public int IMenuId { get; set; }
        public int? ILevelId { get; set; }
        public string VcController { get; set; }
        public string VcAction { get; set; }
        public int IRoleId { get; set; }
        public string VcStatus { get; set; }
        public int? IsParent { get; set; }
        public string VcMenuLinkName { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class UspGetUserRoles
    {
        public string VcTitle { get; set; }
        public string VcRoleDescription { get; set; }
        public int ICurrentRole { get; set; }
        public string VcFullName { get; set; }
        public string VcLdapUserId { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class UspGetRoleName
    {
        public string VcRoleDescription { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class UspCheckEmailExistance
    {       
        public int UserId { get; set; }
        public string VcEmail { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class UspGetUserIdByEmail
    {
        public int IUserId { get; set; }
    }
}
