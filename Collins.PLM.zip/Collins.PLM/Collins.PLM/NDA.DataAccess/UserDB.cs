﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UserDb.cs
* File Desc   :    This file contains code pertaining to UserDB DataAccess Operations.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* -----------        ----------------------  -----------------------------------------------------
* 27-July-2021                               Initial Creation
*********************************************************************************************/


using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using Collins.PLM.DataAccessHandler;
using NDA.Business.DTO;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;

namespace NDA.DataAccess
{
    public class UserDb
    {
        private bool _status;
        private DataSet _ds;
        private DataTable _dt;

        /// <summary>Registrations the user.</summary>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        public bool RegistrationUser(UserData request)
        {
            try
            {
                var pars = new SqlParameter[3];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar, ParameterName = "@vcEmail", Value = request.EmailId
                };

                pars[1] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar, ParameterName = "@vcFullName", Value = request.Username
                };

                pars[2] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar, ParameterName = "@vcLDAPUserID", Value = request.LdapUserId
                };

                int returnValue;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    returnValue = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "USP_RegisterUser", pars));
                }
                
                _status = returnValue == 3;

                return _status;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }

        }
        
        /// <summary>Menus the items.</summary>
        /// <param name="currentRole">The current role.</param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentOutOfRangeException">currentRole</exception>
        public DataTable MenuItems(int currentRole)
        {
            if (currentRole <= 0) throw new ArgumentOutOfRangeException(nameof(currentRole));
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar, ParameterName = "@iRoleId", Value = currentRole
                };
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_NavbarItems", pars);
                }
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>Checks the user existence.</summary>
        /// <param name="ldapUid">The LDAP uid.</param>
        /// <returns></returns>
        public DataTable CheckUserExistence(string ldapUid)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter
                {
                    SqlDbType = SqlDbType.VarChar, ParameterName = "@vcLDAPUserID", Value = ldapUid
                };

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_checkEmailExistance", pars);
                }
                _dt = _ds.Tables[0];
                return _dt;

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>Gets the user identifier by email.</summary>
        /// <param name="vcEmail">The vc email.</param>
        /// <returns></returns>
        public DataTable GetUserIdByEmail(string vcEmail)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter {SqlDbType = SqlDbType.VarChar, ParameterName = "@vcEmail", Value = vcEmail};

                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_GetUserIdByEmail", pars);
                }
                _dt = _ds.Tables[0];
                return _dt;

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>Gets the name of the role.</summary>
        /// <param name="iRoleId">The i role identifier.</param>
        /// <returns></returns>
        public DataTable GetRoleName(int iRoleId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter {SqlDbType = SqlDbType.Int, ParameterName = "@iRoleId", Value = iRoleId};
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_GetRoleName", pars);
                }
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>Gets the user roles.</summary>
        /// <param name="iUserId">The i user identifier.</param>
        /// <returns></returns>
        public DataTable GetUserRoles(int iUserId)
        {
            try
            {
                var pars = new SqlParameter[1];
                pars[0] = new SqlParameter {SqlDbType = SqlDbType.Int, ParameterName = "@iUserId", Value = iUserId};
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString))
                {
                    _ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_GetUserRoles", pars);
                }
                _dt = _ds.Tables[0];
                return _dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}
