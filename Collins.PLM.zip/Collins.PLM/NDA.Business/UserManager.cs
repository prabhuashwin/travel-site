﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UserManager.cs
* File Desc   :    This file contains code pertaining to UserDB Business Operations.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* -----------        ----------------------  -----------------------------------------------------
* 27-July-2021                               Initial Creation
*********************************************************************************************/


using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using NDA.Business.DTO;
using NDA.Business.Interfaces;
using NDA.DataAccess;
using NDA.DataAccess.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;

namespace NDA.Business
{
    public class UserManager : IRegistrationHandler
    {
        private UserDB userDB;
        public UserManager()
        {
            this.userDB = new UserDB();
        }
        public OperationResult UserRegistration(UserData req)
        {
            try
            {
                bool usrdet;
                UserDB userDB = new UserDB();
                //using (UnitOfWork uow = new UnitOfWork())
                //{
                //    var userDB = uow.GetDbInterface<UserDB>();
                usrdet = userDB.RegistrationUser(req);
                //}

                if (usrdet == true)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User registered successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = usrdet
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User registered Fail",
                        MCode = MessageCode.OperationFailed,
                        Data = usrdet
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult CheckUserExistance(string LDAPUid)
        {
            try
            {
                DataTable UserDt = userDB.CheckUserExistance(LDAPUid);
                List<usp_checkEmailExistance> UserDet = ConvertDataTable<usp_checkEmailExistance>(UserDt);
                if (UserDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Menu List Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = UserDet
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Menu List Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = UserDet
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetUserIdByEmail(string vcEmail)
        {
            try
            {
                DataTable UserDt = userDB.GetUserIdByEmail(vcEmail);
                List<usp_GetUserIdByEmail> UserIdDt = ConvertDataTable<usp_GetUserIdByEmail>(UserDt);
                if (UserDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "UserId Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = UserIdDt
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "UserId Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = UserIdDt
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult NavbarItems(int currentRole)
        {
            try
            {
                //UserDB userDB = new UserDB();
                DataTable MenuItemsDt = userDB.MenuItems(currentRole);
                List<MenuListItems> MenuItems = ConvertDataTable<MenuListItems>(MenuItemsDt);
                if (MenuItemsDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Menu List Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = MenuItems
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Menu List Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = MenuItems
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetRoleName(int iRoleId)
        {
            try
            {
                DataTable userDeatails = userDB.GetRoleName(iRoleId);
                List<usp_GetRoleName> userDeatailsList = ConvertDataTable<usp_GetRoleName>(userDeatails);

                if (userDeatails.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User Role Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDeatailsList
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User Role Details not Existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDeatailsList
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetUserRoles(int iUserId)
        {
            try
            {
                DataTable userDeatails = userDB.GetUserRoles(iUserId);
                List<usp_GetUserRoles> userDeatailsList = ConvertDataTable<usp_GetUserRoles>(userDeatails);

                if (userDeatails.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User Role Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDeatailsList
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User Role Details not Existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDeatailsList
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #region--Utils
        private static List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        private static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                        pro.SetValue(obj, dr[column.ColumnName], null);
                    else
                        continue;
                }
            }
            return obj;
        }
        #endregion


    }
}
