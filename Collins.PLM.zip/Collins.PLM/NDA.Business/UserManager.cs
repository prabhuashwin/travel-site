﻿using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using NDA.Business.DTO;
using NDA.Business.Interfaces;
using NDA.DataAccess;
using NDA.DataAccess.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;

namespace NDA.Business
{
    public class UserManager : IRegistrationHandler
    {
        private UserDB userDB;
        public UserManager()
        {
            this.userDB = new UserDB();
        }
        public OperationResult UserRegistration(UserData req)
        {
            try
            {
                bool usrdet;
                UserDB userDB = new UserDB();
                //using (UnitOfWork uow = new UnitOfWork())
                //{
                //    var userDB = uow.GetDbInterface<UserDB>();
                usrdet = userDB.RegistrationUser(req);
                //}

                if (usrdet == true)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User registered successfully",
                        MCode = MessageCode.OperationSuccessful,
                        Data = usrdet
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User registered Fail",
                        MCode = MessageCode.OperationFailed,
                        Data = usrdet
                    };
                }

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult NavbarItems(int currentRole)
        {
            try
            {
                //UserDB userDB = new UserDB();
                DataTable MenuItemsDt = userDB.MenuItems(currentRole);
                List<MenuListItems> MenuItems = ConvertDataTableToClass(MenuItemsDt);
                if (MenuItemsDt.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Menu List Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = MenuItems
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "Menu List Empty",
                        MCode = MessageCode.OperationFailed,
                        Data = MenuItems
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetRoleName(int iRoleId)
        {
            try
            {
                DataTable userDeatails = userDB.GetRoleName(iRoleId);
                List<usp_GetRoleName> userDeatailsList = ConvertDataTableToUserRoleNameList(userDeatails);

                if (userDeatails.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User Role Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDeatailsList
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User Role Details not Existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDeatailsList
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetUserRoles(int iUserId)
        {
            try
            {
                DataTable userDeatails = userDB.GetUserRoles(iUserId);
                List<usp_GetUserRoles_Result> userDeatailsList = ConvertDataTableToUserRolesList(userDeatails);

                if (userDeatails.Rows.Count > 0)
                {
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "User Role Details Fetched",
                        MCode = MessageCode.OperationSuccessful,
                        Data = userDeatailsList
                    };
                }
                else
                {
                    return new OperationResult()
                    {
                        Success = false,
                        Message = "User Role Details not Existed",
                        MCode = MessageCode.OperationFailed,
                        Data = userDeatailsList
                    };
                }
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public List<MenuListItems> ConvertDataTableToClass(DataTable dt)
        {
            List<MenuListItems> ML = new List<MenuListItems>();

            foreach (DataRow row in dt.Rows)
            {
                MenuListItems MI = new MenuListItems();
                //iId, iMenuId, iLevelId, vcController, vcAction, iRoleId, vcStatus, isParent, vcMenuLinkName
                MI.iId = Convert.ToInt32(row["iId"].ToString());
                MI.iMenuId = Convert.ToInt32(row["iMenuId"].ToString());
                MI.iLevelId = Convert.ToInt32(row["iLevelId"].ToString());
                MI.vcController = row["vcController"].ToString();
                MI.vcAction = row["vcAction"].ToString();
                MI.iRoleId = Convert.ToInt32(row["iRoleId"].ToString());
                MI.vcStatus = row["vcStatus"].ToString();
                MI.isParent = Convert.ToInt32(row["isParent"].ToString());
                MI.vcMenuLinkName = row["vcMenuLinkName"].ToString();
                ML.Add(MI);
            }
            return ML;
        }
        public List<usp_GetUserRoles_Result> ConvertDataTableToUserRolesList(DataTable dt)
        {
            List<usp_GetUserRoles_Result> URL = new List<usp_GetUserRoles_Result>();

            foreach (DataRow row in dt.Rows)
            {
                usp_GetUserRoles_Result UR = new usp_GetUserRoles_Result();

                UR.vcTitle = row["vcTitle"].ToString();
                UR.vcRoleDescription = row["vcRoleDescription"].ToString();
                UR.iCurrentRole = Convert.ToInt32(row["iCurrentRole"].ToString());
                UR.vcFullName = row["vcFullName"].ToString();
                UR.vcLDAPUserID = row["vcLDAPUserID"].ToString();

                URL.Add(UR);
            }
            return URL;
        }
        
        public List<usp_GetRoleName> ConvertDataTableToUserRoleNameList(DataTable dt)
        {
            List<usp_GetRoleName> URL = new List<usp_GetRoleName>();

            foreach (DataRow row in dt.Rows)
            {
                usp_GetRoleName UR = new usp_GetRoleName();
                UR.vcRoleDescription = row["vcRoleDescription"].ToString();
                URL.Add(UR);
            }
            return URL;
        }
    }
}
