﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NDA.Business.DTO
{

    public class UserData
    {
        public string username { get; set; }
        public string emailId { get; set; }
        public string LDAPUserId { get; set; }
    }
    public class MenuListItems
    {
        //iId, iMenuId, iLevelId, vcController, vcAction, iRoleId, vcStatus, isParent, vcMenuLinkName
        public int iId { get; set; }
        public int iMenuId { get; set; }
        public Nullable<int> iLevelId { get; set; }
        public string vcController { get; set; }
        public string vcAction { get; set; }
        public int iRoleId { get; set; }
        public string vcStatus { get; set; }
        public Nullable<int> isParent { get; set; }
        public string vcMenuLinkName { get; set; }
    }

    public class usp_GetUserRoles_Result
    {
        public string vcTitle { get; set; }
        public string vcRoleDescription { get; set; }
        public int iCurrentRole { get; set; }
        public string vcFullName { get; set; }
        public string vcLDAPUserID { get; set; }
    }
    public class usp_GetRoleName
    {
        public string vcRoleDescription { get; set; }

    }

}
