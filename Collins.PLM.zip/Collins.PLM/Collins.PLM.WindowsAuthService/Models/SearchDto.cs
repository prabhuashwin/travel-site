﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
*
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name          :             SearchDto.cs
* File Desc          :             This file contains code pertaining to SearchDto
*                    
*
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 07-Jul-2021                                Initial Creation
*********************************************************************************************/

namespace Collins.PLM.WindowsAuthService.Models
{
    public class SearchDto
    {
        public string fname { get; set; }
        public string lname { get; set; }
    }
}