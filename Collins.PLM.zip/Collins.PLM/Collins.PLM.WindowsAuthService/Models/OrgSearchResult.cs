﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
*
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name          :             OrgSearchResult.cs
* File Desc          :             This file contains code pertaining to LDAP Search.
*                    
*
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 07-Jul-2021                                Initial Creation
*********************************************************************************************/

namespace Collins.PLM.WindowsAuthService.Models
{
    public class OrgSearchResult
    {
        /// <summary>
        /// Gets or sets the search identifier.
        /// </summary>
        /// <value>
        /// The search identifier.
        /// </value>
        public string SearchId { get; set; }
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }
        /// <summary>
        /// Gets or sets the windows identifier.
        /// </summary>
        /// <value>
        /// The windows identifier.
        /// </value>
        public string WindowsId { get; set; }
        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>
        /// The email.
        /// </value>
        public string Email { get; set; }
        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title { get; set; }
    }
}