﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
*
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name          :             OrgNameSearch.cs
* File Desc          :             This file contains code pertaining to LDAP Search.
*                    
*
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 07-Jul-2021                                Initial Creation
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;
using Collins.PLM.Common.Dto;
using Collins.PLM.WindowsAuthService.Models;
using Collins.PLM.WindowsAuthService.DirectoryHelper;

namespace Collins.PLM.WindowsAuthService.Helpers
{
    
    /// <summary>
    ///
    /// </summary>
    public class OrgNameSearch
    {
        /// <summary>
        /// The first name
        /// </summary>
        string firstName = string.Empty;
        /// <summary>
        /// The last name
        /// </summary>
        string lastName = string.Empty;

        //string searchApi = @"http://spapp.utc.com/directorysearch/SearchResultForm.aspx?fn={0}&ln={1}&cn=&tn=&bu=HS&mc=C";
        /// <summary>
        /// The search API
        /// </summary>
        string searchApi = @"http://spapp.utc.com/directorysearch/SearchResultForm.aspx?fn={0}&ln={1}&cn=&tn=&bu=HS&mc=C&pg=-1";

        /// <summary>
        /// The detail API
        /// </summary>
        string detailApi = @"http://spapp.utc.com/directorysearch/UserDetails.aspx?fn={0}&ln={1}&cn=&tn=&bu=HS&mc=C&pg=-1&uid={2}";

        //string detailApi = @"http://spapp.utc.com/directorysearch/UserDetails.aspx?fn={0}&ln={1}&cn=&tn=&bu=HS&mc=C&pg=all&uid={2}";

        //string detailApi = @"http://spapp.utc.com/directorysearch/UserDetails.aspx?fn={0}&ln={1}&cn=&tn=&bu=all&mc=C&pg=all&uid={2}";


        /// <summary>
        /// Searches the specified function.
        /// </summary>
        /// <param name="fn">The function.</param>
        /// <param name="ln">The ln.</param>
        /// <returns></returns>
        /// <exception cref="Exception">No string to search</exception>
        public List<OrgSearchResult> Search(string fn, string ln)
        {
            try
            {
                if (string.IsNullOrEmpty(fn) && string.IsNullOrEmpty(ln))
                {
                    throw new Exception("No string to search");
                }

                List<OrgSearchResult> lst = new List<OrgSearchResult>();

                var url = string.Format(searchApi, fn, ln);
                var web = new HtmlWeb();
                var doc = web.Load(url);
                var data = doc.GetElementbyId("updtusers");
                if (data != null && data.HasChildNodes)
                {
                    var rows = data.ChildNodes.Where(x => x.Name.Equals("tr") && x.HasAttributes).ToList();
                    foreach (var item in rows)
                    {
                        OrgSearchResult res = new OrgSearchResult();
                        res.SearchId = getDatainTags(item.Attributes["onclick"].Value, "uid=", "&#39;,");

                        var td = item.ChildNodes.Where(x => x.Name.Equals("td") && x.HasAttributes);
                        foreach (var tdata in td)
                        {
                            if (tdata.Attributes.Where(x => x.Value.Equals("user-data")).Count() > 0)
                            {
                                var usrData = tdata.ChildNodes.Where(x => x.Name.Equals("div")).ToList();
                                if (usrData != null && usrData.Count >= 1)
                                {
                                    res.Name = usrData[0].InnerText.Trim();
                                    res.Email = usrData[1].InnerText.Trim();
                                }
                            }
                        }
                        lst.Add(res);
                    }

                    foreach (var item in lst)
                    {
                        var url2 = string.Format(detailApi, fn, ln, item.SearchId);
                        var web2 = new HtmlWeb();
                        var doc2 = web.Load(url2);

                        var data2 = doc2.GetElementbyId("business-table");
                        if (data2 != null)
                        {
                            var domainData = getDatainTags(data2.InnerText, @"Domain\UserName", "Azure ID").Trim();
                            foreach (var dm in domainData.Split(';'))
                            {
                                if (dm.ToUpper().Contains("UTCAIN\\") || dm.ToUpper().Contains("UTCAUS\\"))
                                {
                                    item.WindowsId = dm.Trim();
                                }
                            }
                        }

                        var data3 = doc2.GetElementbyId("UserDetailsControl1_rptrSummary__ctl2_lblValue");
                        if (data3 != null)
                        {
                            item.Title = data3.InnerText.Trim();
                        }

                    }

                }
                return lst;
            }
            catch (Exception)
            {

                throw;
            }
        }




        /// <summary>
        /// Get User Details using LDAP Library
        /// </summary>
        /// <param name="fn">The function.</param>
        /// <param name="ln">The ln.</param>
        /// <returns></returns>
        /// <exception cref="Exception">No string to search</exception>
        public OperationResult SearchAllUserDetails(string fn, string ln)
        {
            try
            {
                ActiveDirectoryHelper helper = new ActiveDirectoryHelper();
                if (string.IsNullOrEmpty(fn) && string.IsNullOrEmpty(ln))
                {
                    throw new Exception("No string to search");
                }
                List<OrgSearchResult> lst = new List<OrgSearchResult>();
                var usrDetails = helper.GetUserByName(fn, ln);


                if (usrDetails.Count != 0)
                {
                    foreach (var item in usrDetails)
                    {
                        OrgSearchResult res = new OrgSearchResult();

                        res.Name = item.FirstName + " " + item.LastName;
                        res.WindowsId = item.LoginNameWithDomain;
                        res.Title = item.LoginName;
                        res.Email = item.EmailAddress;
                        lst.Add(res);
                    }
                    return new OperationResult()
                    {
                        Success = true,
                        Message = "Success",
                        MCode = MessageCode.OperationSuccessful,
                        Data = lst
                    };
                }
                else
                {
                    return new OperationResult
                    {
                        Success = false,
                        Message = "Fail",
                        MCode = MessageCode.OperationFailed,
                        Data = { }
                    };
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public OperationResult SearchUserDetails(string name)
        {
            try
            {
                ActiveDirectoryHelper helper = new ActiveDirectoryHelper();
                if (string.IsNullOrEmpty(name))
                {
                    throw new Exception("No string to search");
                }
                OrgSearchResult lst = new OrgSearchResult();
                var usrDetails = helper.GetUserByLoginName(name);
                if (usrDetails != null)
                {
                    OrgSearchResult res = new OrgSearchResult();
                    lst.Name = usrDetails.FirstName + " " + usrDetails.LastName;
                    lst.WindowsId = usrDetails.LoginNameWithDomain;
                    lst.Title = usrDetails.LoginName;
                    lst.Email = usrDetails.EmailAddress;

                    return new OperationResult
                    {
                        Success = true,
                        Message = "Success",
                        MCode = MessageCode.OperationSuccessful,
                        Data = lst
                    };
                }
                else
                {
                    return new OperationResult
                    {
                        Success = false,
                        Message = "Fail",
                        MCode = MessageCode.OperationFailed,
                        Data = { }
                    };
                }


                //return lst;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Gets the datain tags.
        /// </summary>
        /// <param name="s">The s.</param>
        /// <param name="starttag">The starttag.</param>
        /// <param name="endtag">The endtag.</param>
        /// <returns></returns>
        private string getDatainTags(string s, string starttag, string endtag)
        {
            var startTag = starttag;
            int startIndex = s.IndexOf(startTag) + startTag.Length;
            int endIndex = s.IndexOf(endtag, startIndex);
            return s.Substring(startIndex, endIndex - startIndex);
        }
    }
}