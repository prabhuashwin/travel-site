﻿using Collins.PLM.Common.Dto;
using NDA.Business.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NDA.Business.Interfaces
{
    public interface IRegistrationHandler
    {
        OperationResult UserRegistration(UserData req);
    }
}
