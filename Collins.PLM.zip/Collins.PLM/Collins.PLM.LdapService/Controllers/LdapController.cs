﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    LdapController.cs
* File Desc   :    This file contains code pertaining to Ldap Controller methods.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 07-Jul-2021                                Initial Creation
*********************************************************************************************/

using Collins.PLM.Common.Dto;
using System.Configuration;
using System.IO;
using System.Net;
using System.Web.Http;

namespace Collins.PLM.LdapService.Controllers
{
    //[EnableCors(origins: "http://localhost:51315/", headers: "*", methods: "*")]
    public class LdapController : ApiController
    {
        public OperationResult operationResult = new OperationResult();
        public string webAPIBase = ConfigurationManager.AppSettings["LdapApiUrl"];

        [HttpGet]
        [Route("api/LDAP/LDAPLoginResult")]
        public IHttpActionResult LDAPLoginResult(string userid, string password)
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                   | SecurityProtocolType.Tls11
                   | SecurityProtocolType.Tls12
                   | SecurityProtocolType.Ssl3;

            string requestedUrl = webAPIBase + "/LDAP/Login?userid=" + userid + "&password=" + password;

            var request = (HttpWebRequest)WebRequest.Create(requestedUrl);
            request.Method = "GET";
            var response = (HttpWebResponse)request.GetResponse();
            string responseString;
            using (var stream = response.GetResponseStream())
            {
                using (var reader = new StreamReader(stream))
                {
                    responseString = reader.ReadToEnd();
                }
            }
            return Ok(responseString);
        }
        
        [HttpGet]
        [Route("api/LDAP/GetDeatilsFromLDAP")]
        public IHttpActionResult GetDeatilsFromLDAP(string userid)
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                       | SecurityProtocolType.Tls11
                       | SecurityProtocolType.Tls12
                       | SecurityProtocolType.Ssl3;

                string requestedUrl = webAPIBase + "/LDAP/GetDetailsFromLDAP?userid=" + userid;

                var request = (HttpWebRequest)WebRequest.Create(requestedUrl);
                request.Method = "GET";
                var response = (HttpWebResponse)request.GetResponse();
                string responseString;
                using (var stream = response.GetResponseStream())
                {
                    using (var reader = new StreamReader(stream))
                    {
                        responseString = reader.ReadToEnd();
                    }
                }
                return Ok(responseString);
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.ToString());
            }
           
        }
    }
}
