﻿using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using Collins.PLM.DataAccessHandler;
using NDA.Business.DTO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace NDA.DataAccess
{
    public class UserDB
    {
        bool status;
        
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        public bool RegistrationUser(UserData request)
        {
            try
            {
                SqlParameter[] pars = new SqlParameter[3];
                pars[0] = new SqlParameter();
                pars[0].SqlDbType = SqlDbType.VarChar;
                pars[0].ParameterName = "@vcEmail";
                pars[0].Value = request.emailId;

                pars[1] = new SqlParameter();
                pars[1].SqlDbType = SqlDbType.VarChar;
                pars[1].ParameterName = "@vcFullName";
                pars[1].Value = request.username;

                pars[2] = new SqlParameter();
                pars[2].SqlDbType = SqlDbType.VarChar;
                pars[2].ParameterName = "@vcLDAPUserID";
                pars[2].Value = request.LDAPUserId;
                #region
                //pars[1] = new SqlParameter();
                //pars[1].SqlDbType = SqlDbType.Int;
                //pars[1].ParameterName = "@ReturnValue";
                //pars[1].Direction = ParameterDirection.Output;
                #endregion
                int returnval = Convert.ToInt32(SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "USP_RegisterUser", pars));
                //int returnval = Convert.ToInt32(pars[1].Value);

                if (returnval == 3)
                    status = true;
                else
                    status = false;
               
                return status;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw exception;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }

        }        
        public DataTable MenuItems(int currentRole)
        {
            try
            {
                SqlParameter[] pars = new SqlParameter[1];
                pars[0] = new SqlParameter();
                pars[0].SqlDbType = SqlDbType.VarChar;
                pars[0].ParameterName = "@iRoleId";
                pars[0].Value = currentRole;

                DataSet ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_NavbarItems", pars);
                DataTable dt = ds.Tables[0];
                return dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw exception;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

      
        public DataTable CheckUserExistance(string LDAPUid)
        {
            try
            {
                SqlParameter[] pars = new SqlParameter[1];
                pars[0] = new SqlParameter();
                pars[0].SqlDbType = SqlDbType.VarChar;
                pars[0].ParameterName = "@vcLDAPUserID";
                pars[0].Value = LDAPUid;

                DataSet ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_checkEmailExistance", pars);
                DataTable dt = ds.Tables[0];
                return dt;

            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw exception;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetRoleName(int iRoleId)
        {
            try
            {
                SqlParameter[] pars = new SqlParameter[1];
                pars[0] = new SqlParameter();
                pars[0].SqlDbType = SqlDbType.Int;
                pars[0].ParameterName = "@iRoleId";
                pars[0].Value = iRoleId;

                DataSet ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_GetRoleName", pars);
                DataTable dt = ds.Tables[0];
                return dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw exception;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public DataTable GetUserRoles(int iUserId)
        {
            try
            {
                SqlParameter[] pars = new SqlParameter[1];
                pars[0] = new SqlParameter();
                pars[0].SqlDbType = SqlDbType.Int;
                pars[0].ParameterName = "@iUserId";
                pars[0].Value = iUserId;

                DataSet ds = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "usp_GetUserRoles", pars);
                DataTable dt = ds.Tables[0];
                return dt;
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw exception;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        
    }
}
