﻿using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using NDA.Business;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace Collins.PLM.NDAService.Controllers
{
    public class NDAController : ApiController
    {
        [HttpGet]
        [Route("api/NDA/MenuList")]
        public IHttpActionResult MenuList(int currentRole)
        {
            try
            {                
                OperationResult or = new OperationResult();
                or = new UserManager().NavbarItems(currentRole);
                var json = new JavaScriptSerializer().Serialize(or);                
                return Ok(json);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet]
        [Route("api/NDA/GetUserRoles")]
        public IHttpActionResult GetUserRoles(int iUserId)
        {
            try
            {
                OperationResult or = new OperationResult();
                or = new UserManager().GetUserRoles(iUserId);
                var json = new JavaScriptSerializer().Serialize(or);
                return Ok(json);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet]
        [Route("api/NDA/GetRoleName")]
        public IHttpActionResult GetRoleName(int iRoleId)
        {
            try
            {
                OperationResult or = new OperationResult();
                or = new UserManager().GetRoleName(iRoleId);
                var json = new JavaScriptSerializer().Serialize(or);
                return Ok(json);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

    }
}
