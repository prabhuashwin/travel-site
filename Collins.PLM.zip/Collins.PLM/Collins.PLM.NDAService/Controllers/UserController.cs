﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UserController
* File Desc   :    This file contains code pertaining to deal with User Roles,Authentication and Autherization.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* -----------        ----------------------  -----------------------------------------------------
* 27-July-2021                               Initial Creation
*********************************************************************************************/

using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using NDA.Business;
using NDA.Business.DTO;
using NDA.Business.Interfaces;
using System;
using System.Reflection;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace Collins.PLM.NDAService.Controllers
{
    public class UserController : ApiController
    {
        [HttpPost]
        [Route("api/User/Register")]
        public IHttpActionResult Register(UserData req)
        {             
            try
            {
                OperationResult or = new OperationResult();
                or = new UserManager().UserRegistration(req);
                var json = new JavaScriptSerializer().Serialize(or);
                return Ok(json);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet]
        [Route("api/User/CheckUserExistance")]
        public IHttpActionResult CheckUserExistance(string LDAPUid)
        {
            try
            {
                OperationResult or = new OperationResult();
                or = new UserManager().CheckUserExistance(LDAPUid);               
                var json = new JavaScriptSerializer().Serialize(or);
                return Ok(json);                
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet]
        [Route("api/User/GetUserIdByEmail")]
        public IHttpActionResult GetUserIdByEmail(string vcEmail)
        {
            try
            {
                OperationResult or = new OperationResult();
                or = new UserManager().GetUserIdByEmail(vcEmail);
                var json = new JavaScriptSerializer().Serialize(or);
                return Ok(json);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet]
        [Route("api/User/GetUserRoles")]
        public IHttpActionResult GetUserRoles(int iUserId)
        {
            try
            {
                OperationResult or = new OperationResult();
                or = new UserManager().GetUserRoles(iUserId);
                var json = new JavaScriptSerializer().Serialize(or);
                return Ok(json);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

        [HttpGet]
        [Route("api/User/GetRoleName")]
        public IHttpActionResult GetRoleName(int iRoleId)
        {
            try
            {
                OperationResult or = new OperationResult();
                or = new UserManager().GetRoleName(iRoleId);
                var json = new JavaScriptSerializer().Serialize(or);
                return Ok(json);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }

    }
}
