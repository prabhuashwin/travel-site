﻿using Collins.PLM.Common.Dto;
using Collins.PLM.Common.ExceptionHandler.Exception;
using Collins.PLM.Common.ExceptionHandler.Logging;
using NDA.Business;
using NDA.Business.DTO;
using NDA.Business.Interfaces;
using System;
using System.Reflection;
using System.Web.Http;

namespace Collins.PLM.NDAService.Controllers
{
    public class RegistrationController : ApiController
    {
        [HttpPost]
        [Route("api/Registration/Register")]
        public IHttpActionResult Register(UserData req)
        {             
            try
            {
                IRegistrationHandler irh = new UserManager();
                OperationResult or = new OperationResult();
                or = new UserManager().UserRegistration(req);
                return Ok(or);
            }
            catch (CollinsPLMException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return BadRequest();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return InternalServerError();
            }
        }        
    }
}
