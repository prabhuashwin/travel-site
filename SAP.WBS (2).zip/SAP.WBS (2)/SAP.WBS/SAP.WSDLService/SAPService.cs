﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Reflection;
using SAP.Framework.Constants;
using SAP.Framework.Logging;
using SAP.WSDLService.SAPWSDLReferenceWBSElement;
using SAP.WSDLService.SAPWSDLReferenceNetwork;
using SAP.Framework.Exception;

namespace SAP.WSDLService
{
    /// <summary>
    /// 
    /// </summary>
    public class SapService
    {
        #region Class Members

        /// <summary>
        /// The client
        /// </summary>
        private readonly Z_FI_RFC_WBS_UTIL _client;

        /// <summary>
        /// The client request
        /// </summary>
        private ZFiRfcWbsUtil _clientRequest;

        /// <summary>
        /// The client response
        /// </summary>
        private ZFiRfcWbsUtilResponse _clientResponse;

        /// <summary>
        /// The netork client
        /// </summary>
        private readonly Z_FI_RFC_NW_UTIL _networkClient;

        /// <summary>
        /// The network request
        /// </summary>
        private ZFiRfcNwUtil _networkRequest;

        /// <summary>
        /// The network response
        /// </summary>
        private ZFiRfcNwUtilResponse _networkResponse;

        /// <summary>
        /// The netork client tasks
        /// </summary>
        private readonly Z_FI_RFC_NW_UTIL _networkClientTasks;

        /// <summary>
        /// The network request tasks
        /// </summary>
        private ZFiRfcNwUtil _networkRequestTasks;

        /// <summary>
        /// The network response tasks
        /// </summary>
        private ZFiRfcNwUtilResponse _networkResponseTasks;
        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="SapService"/> class.
        /// </summary>
        public SapService()
        {
            try
            {
                _client = new Z_FI_RFC_WBS_UTIL();
                _clientRequest = new ZFiRfcWbsUtil();
                _clientResponse = new ZFiRfcWbsUtilResponse();

                _networkClient = new Z_FI_RFC_NW_UTIL();
                _networkRequest = new ZFiRfcNwUtil();
                _networkResponse = new ZFiRfcNwUtilResponse();

                _networkClientTasks = new Z_FI_RFC_NW_UTIL();
                _networkRequestTasks = new ZFiRfcNwUtil();
                _networkResponseTasks = new ZFiRfcNwUtilResponse();
            }
            catch (SapException exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        #endregion

        #region Connect to SAP

        /// <summary>
        /// Connects to sap WBS.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        public void ConnectToSapWbs(string userName, string password)
        {
            //Validate the credentials
            _client.PreAuthenticate = true;
            _client.Credentials = new NetworkCredential(userName, password);
        }

        /// <summary>
        /// Connects to sap network.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        public void ConnectToSapNetwork(string userName, string password)
        {
            //Validate the credentials
            _networkClient.PreAuthenticate = true;
            _networkClient.Credentials = new NetworkCredential(userName, password);
        }

        /// <summary>
        /// Connects to sap network for activity creation.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        public void ConnectToSapNetworkForActivityCreation(string userName, string password)
        {
            //Validate the credentials
            _networkClientTasks.PreAuthenticate = true;
            _networkClientTasks.Credentials = new NetworkCredential(userName, password);
        }
        #endregion

        #region Create WBS Element for Project as well as for all the Unique Task Descriptions

        /// <summary>
        /// Creates the WBS identifier.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="billingInformation">The billing information.</param>
        /// <param name="projectDefinition">The project definition.</param>
        /// <param name="projectName">Name of the project.</param>
        /// <returns></returns>
        public object CreateWbsId(string userName, string password, long requestId, string billingInformation,
            string projectDefinition, string projectName)
        {
            const string insertLogStmt = "INSERT INTO dbo.tbl_SAPLogs(RequestId, MessageId, MessageNumber, MessageText, MessageType, Method, ObjectType, UpdatedOn) " +
                                      "VALUES(@RequestId, @MessageId, @MessageNumber, @MessageText, @MessageType, @Method, @ObjectType,  @UpdatedOn)";

            const string insertStmt = "INSERT INTO dbo.tbl_SAP_WBSNetwork(RequestId, ProjectDefinition, ChargeCodeDescription, WorkCenter, IsParent, UpdatedOn) " +
                                      "VALUES(@RequestId, @ProjectDefinition, @ChargeCodeDescription, @WorkCenter, @IsParent, @UpdatedOn)";

            object objResponse = null;
            try
            {
                //Connect to SAP for WBS ID Service 
                ConnectToSapWbs(userName, password);

                //Response from first web request
                _clientRequest = CreateWbsRequest(billingInformation, projectDefinition, projectName);
                _clientResponse = _client.ZFiRfcWbsUtil(_clientRequest);

                //Need to add WBSID's to the DB in a temporary table
                if (_clientResponse.PMsgs[0].MessageType != "E")
                {
                    #region Add this in WBS Tool if performance issues here in future

                    //Fetch all the distinct Tasks based on the project name.

                    #region FetchingTaskList

                    //Connect to DB and based on Project Name get the Unique Task Description from the Task Table
                    var sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString);
                    var cmd = new SqlCommand("GetSAPProjectTaskWorkCenter", sqlConnection);
                    cmd.Parameters.AddWithValue("ProjectName", projectName); //Change this to ProjectName at later stage
                    cmd.CommandType = CommandType.StoredProcedure;
                    var adp = new SqlDataAdapter(cmd);
                    var dSet = new DataSet();
                    sqlConnection.Open();
                    cmd.ExecuteNonQuery();
                    adp.Fill(dSet);
                    sqlConnection.Close();

                    //Add a row with Project Name 
                    dSet.Tables[0].Columns.Add("IsParent", typeof(string));
                    var drProjectName = dSet.Tables[0].NewRow();
                    drProjectName["TaskDescription"] = projectName;
                    drProjectName["WorkCenter"] = null;
                    drProjectName["IsParent"] = "Yes";
                    dSet.Tables[0].Rows.Add(drProjectName);

                    // define the INSERT statement using **PARAMETERS**
                    // set up connection and command objects in ADO.NET
                    using (var conn =
                        new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    using (var commandInsert = new SqlCommand(insertStmt, conn))
                    {
                        // define parameters - ReportID is the same for each execution, so set value here
                        commandInsert.Parameters.Add("@RequestId", SqlDbType.Int).Value = requestId;
                        commandInsert.Parameters.Add("@ProjectDefinition", SqlDbType.NVarChar);
                        commandInsert.Parameters.Add("@ChargeCodeDescription", SqlDbType.NVarChar);
                        commandInsert.Parameters.Add("@WorkCenter", SqlDbType.NVarChar);
                        commandInsert.Parameters.Add("@IsParent", SqlDbType.NVarChar);
                        commandInsert.Parameters.Add("@UpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                        conn.Open();

                        //// iterate over all Reqeuest Id's and execute the INSERT statement for each of them
                        foreach (DataRow dr in dSet.Tables[0].Rows)
                        {
                            commandInsert.Parameters["@IsParent"].Value = dr["IsParent"].ToString();
                            if (dr["IsParent"].ToString() == "Yes")
                            {
                                commandInsert.Parameters["@IsParent"].Value = dr["IsParent"].ToString();
                            }
                            commandInsert.Parameters["@ProjectDefinition"].Value = projectDefinition;
                            commandInsert.Parameters["@ChargeCodeDescription"].Value = dr["TaskDescription"].ToString();
                            commandInsert.Parameters["@WorkCenter"].Value = dr["WorkCenter"].ToString();

                            commandInsert.ExecuteNonQuery();
                        }

                        conn.Close();
                    }

                    //string[] Gh = new string[dSet.Tables[0].Rows.Count];

                    #endregion

                    #region Temporary region for Work Centers QUETANJE

                    const string strWorkCenter = "QUETANJE";
                    using (var connection =
                        new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET WorkCenter='" + strWorkCenter +
                                              "' Where RequestId ='" + requestId + "' and IsParent <> 'Yes'";
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }

                    #endregion

                    #endregion

                    InsertSapLogs(insertLogStmt, requestId, _clientResponse);
                    using (var connection =
                        new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    using (var command = connection.CreateCommand())
                    {
                        foreach (var data in _clientResponse.PWbs)
                        {
                            command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET ChargeCode='" + data.Wbs +
                                                  "' Where ChargeCodeDescription ='" + data.Desc + "'";
                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                    }

                    objResponse = _clientResponse;
                }
                else
                {
                    //RequestId, MessageId, MessageNumber, MessageText, MessageType, Method, ObjectType, UpdatedOn
                    InsertSapLogs(insertLogStmt, requestId, _clientResponse);
                    return _clientResponse;
                }

                return _clientResponse;
            }

            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        #region Create Network Id based for the WBS Element that has been created

        /// <summary>
        /// Creates the network identifier.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="projectDefinition">The project definition.</param>
        /// <param name="projectName">Name of the project.</param>
        /// <param name="wbsElement">The WBS element.</param>
        /// <param name="projectStartDate">The project start date.</param>
        /// <param name="projectEndDate">The project end date.</param>
        /// <returns></returns>
        public object CreateNetworkId(string userName, string password, long requestId, string projectDefinition, string projectName, string wbsElement, DateTime projectStartDate, DateTime projectEndDate)
        {
            const string insertLogStmt = "INSERT INTO dbo.tbl_SAPLogs(RequestId, MessageId, MessageNumber, MessageText, MessageType, Method, ObjectType, UpdatedOn) " +
                                      "VALUES(@RequestId, @MessageId, @MessageNumber, @MessageText, @MessageType, @Method, @ObjectType,  @UpdatedOn)";

            try
            {
                //Need to call second service by passing the WBS ID along with Tasks for creating the network
                //Connect to SAP for WBS ID Service
                //
                ConnectToSapNetwork(userName, password);

                //Create Network
                _networkRequest = CreateNetworkRequest(wbsElement, projectDefinition, projectName, projectStartDate, projectEndDate);
                _networkResponse = _networkClient.ZFiRfcNwUtil(_networkRequest);
                
                if (_networkResponse.PMsgs[0].MessageText != "E")
                {
                    InsertSapLogsNetwork(insertLogStmt, requestId, _networkResponse);

                    //Update Network ID in DB based on Request ID
                    using (var connection =
                        new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET NetworkId='" + _networkResponse.PNetworks[0].Order +
                                              "' Where RequestId ='" + requestId + "'";
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }
                }
                else
                {
                    InsertSapLogsNetwork(insertLogStmt, requestId, _networkResponse);
                    return _networkResponse;
                }

                return _networkResponse;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        #region Create Network activity for all the Task Descrioptions that have been created
        /// <summary>
        /// Creates the network activity.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="projectDefinition">The project definition.</param>
        /// <param name="projectName">Name of the project.</param>
        /// <param name="wbsElement">The WBS element.</param>
        /// <param name="networkId">The network identifier.</param>
        /// <returns></returns>
        public object CreateNetworkActivity(string userName, string password, long requestId, string projectDefinition, string projectName, string wbsElement, string networkId)
        {
            const string insertLogStmt = "INSERT INTO dbo.tbl_SAPLogs(RequestId, MessageId, MessageNumber, MessageText, MessageType, Method, ObjectType, UpdatedOn) " +
                                      "VALUES(@RequestId, @MessageId, @MessageNumber, @MessageText, @MessageType, @Method, @ObjectType,  @UpdatedOn)";

            try
            {
                ConnectToSapNetworkForActivityCreation(userName, password);

                //Creater Network tasks
                _networkRequestTasks = CreateNetworkRequestTasks(networkId);
                _networkResponseTasks = _networkClientTasks.ZFiRfcNwUtil(_networkRequestTasks);

                object objResponse = null;
                if (_networkResponseTasks.PMsgs[0].MessageType != "E")
                {
                    InsertSapLogsNetwork(insertLogStmt, requestId, _networkResponseTasks);

                    using (var connection =
                    new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    using (var command = connection.CreateCommand())
                    {
                        foreach (var data in _networkResponseTasks.PNwActivity)
                        {
                            command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET ActivityNumber='" + data.Activity +
                                                  "' Where ChargeCodeDescription ='" + data.OperationShortText +
                                                  "' and WorkCenter ='" + data.WorkCenter + "' and ChargeCode ='" +
                                                  data.Wbs + "'";
                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                    }

                    objResponse = _networkResponseTasks;
                }
                else
                {
                    InsertSapLogsNetwork(insertLogStmt, requestId, _networkResponseTasks);
                    objResponse = _networkResponseTasks;
                    return _networkResponseTasks;
                }

                return objResponse;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion
        
        #region WSDL Methods for Creating the WBS Elements, Network Id and the Network Activities

        /// <summary>
        /// Creates the WBS request.
        /// </summary>
        /// <param name="billingInformation">The billing information.</param>
        /// <param name="projectDefinition">The project definition.</param>
        /// <param name="projectName">Name of the project.</param>
        /// <returns></returns>
        public static ZFiRfcWbsUtil CreateWbsRequest(string billingInformation, string projectDefinition, string projectName)
        {
            #region Actual Code
            var clientReq = new ZFiRfcWbsUtil();

            var hierarchyArray = new WbsHierarchie[1];
            var pstatusArray = new WbsMntSystemStatus[1];
            var ustatusArry = new WbsMntUserStatus[1];
            var mssgArry = new SAPWSDLReferenceWBSElement.MethMessage[1];
            string pIsChangeField = string.Empty;
            string pIsClosureField = string.Empty;

            var wbs = new ZpsWbsElement
            {
                Level = SapConstants.LevelOne,
                Parent = billingInformation,
                Project = projectDefinition,
                Desc = projectName,
                CostingSheet = SapConstants.CostingSheet,
                Plant = SapConstants.Plant,
                AccAssignment = SapConstants.AccAssignment,
                ProjectType = SapConstants.ProjectType,
                Priority = SapConstants.Priority
            };

            //Fetch all the distinct Tasks based on the project name.
            #region FetchingTaskList

            //Connect to DB and based on Project Name get the Unique Task Description from the Task Table
            var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString);
            connection.Open();

            var cmd = new SqlCommand("GetSAPDistinctProjectTasks", connection);
            cmd.Parameters.AddWithValue("ProjectName", projectName);
            cmd.CommandType = CommandType.StoredProcedure;
            var adp = new SqlDataAdapter(cmd);
            var dSet = new DataSet();

            cmd.ExecuteNonQuery();
            adp.Fill(dSet);

            #endregion

            var wbsarray = new ZpsWbsElement[dSet.Tables[0].Rows.Count + 1];

            //Assigning the parent element data to the wbarray
            wbsarray[0] = wbs;

            //Looping through the dataset to insert Tasks into the array
            foreach (var table in dSet.Tables)
            {
                var i = 0;
                var j = 1;
                foreach (DataRow row in dSet.Tables[0].Rows)
                {
                    //Adding values to the wbarray
                    var wbs1 = new ZpsWbsElement
                    {
                        Level = SapConstants.LevelTwo,
                        Parent = SapConstants.ParentLevelOne,
                        Project = projectDefinition,
                        Desc = row["TaskDescription"].ToString(),
                        CostingSheet = SapConstants.CostingSheet,
                        Plant = SapConstants.Plant,
                        AccAssignment = SapConstants.AccAssignment,
                        ProjectType = "",
                        Priority = ""
                    };


                    wbsarray[j] = wbs1;

                    i++;
                    j++;
                }
            }

            clientReq.PWbs = wbsarray;
            clientReq.PHierarchy = hierarchyArray;
            clientReq.PSysStatus = pstatusArray;
            clientReq.PUsrStatus = ustatusArry;
            clientReq.PMsgs = mssgArry;
            clientReq.PIsChange = pIsChangeField;
            clientReq.PIsClosure = pIsClosureField;

            return clientReq;

            #endregion
        }

        /// <summary>
        /// Creates the network request.
        /// </summary>
        /// <param name="wbsElement">The WBS element.</param>
        /// <param name="projectDefinition">The project definition.</param>
        /// <param name="projectName">Name of the project.</param>
        /// <param name="projectStartDate">The project start date.</param>
        /// <param name="projectEndDate">The project end date.</param>
        /// <returns></returns>
        public static ZFiRfcNwUtil CreateNetworkRequest(string wbsElement, string projectDefinition, string projectName, DateTime projectStartDate, DateTime projectEndDate)
        {
            var networkReq = new ZFiRfcNwUtil();

            var pMessageField = new SAPWSDLReferenceNetwork.MethMessage[1];


            var pNwActivityField = new ZpsNwActivity[1];
            var pNwStatusField = new ZpsNetworkStatus[1];

            //Connect to DB and based on Project Name get the Unique Task Description from the Task Table

            var networkItem = new ZpsNetworks
            {
                Order = "",
                OrderType = "ZS02",
                ShortText = projectName,
                Plant = "2930",
                WbsElement = wbsElement,
                ProjectDefinition = projectDefinition,
                MrpController = "G99",
                SchedulingType = "2"
                //BasicStartDate = projectStartDate.ToString("MM-dd-yyyy"),
                //BasicFinishDate = projectEndDate.ToString("MM-dd-yyyy")
            };

            var networkArray = new ZpsNetworks[1];
            networkArray[0] = networkItem;
            networkReq.PNetworks = networkArray;
            networkReq.PMsgs = pMessageField;
            networkReq.PNwActivity = pNwActivityField;
            networkReq.PNwStatus = pNwStatusField;

            return networkReq;
        }

        /// <summary>
        /// Creates the network request tasks.
        /// </summary>
        /// <param name="networkElement">The network element.</param>
        /// <returns></returns>
        private static ZFiRfcNwUtil CreateNetworkRequestTasks(string networkElement)
        {
            ZFiRfcNwUtil networkReq = new ZFiRfcNwUtil();

            ZpsNetworks[] networkArray = new ZpsNetworks[1];
            SAPWSDLReferenceNetwork.MethMessage[] pMessageField = new SAPWSDLReferenceNetwork.MethMessage[1];
            ZpsNwActivity[] pNwActivityField = new ZpsNwActivity[1];
            ZpsNetworkStatus[] pNwStatusField = new ZpsNetworkStatus[1];


            #region FetchingNetworkListTasks
            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString);
            connection.Open();

            SqlCommand cmd = new SqlCommand("GetSAPWBSNetworkTasks", connection);
            cmd.Parameters.AddWithValue("NetworkID", networkElement);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet dSet = new DataSet();

            cmd.ExecuteNonQuery();
            adp.Fill(dSet);


            pNwActivityField = new ZpsNwActivity[dSet.Tables[0].Rows.Count];

            //Looping through the dataset to insert Tasks into the array
            foreach (var table in dSet.Tables)
            {
                int i = 0;
                int j = 0;
                foreach (DataRow row in dSet.Tables[0].Rows)
                {
                    //Adding values to the wbarray
                    ZpsNwActivity nwActivity = new ZpsNwActivity
                    {
                        Order = row["NetworkId"].ToString(),
                        Activity = "",
                        ControlKey = "PS01",
                        WorkCenter = row["WorkCenter"].ToString(),
                        Plant = SapConstants.Plant,
                        OperationShortText = row["ChargeCodeDescription"].ToString(),
                        ActivityType = "EXP",
                        Wbs = row["ChargeCode"].ToString()
                    };

                    //Add Project Start Date and End Date

                    pNwActivityField[j] = nwActivity;

                    i++;
                    j++;
                }
            }

            networkReq.PNetworks = networkArray;
            networkReq.PMsgs = pMessageField;
            networkReq.PNwActivity = pNwActivityField;
            networkReq.PNwStatus = pNwStatusField;

            return networkReq;


            #endregion
        }

        #endregion

        #region Methods to Log all the SAP activities to the database. InsertSapLogs is used to Log SAP Activities for WBS Elements. InsertSapLogsNetwork is used for logging Netowrk ID and Network Activities

        /// <summary>
        /// Inserts the sap logs.
        /// </summary>
        /// <param name="insertLogStmt">The insert log statement.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="wbsReponse">The WBS reponse.</param>
        public static void InsertSapLogs(string insertLogStmt, long requestId, ZFiRfcWbsUtilResponse wbsReponse)
        {
            using (var conn =
                    new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
            using (var commandInsert = new SqlCommand(insertLogStmt, conn))
            {

                commandInsert.Parameters.Add("@RequestId", SqlDbType.Int).Value = requestId;
                commandInsert.Parameters.Add("@MessageId", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@MessageNumber", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@MessageText", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@MessageType", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@Method", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@ObjectType", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@UpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                foreach (var item in wbsReponse.PMsgs)
                {
                    commandInsert.Parameters["@MessageId"].Value = item.MessageId;
                    commandInsert.Parameters["@MessageNumber"].Value = item.MessageNumber;
                    commandInsert.Parameters["@MessageText"].Value = item.MessageText;
                    commandInsert.Parameters["@MessageType"].Value = item.MessageType;
                    commandInsert.Parameters["@Method"].Value = item.Method;
                    commandInsert.Parameters["@ObjectType"].Value = item.ObjectType;

                    conn.Open();
                    commandInsert.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }

        /// <summary>
        /// Inserts the sap logs network.
        /// </summary>
        /// <param name="insertLogStmt">The insert log statement.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="networkReponse">The network reponse.</param>
        public static void InsertSapLogsNetwork(string insertLogStmt, long requestId, ZFiRfcNwUtilResponse networkReponse)
        {
            using (var conn =
                    new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
            using (var commandInsert = new SqlCommand(insertLogStmt, conn))
            {
                commandInsert.Parameters.Add("@RequestId", SqlDbType.Int).Value = requestId;
                commandInsert.Parameters.Add("@MessageId", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@MessageNumber", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@MessageText", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@MessageType", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@Method", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@ObjectType", SqlDbType.NVarChar);
                commandInsert.Parameters.Add("@UpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                foreach (var item in networkReponse.PMsgs)
                {
                    commandInsert.Parameters["@MessageId"].Value = item.MessageId;
                    commandInsert.Parameters["@MessageNumber"].Value = item.MessageNumber;
                    commandInsert.Parameters["@MessageText"].Value = item.MessageText;
                    commandInsert.Parameters["@MessageType"].Value = item.MessageType;
                    commandInsert.Parameters["@Method"].Value = item.Method;
                    commandInsert.Parameters["@ObjectType"].Value = item.ObjectType;

                    conn.Open();
                    commandInsert.ExecuteNonQuery();
                    conn.Close();
                }
            }
        } 
        #endregion
    }
}