﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAP.WSDLService.DTO
{
    public class BAPI_METH_MESSAGE
    {
        private string mETHODField;

        private string oBJECT_TYPEField;

        private string iNTERNAL_OBJECT_IDField;

        private string eXTERNAL_OBJECT_IDField;

        private string mESSAGE_IDField;

        private string mESSAGE_NUMBERField;

        private string mESSAGE_TYPEField;

        private string mESSAGE_TEXTField;
    }
}
