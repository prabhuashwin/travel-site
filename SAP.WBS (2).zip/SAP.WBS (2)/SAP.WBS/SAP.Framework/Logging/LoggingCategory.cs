﻿namespace SAP.Framework.Logging
{
    /// <summary>
    /// 
    /// </summary>
    public enum LoggingCategory
    {
        /// <summary>
        /// Error Category.
        /// </summary>
        Error,

        /// <summary>
        /// Event Category.
        /// </summary>
        Event,

        /// <summary>
        /// The performance parameter logger.
        /// </summary>
        PerformanceParam
    }
}