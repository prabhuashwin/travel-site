﻿using SAP.DTO;

namespace SAP.Framework.Exception
{
    /// <summary />
    /// <seealso cref="System.Exception" />
    public class SapException : System.Exception
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="SapException" /> class.
        /// </summary>
        public SapException()
        {
            Result = new OperationResult();
        }


        /// <summary>
        ///     Initializes a new instance of the <see cref="SapException" /> class.
        /// </summary>
        /// <param name="code">The code.</param>
        /// <param name="message">The message.</param>
        public SapException(MessageCode code, string message)
            : base(message)
        {
            Result = new OperationResult {Success = false, MCode = code, Message = message};
        }


        /// <summary>
        ///     Gets or sets the result.
        /// </summary>
        /// <value>
        ///     The result.
        /// </value>
        public OperationResult Result { get; set; }
    }
}