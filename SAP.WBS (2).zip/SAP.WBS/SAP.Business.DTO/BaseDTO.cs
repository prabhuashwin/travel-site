﻿using System;
using System.Globalization;

namespace SAP.Business.DTO
{
    /// <summary>
    /// 
    /// </summary>
    public class BaseDto
    {
        /// <summary>
        /// Gets the modified date time string.
        /// </summary>
        /// <value>
        /// The modified date time string.
        /// </value>
        public string ModifiedDateTimeStr =>
            ModifiedDateTime.ToString("yyyy MM dd HH mm ss", CultureInfo.InvariantCulture);

        /// <summary>
        /// Gets the created date time string.
        /// </summary>
        /// <value>
        /// The created date time string.
        /// </value>
        public string CreatedDateTimeStr =>
            CreatedDateTime.ToString("yyyy MM dd HH mm ss", CultureInfo.InvariantCulture);

        /// <summary>
        /// Gets or sets the modified date time.
        /// </summary>
        /// <value>
        /// The modified date time.
        /// </value>
        public DateTime ModifiedDateTime { get; set; }

        /// <summary>
        /// Gets or sets the created date time.
        /// </summary>
        /// <value>
        /// The created date time.
        /// </value>
        public DateTime CreatedDateTime { get; set; }
    }
}