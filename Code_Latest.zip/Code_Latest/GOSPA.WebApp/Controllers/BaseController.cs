﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Security.Principal;
using GOSPA.WebApp.SiteHelpers;

namespace GOSPA.WebApp.Controllers
{
    public class BaseController : Controller
    {
        private Exception currentException;


        protected Models.UserViewModel currentUser;


        private MyIdentity myIdentity;


        private MyPrincipal myPrincipal;


        protected String UserId;



        public BaseController()
        {
            currentUser = Session != null ? Session.GetCurrentUser() : null;
        }

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <value>
        /// The user.
        /// </value>
        /// Added for impersonation
        new public IPrincipal User
        { // override User for impersonation
            get
            {
                if ((!string.IsNullOrEmpty(this.UserId)) || (Session["UserId"] != null))
                {
                    if (Session["UserId"] == null)
                        Session["UserId"] = this.UserId;
                    if (this.UserId == null)
                        this.UserId = Session["UserId"].ToString();

                    myIdentity = new MyIdentity(this.UserId, "", true, new Guid());
                    myPrincipal = new MyPrincipal(myIdentity);

                    return myPrincipal;
                }
                else
                {
                    return base.User;
                }
            }
        }
        public ActionResult ExceptionPage(Exception exception, int errorType)
        {
            return View(exception);
        }
    }
}