﻿using GOSPA.Business;
using GOSPA.Common.DTO;
using GOSPA.ExceptionHandler.Exception;
using SAP.Framework.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using GOSPA.WebApp.SiteHelpers;
using System.Configuration;
using System.Text;
using GOSPA.WebApp.Models;
using System.Collections;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using System.Globalization;
using GOSPA.DataModels;
using System.Data.SqlClient;
using System.Data;
using Newtonsoft.Json.Linq;

using System.IO;
using OfficeOpenXml;
using OfficeOpenXml.Style;


namespace GOSPA.WebApp.Controllers
{
    public class HomeController : BaseController
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        public ActionResult Index()
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                return View();
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #region LoginSection

        /// <summary>
        /// Logins the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult Login(string id)
        {
            try
            {
                base.UserId = id;
                ViewData["UserId"] = id;

                var operationResult = new UserManager().GetUserDetailsWindows(User.Identity.Name);
                Session["LoginId"] = operationResult.iID;
                Session["CurrentRole"] = operationResult.iARoleId;
                ViewBag.CurrentRole = Session["CurrentRole"];

                if (operationResult.iID > 0)
                {
                    if (operationResult.dStatus == Convert.ToBoolean(UserActiveStatus.Active))
                    {
                        ///Fetch the current Week
                        DateTime dtPassed = DateTime.Now;
                        CultureInfo ciCurr = CultureInfo.CurrentCulture;
                        int weekNum = ciCurr.Calendar.GetWeekOfYear(dtPassed, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

                                                IList<SelectListItem> WeekData = new List<SelectListItem>
                        {
                            new SelectListItem() {Text="Week2",Value="2" }
                        };
                        ViewBag.WeekIds = WeekData;
                        //Build the ddl for the Actual/Estimate
                        ///Get the corresponding Value stream for the OpsUser
                        if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                        {
                            ///If Ops User fetch the Value stream of respective Ops user
                            var valueStream = new UserManager().GetOpsUSerValueStream(operationResult.iID,
                                                                                      (int)UserRoleTypes.OPSUser);

                            var vsdata = ((IEnumerable)valueStream.Data).Cast<Common.DTO.GetOpsUserList>().ToList();

                            Session["OpsUserVs"] = vsdata[0].iVSID;
                            Session["OpsUserVsValue"] = vsdata[0].vcValueStream;
                        }
                        if (operationResult.RoleId != null)
                        {
                            var roleResult = new UserManager().GetUserRoles(operationResult.iID);

                            //List<string> strrolelist = new List<string>();
                            //foreach (var r in roleResult)
                            //{
                            //    UserRoleTypes resRole;
                            //    int val = r;

                            //    resRole = (UserRoleTypes)Enum.Parse(typeof(UserRoleTypes), val.ToString());

                            //    strrolelist.Add(resRole.ToString());
                            //}

                            //var roleList = strrolelist;

                            ////var roleList = new List<string> { "Ops User", "Financial Controller", "LeaderShip Team" };

                            //List<String> preferences = new List<String> { "Ops User", "Financial Controller", "LeaderShip Team" };

                            //IEnumerable<String> orderedData = roleList.OrderBy(item => preferences.IndexOf(item));

                            //Session["RoleList"] = orderedData;

                            //ViewBag.AllRoles = Session["RoleList"];

                            //Added
                            Session["rololeids"] = operationResult.RoleId;
                            Session["Workinguser"] = operationResult.iID;
                            //Added


                            List<string> strrolelist = new List<string>();
                            foreach (var r in roleResult)
                            {
                                UserRoleTypes resRole;
                                int val = r;

                                resRole = (UserRoleTypes)Enum.Parse(typeof(UserRoleTypes), val.ToString());

                                strrolelist.Add(resRole.ToString());
                            }

                            var roleList = strrolelist;

                            //var roleList = new List<string> { "Ops User", "Financial Controller", "LeaderShip Team" };

                            List<String> preferences = new List<String> { "Ops User", "Financial Controller", "LeaderShip Team", "SBU Head" };

                            IEnumerable<String> orderedData = roleList.OrderBy(item => preferences.IndexOf(item));

                            Session["RoleList"] = orderedData;

                            ViewBag.AllRoles = Session["RoleList"];
                        }
                        var userName = User.Identity.Name.Substring(User.Identity.Name.IndexOf(@"\") + 1);

                        Session["CurrentUser"] = userName;
                        Session["CurrentRole"] = (UserRoleTypes)Enum.Parse(typeof(UserRoleTypes), operationResult.iARoleId.ToString());

                        return RedirectToAction("Index");
                    }
                    else
                        return RedirectToAction("UnauthorizeAccess");
                }
                else
                    return RedirectToAction("Register");
                //var s = @"utcain\";
                //var r = s.Substring(s.IndexOf(@"\") + 1);
                //GOSPA.WebApp.SiteHelpers.OrgNameSearch srch = new SiteHelpers.OrgNameSearch();
                //var result = srch.SearchUserDetails(model.Name.Substring(s.IndexOf(@"\") + 1));

                //var usr = UserService.Find(x => x.WindowsId.Equals(User.Identity.Name.ToUpper())).SingleOrDefault();

                //OperationResult operationResult = new OperationResult();

                //operationResult = new UserManager().RegisterUser(user.EmailId, user.Name);

                //return RedirectToAction("Index");
                //return View();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// Searches the user.
        /// </summary>
        /// <param name="firstName">The first name.</param>
        /// <param name="lastName">The last name.</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SearchUser(string firstName, string lastName)
        {
            try
            {
                GOSPA.WebApp.SiteHelpers.OrgNameSearch srch = new SiteHelpers.OrgNameSearch();
                return Json(srch.SearchAllUserDetails(firstName, lastName));
            }
            catch (Exception ex)
            {
                return Json(ex.ToString());
            }
        }

        /// <summary>
        /// Gets the windows user identifier.
        /// </summary>
        /// <returns></returns>
        //[AllowAnonymous]
        [HttpPost]
        public ActionResult GetWindowsUserId()
        {
            return Json(User.Identity.Name);
        }

        public ActionResult Register()
        {
            try
            {
                var enumData = from UserRoleTypes u in Enum.GetValues(typeof(UserRoleTypes))
                               where u.ToString() != "Admin"
                               select new
                               {
                                   ID = (int)u,
                                   Name = u.ToString()
                               };

                ViewBag.EnumList = new SelectList(enumData, "ID", "Name");

                return View();
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }

        }

        [HttpPost]
        public ActionResult Register(Models.UserViewModel model)
        {
            try
            {
                var s = @"utcain\";
                var r = s.Substring(s.IndexOf(@"\") + 1);
                OrgNameSearch srch = new SiteHelpers.OrgNameSearch();
                var result = srch.SearchUserDetails(model.Name.Substring(s.IndexOf(@"\") + 1));

                OperationResult operationResult = new OperationResult();
                operationResult = new UserManager().RegisterUser(result.Name, result.Email, model.RoleId, result.Title, result.WindowsId);

                if (operationResult.Success == true)
                {
                    TempData["RegSuccess"] = "Success";
                }

                ///Notification mail to Admin to approve the registration request
                //Email Configuration details
                string toreply = result.Email;
                string subject = "User requested for Admin Approval";
                string toAddress = ConfigurationManager.AppSettings["AdminMail"];
                string toCC = result.Email;

                UserRoleTypes resRole;
                int val = model.RoleId;

                resRole = (UserRoleTypes)Enum.Parse(typeof(UserRoleTypes), val.ToString());

                //string res= (UserRoleTypes)Enum.Parse(typeof(UserRoleTypes), model.RoleId).ToString();

                StringBuilder sb = new StringBuilder();
                sb.Append("<h2><center>Finance-GOSPA Tool: User Requested for Approval</center></h2>");
                sb.Append("<p>Hi Admin,</p> ");
                sb.Append("<p>User submitted the below registration request.</p>");
                sb.Append("<html><head><style> table, th, td {border: 1px solid black;}</style></head><body>");
                sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='4'><center><h4>User Details</h4></center></td></tr>");
                sb.Append("<tr><th>User Name</th><td colspan='3'>" + result.Name + "</ td ></ tr > ");
                sb.Append("<tr><th>User Email</th><td colspan='3'>" + result.Email + "</ td ></ tr > ");
                sb.Append("<tr><th>User Title</th><td colspan='3'>" + result.Title + "</ td ></ tr > ");
                sb.Append("<tr><th>User WindowsId</th><td colspan='3'>" + result.WindowsId + "</ td ></ tr > ");
                sb.Append("<tr><th>User Role</th><td colspan='3'>" + resRole + "</ td ></ tr > ");
                sb.Append("<tr><th>User Active Status</th><td colspan='3' style='background-color: #FFCCCB; '>InActive</ td ></ tr > ");
                sb.Append("</table></body></html>");

                //sb.Append("<br />Please click the link to open the project :<a href='" + urlLink + "'>click here</a>");
                sb.Append("<p>Regards, <br/>Finance-GOSPA Tool Team.</p>");

                var emailhelper = new EmailNotification();
                emailhelper.SendMailToAdmin(toreply, toAddress, toCC, subject, sb.ToString(), true);

                return new EmptyResult();
                //return Json(model, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// Unauthorizes the access.
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult UnauthorizeAccess()
        {
            return View();
        }


        [AllowAnonymous]
        public ActionResult Errorpage()
        {
            return View();
        }
        /// <summary>
        /// Logouts the specified role.
        /// </summary>
        /// <param name="Role">The role.</param>
        /// <returns></returns>
        public ActionResult Logout(string Role)
        {
            if (Role != null)
            {
                int selectedRole = Convert.ToInt32((UserRoleTypes)Enum.Parse(typeof(UserRoleTypes), Role.ToString()));

                ///Update the existing roleid as the changed roleId

                OperationResult operationResult = new OperationResult();

                var operationResult1 = new UserManager().GetUserDetailsWindows(User.Identity.Name);

                operationResult = new UserManager().UpdateUserActiveRole(operationResult1.iID, selectedRole);

                //check if selected role and current role are not the same

                return RedirectToAction("SwitchLogout");
            }
            else
            {
                this.Session.Abandon();
            }
            return View();
        }

        [AllowAnonymous]
        public ActionResult SwitchLogout()
        {
            return View();
        }

        #endregion

        #region FetchDataMethods        
        [HttpPost]
        public ActionResult getLIWeeksData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }
                Timeline = Convert.ToInt32(TimelineId);
                // Getting all grid data    
                OperationResult operationResult = new OperationResult();
                if (Convert.ToInt32(WeekId) == 0)
                {
                    operationResult = new LOVManager().GetGridDataActuals(vs, Convert.ToInt32(WeekId));
                }
                else
                {
                    operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);
                }
                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "Leading Indicators").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result, Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        [HttpPost]
        public ActionResult getResultsWeeksData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                Timeline = Convert.ToInt32(TimelineId);
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }

                //Getting all grid data    
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);

                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "Results").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        [HttpPost]
        public ActionResult getDemandWeeksData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                Timeline = Convert.ToInt32(TimelineId);
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }
                // Getting all grid data    
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);

                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "Demand").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        [HttpPost]
        public ActionResult getOutputWeeksData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                Timeline = Convert.ToInt32(TimelineId);
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }
                // Getting all grid data    
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);

                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "Output").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        [HttpPost]
        public ActionResult getOverdueWeeksData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                Timeline = Convert.ToInt32(TimelineId);
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }
                // Getting all grid data    
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);

                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "Overdue").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        [HttpPost]
        public ActionResult getDMPInputData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                Timeline = Convert.ToInt32(TimelineId);
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }
                // Getting all grid data    
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);

                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "DMP Input").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        [HttpPost]
        public ActionResult getInvbrkWeeksData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                Timeline = Convert.ToInt32(TimelineId);
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }
                // Getting all grid data    
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);

                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "Inventory Breakdown").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        [HttpPost]
        public ActionResult getHeadCountWeeksData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                Timeline = Convert.ToInt32(TimelineId);
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }
                // Getting all grid data    
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);

                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "Headcount").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        [HttpPost]
        public ActionResult getHoursWeeksData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                Timeline = Convert.ToInt32(TimelineId);
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }
                // Getting all grid data    
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);

                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "Hours").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        [HttpPost]
        public ActionResult getProdcWeeksData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                Timeline = Convert.ToInt32(TimelineId);
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }
                // Getting all grid data    
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);

                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "Productivity (%)").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        [HttpPost]
        public ActionResult getEbitWeeksData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                Timeline = Convert.ToInt32(TimelineId);
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }
                // Getting all grid data    
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);

                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "EBIT").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        [HttpPost]
        public ActionResult getCapexWeeksData(string ValueStream, string WeekId, string TimelineId)
        {
            try
            {
                //Fetching the Ops User Value stream
                int vs = 0;
                int Timeline = 0;
                Timeline = Convert.ToInt32(TimelineId);
                if (Convert.ToInt32(Session["CurrentRole"]) == (int)UserRoleTypes.OPSUser)
                {
                    vs = Convert.ToInt32(Session["OpsUserVs"]);
                }
                else
                {
                    vs = Convert.ToInt32(ValueStream);
                }
                // Getting all grid data    
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekId), Timeline);

                var result = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().Where(x => x.vcTypeName == "Capex").ToList();

                var joutput = new JavaScriptSerializer().Serialize(result);

                var json = JsonConvert.SerializeObject(result);

                var list = JsonConvert.SerializeObject(result,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

                return Content(list, "application/json");

            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// Update demand data
        /// </summary>
        /// <param name="jsonOfData">The jsonOfData identifier</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult SaveDataSheetData(List<GOSPA.Common.DTO.GetGriddata> jsonOfData)
        {
            try
            {
                var model = 0;

                //Looping all the jsonData to update the respective row data in tbl Weekdata
                OperationResult opsresult = new OperationResult();

                opsresult = new LOVManager().GetUserDetails1();
                var data = ((IEnumerable)opsresult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserId == Convert.ToInt32(Session["LoginId"])).Take(1).ToList();

                if (jsonOfData.Count > 0)
                {
                    for (int i = 0; i < jsonOfData.Count; i++)
                    {
                        opsresult = new LOVManager().UpdateDemandDet(jsonOfData[i].iWGDID,
                                                                     Convert.ToDouble(jsonOfData[i].iLE_HFM),
                                                                     Convert.ToDouble(jsonOfData[i].iMTD),
                                                                     Convert.ToDouble(jsonOfData[i].iEST),
                                                                     Convert.ToDouble(jsonOfData[i].iActuals),
                                                                     jsonOfData[i].Comments,
                                                                     Convert.ToInt32(Session["LoginId"]));
                    }
                    ///Updatating the Totals for the respective rows
                    opsresult = new LOVManager().UpdateLOVTotals(jsonOfData[0].iWeekID,
                                                                 jsonOfData[0].iVSID,
                                                                 jsonOfData[0].iTimelineID,
                                                                 jsonOfData[0].vcTypeName);
                    //Validate Req exists in tbl_GOSSheet,tbl_Request
                    opsresult = new LOVManager().ValidateReqSheet(jsonOfData[0].iTimelineID,
                                                                  jsonOfData[0].iVSID,
                                                                  jsonOfData[0].iWeekID);

                    if (opsresult.Data.ToString() == "False")
                    {
                        ///Insert into tbl_GOSSheet/tbl_Request/tbl_RequestHistory
                        opsresult = new LOVManager().InsertIntoRequest(jsonOfData[0].iTimelineID,
                                                                       jsonOfData[0].iVSID,
                                                                       jsonOfData[0].iWeekID,
                                                                       data[0].UserName,
                                                                       Convert.ToInt32(Session["LoginId"]),
                                                                       (int)Models.RequestStatus.Draft);
                    }
                    else
                    {
                        ///Insert into tbl_RequestHistory
                        opsresult = new LOVManager().InsertIntoReqHistory(jsonOfData[0].iTimelineID,
                                                                          jsonOfData[0].iVSID,
                                                                          jsonOfData[0].iWeekID,
                                                                          data[0].UserName,
                                                                          Convert.ToInt32(Session["LoginId"]),
                                                                          Convert.ToInt32(Session["CurrentRole"]));
                    }
                }
                return Json(model, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        public ActionResult FetchTimelineDetails(int Year, int MonthId)
        {
            //Getting TimeLine details   
            OperationResult operationResult = new OperationResult();
            operationResult = new LOVManager().FetchTimelineDetails(Year, MonthId);

            var m = operationResult.Data.ToString();

            return Json(m, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region OpsUser
        [HttpGet]
        public ActionResult MyDataSheet()
        {
            
            //var model = 0;
            ViewBag.AllRoles = Session["RoleList"];
            int vs = Convert.ToInt32(Session["OpsUserVs"]);
            //Getting all grid data
            //OperationResult operationResult = new OperationResult();
            //operationResult = new LOVManager().GetGridData(2, 2);

            //var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().ToList();
            //var model = data.AsEnumerable();
            DateTime todaysdate = DateTime.UtcNow;

            CultureInfo ciCurr = CultureInfo.CurrentCulture;
            int weekNum = ciCurr.Calendar.GetWeekOfYear(todaysdate, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

            ////Building the Weeklyddl dynamic
            OperationResult operationResult = new OperationResult();
            operationResult = new LOVManager().GetWeekData(todaysdate, vs);

            var wkdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetWeekList>().ToList();
            ViewBag.WeekData = wkdata.ToList();

            return View();
        }

        [HttpPost]
        public ActionResult MyDataSheet(int TimelineId, int WeekValue)
        {
            ViewBag.AllRoles = Session["RoleList"];
            int vs = Convert.ToInt32(Session["OpsUserVs"]);

            //Getting all Value stream data   
            OperationResult operationResult = new OperationResult();

            //Getting all grid data 
            operationResult = new LOVManager().GetGridData(vs, WeekValue, TimelineId);

            var data1 = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().ToList();
            var model = data1.AsEnumerable();

            //return View(model);
            return Json(model, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public ActionResult MyDynmDataSheet()
        {
            ViewBag.AllRoles = Session["RoleList"];
            int vs = Convert.ToInt32(Session["OpsUserVs"]);


            DateTime todaysdate = DateTime.UtcNow;

            CultureInfo ciCurr = CultureInfo.CurrentCulture;
            int weekNum = ciCurr.Calendar.GetWeekOfYear(todaysdate, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

            ////Building the Weeklyddl dynamic
            OperationResult operationResult = new OperationResult();
            operationResult = new LOVManager().GetWeekData(todaysdate, vs);

            var wkdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetWeekList>().ToList();
            ViewBag.WeekData = wkdata.ToList();

            return View();
        }


        public ActionResult CheckSubmitReqStatus(int WeekValue, int TimelineId)
        {
            ViewBag.AllRoles = Session["RoleList"];
            int ValuestreamId = Convert.ToInt32(Session["OpsUserVs"]);

            //Getting Request Status details   
            OperationResult operationResult = new OperationResult();
            operationResult = new LOVManager().CheckSubmitReqStatus(ValuestreamId, WeekValue, TimelineId);

            var m = operationResult.Data.ToString();

            return Json(m, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult OpsUserSubmit(List<GOSPA.Common.DTO.GetGriddata> jsonOfData)
        {
            var model = 0;
            OperationResult operationResult = new OperationResult();

            operationResult = new LOVManager().GetUserDetails1();
            var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserId == Convert.ToInt32(Session["LoginId"])).Take(1).ToList();

            if (jsonOfData != null)
            {
                if (jsonOfData.Count > 0)
                {
                    int iWeeKId = Convert.ToInt32(jsonOfData[0].iWeekID);
                    int TimelineId = Convert.ToInt32(jsonOfData[0].iTimelineID);
                    //Getting the Month Id
                    operationResult = new LOVManager().GetMonthValue(TimelineId);
                    var mId = Convert.ToInt32(operationResult.Data.ToString());

                    ///Getting the Month Name 
                    var cultureEn = "en-US";
                    var monthName = CultureInfo.CreateSpecificCulture(cultureEn).DateTimeFormat.GetAbbreviatedMonthName(mId);

                    //Updating status in the Request table
                    //Insert into ReqStakeHolder table
                    //Insert into Req History table
                    operationResult = new LOVManager().UpdateSubmitRequest(jsonOfData[0].iTimelineID,
                                                                           jsonOfData[0].iVSID,
                                                                           jsonOfData[0].iWeekID,
                                                                           data[0].UserName,
                                                                           Convert.ToInt32(Session["LoginId"]),
                                                                           (int)Models.RequestStatus.OpsSubmitted,
                                                                           Convert.ToInt32(Session["CurrentRole"]));


                    //Send mail to FC
                    StringBuilder sb = new StringBuilder();
                    sb.Append("<h2><center>Finance-GOSPA Tool: Ops User Submitted the datasheet for Approval</center></h2>");
                    sb.Append("<p>Hi Finance Controller Focals,</p> ");
                    sb.Append("<p>Ops user has submitted the datasheet for " + monthName + "-Week" + iWeeKId + " .</p>");
                    //sb.Append("<html><head><style> table, th, td {border: 1px solid black;}</style></head><body>");
                    //sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='4'><center><h4>Data sheet Details</h4></center></td></tr>");
                    //sb.Append("<tr><th>User Name</th><td colspan='3'>" + data[0].UserName + "</ td ></ tr > ");
                    //sb.Append("<tr><th>User Email</th><td colspan='3'>" + data[0].UserEmail + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Title</th><td colspan='3'>" + result.Title + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User WindowsId</th><td colspan='3'>" + result.WindowsId + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Role</th><td colspan='3'>" + resRole + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Active Status</th><td colspan='3' style='background-color: #FFCCCB; '>InActive</ td ></ tr > ");
                    //sb.Append("</table></body></html>");

                    ////sb.Append("<br />Please click the link to open the project :<a href='" + urlLink + "'>click here</a>");
                    sb.Append("<p>Regards, <br/>Finance-GOSPA Tool Team.</p>");

                    ///Get all Finance Controller users
                    operationResult = new LOVManager().GetFCLTUserDetails((int)Models.UserRoleTypes.FinancialController);
                    var FcUsers = ((IEnumerable)operationResult.Data).Cast<string>().ToList();
                    //var FcUsers = operationResult.Data.ToString();

                    string toreply = ConfigurationManager.AppSettings["ReplyToMail"];
                    string subject = "Ops User Submitted the datasheet for Approval";
                    string toAddress = FcUsers[0].ToString();
                    string toCC = data[0].UserEmail;

                    var emailhelper = new EmailNotification();
                    emailhelper.SendMailToAdmin(toreply, toAddress, toCC, subject, sb.ToString(), true);
                }
            }
            //return View();
            return Json(model, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region FinanceController

        public ActionResult MyQueueSheet()
        {
            ViewBag.AllRoles = Session["RoleList"];

            //Getting all Value stream data   
            OperationResult operationResult = new OperationResult();
            operationResult = new LOVManager().GetFCVSData(Convert.ToInt32(Session["LoginId"]));

            var vsdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetValueStreamList>().ToList();
            ViewBag.FCValueStream = vsdata.ToList();

            DateTime todaysdate = DateTime.UtcNow;

            CultureInfo ciCurr = CultureInfo.CurrentCulture;
            int weekNum = ciCurr.Calendar.GetWeekOfYear(todaysdate, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

            ////Building the Weeklyddl dynamic
            operationResult = new LOVManager().GetWeekData(todaysdate, 2);

            var wkdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetWeekList>().ToList();
            ViewBag.FCWeekData = wkdata.ToList();

            return View();
        }

        [HttpPost]
        public JsonResult MyQueueSheet(string ValueStream, string WeekValue)
        {
            ViewBag.AllRoles = Session["RoleList"];
            int vs = Convert.ToInt32(ValueStream);

            //Getting all Value stream data   
            OperationResult operationResult = new OperationResult();

            //Getting all grid data 
            operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekValue), 2);

            var data1 = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().ToList();
            var model = data1.AsEnumerable();

            //return View(model);
            return Json(model, JsonRequestBehavior.AllowGet);
        }

        public ActionResult FCCheckSubmitReqStatus(string ValueStream, string WeekId)
        {
            ViewBag.AllRoles = Session["RoleList"];
            int vs = Convert.ToInt32(ValueStream);

            //Getting Request Status details   
            OperationResult operationResult = new OperationResult();
            operationResult = new LOVManager().CheckSubmitReqStatus(vs, Convert.ToInt32(WeekId), 3);

            var m = operationResult.Data.ToString();

            return Json(m, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult FCUserSubmit(List<GOSPA.Common.DTO.GetGriddata> jsonOfData)
        {

            var model = 0;
            OperationResult operationResult = new OperationResult();

            operationResult = new LOVManager().GetUserDetails1();
            var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserId == Convert.ToInt32(Session["LoginId"])).Take(1).ToList();

            if (jsonOfData != null)
            {
                if (jsonOfData.Count > 0)
                {
                    int iWeeKId = Convert.ToInt32(jsonOfData[0].iWeekID);

                    operationResult = new LOVManager().UpdateSubmitRequest(jsonOfData[0].iTimelineID,
                                                                           jsonOfData[0].iVSID,
                                                                           jsonOfData[0].iWeekID,
                                                                           data[0].UserName,
                                                                           Convert.ToInt32(Session["LoginId"]),
                                                                           (int)Models.RequestStatus.OpsSubmitted,
                                                                           Convert.ToInt32(Session["CurrentRole"]));
                    //Send mail to LT
                    StringBuilder sb = new StringBuilder();
                    sb.Append("<h2><center>Finance-GOSPA Tool: Finance Controller User Submitted the datasheet for Approval</center></h2>");
                    sb.Append("<p>Hi Leadership Team Focals,</p> ");
                    sb.Append("<p>Finance Controller has submitted the datasheet for Jan-Week2" + iWeeKId + ".</p>");
                    //sb.Append("<html><head><style> table, th, td {border: 1px solid black;}</style></head><body>");
                    //sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='4'><center><h4>Data sheet Details</h4></center></td></tr>");
                    //sb.Append("<tr><th>User Name</th><td colspan='3'>" + data[0].UserName + "</ td ></ tr > ");
                    //sb.Append("<tr><th>User Email</th><td colspan='3'>" + data[0].UserEmail + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Title</th><td colspan='3'>" + result.Title + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User WindowsId</th><td colspan='3'>" + result.WindowsId + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Role</th><td colspan='3'>" + resRole + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Active Status</th><td colspan='3' style='background-color: #FFCCCB; '>InActive</ td ></ tr > ");
                    //sb.Append("</table></body></html>");

                    ////sb.Append("<br />Please click the link to open the project :<a href='" + urlLink + "'>click here</a>");
                    sb.Append("<p>Regards, <br/>Finance-GOSPA Tool Team.</p>");

                    ///Get all Finance Controller users
                    operationResult = new LOVManager().GetFCLTUserDetails((int)Models.UserRoleTypes.LeaderShipTeam);
                    var LTUsers = ((IEnumerable)operationResult.Data).Cast<string>().ToList();

                    string toreply = ConfigurationManager.AppSettings["ReplyToMail"];
                    string subject = "Finance Controller Submitted the datasheet for Approval";
                    string toAddress = LTUsers[0].ToString();
                    string toCC = data[0].UserEmail;

                    var emailhelper = new EmailNotification();
                    emailhelper.SendMailToAdmin(toreply, toAddress, toCC, subject, sb.ToString(), true);
                }
            }
            //return View();
            return Json(model, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult FCUserReject(List<GOSPA.Common.DTO.GetGriddata> jsonOfData)
        {
            var model = 0;
            ViewBag.AllRoles = Session["RoleList"];

            OperationResult operationResult = new OperationResult();

            if (jsonOfData != null)
            {
                if (jsonOfData.Count > 0)
                {
                    operationResult = new LOVManager().GetUserDetails1();
                    //Get FC User details
                    var FcDetails = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserId == Convert.ToInt32(Session["LoginId"])).Take(1).ToList();

                    ///Get the Ops user Details
                    operationResult = new LOVManager().GetOpsUserDetails(jsonOfData[0].iTimelineID,
                                                                         jsonOfData[0].iVSID,
                                                                         jsonOfData[0].iWeekID);

                    var OpsDetails = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().ToList();

                    //Update Req,ReqSH,ReqHis
                    operationResult = new LOVManager().UpdateRejectStatus(jsonOfData[0].iTimelineID,
                                                                          jsonOfData[0].iVSID,
                                                                          jsonOfData[0].iWeekID,
                                                                          FcDetails[0].UserName,
                                                                          Convert.ToInt32(Session["CurrentRole"]));
                    //Send mail to OpsUser
                    StringBuilder sb = new StringBuilder();
                    sb.Append("<h2><center>Finance-GOSPA Tool: Finance Controller User has rejected the datasheet for some changes.</center></h2>");
                    sb.Append("<p>Hi " + OpsDetails[0].UserName + ",</ p > ");
                    sb.Append("<p>Finance Controller has rejected the datasheet for Jan-Week" + jsonOfData[0].iWeekID + ".</ p > ");
                    //sb.Append("<html><head><style> table, th, td {border: 1px solid black;}</style></head><body>");
                    //sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='4'><center><h4>Data sheet Details</h4></center></td></tr>");
                    //sb.Append("<tr><th>User Name</th><td colspan='3'>" + data[0].UserName + "</ td ></ tr > ");
                    //sb.Append("<tr><th>User Email</th><td colspan='3'>" + data[0].UserEmail + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Title</th><td colspan='3'>" + result.Title + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User WindowsId</th><td colspan='3'>" + result.WindowsId + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Role</th><td colspan='3'>" + resRole + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Active Status</th><td colspan='3' style='background-color: #FFCCCB; '>InActive</ td ></ tr > ");
                    //sb.Append("</table></body></html>");

                    ////sb.Append("<br />Please click the link to open the project :<a href='" + urlLink + "'>click here</a>");
                    sb.Append("<p>Regards, <br/>Finance-GOSPA Tool Team.</p>");

                    /////Get all Finance Controller users
                    //operationResult = new LOVManager().GetFCLTUserDetails((int)Models.UserRoleTypes.LeaderShipTeam);
                    //var LTUsers = ((IEnumerable)operationResult.Data).Cast<string>().ToList();

                    string toreply = ConfigurationManager.AppSettings["ReplyToMail"];
                    string subject = "Finance Controller Rejected the datasheet for Changes";
                    string toAddress = OpsDetails[0].UserEmail.ToString();
                    string toCC = FcDetails[0].UserEmail;

                    var emailhelper = new EmailNotification();
                    emailhelper.SendMailToAdmin(toreply, toAddress, toCC, subject, sb.ToString(), true);
                }
            }

            return Json(model, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region LeadershipTeam
        public ActionResult MyLTQueueSheet()
        {
            ViewBag.AllRoles = Session["RoleList"];

            //Getting all Value stream data   
            OperationResult operationResult = new OperationResult();
            operationResult = new LOVManager().GetVSData();
            //operationResult = new LOVManager().GetFCVSData(Convert.ToInt32(Session["LoginId"]));
            var vsdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetValueStreamList>().ToList();
            ViewBag.ValueStream = vsdata.ToList();

            DateTime todaysdate = DateTime.UtcNow;
            CultureInfo ciCurr = CultureInfo.CurrentCulture;
            int weekNum = ciCurr.Calendar.GetWeekOfYear(todaysdate, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

            ////Building the Weeklyddl dynamic
            operationResult = new LOVManager().GetWeekData(todaysdate, 2);

            var wkdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetWeekList>().ToList();
            ViewBag.LTWeekData = wkdata.ToList();

            return View();
        }

        [HttpPost]
        public ActionResult GetWeekList(int selectedVsid)
        {
            DateTime todaysdate = DateTime.UtcNow;
            CultureInfo ciCurr = CultureInfo.CurrentCulture;
            int weekNum = ciCurr.Calendar.GetWeekOfYear(todaysdate, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

            ////Building the Weeklyddl dynamic
            OperationResult operationResult = new OperationResult();
            operationResult = new LOVManager().GetWeekData(todaysdate, selectedVsid);

            var wkdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetWeekList>().ToList();
            ViewBag.LTWeekData = wkdata.ToList();

            return null;
        }

        [HttpPost]
        public JsonResult MyLTQueueSheet(string ValueStream, string WeekValue)
        {
            ViewBag.AllRoles = Session["RoleList"];
            int vs = Convert.ToInt32(ValueStream);

            //Getting all Value stream data   
            OperationResult operationResult = new OperationResult();

            //Getting all grid data 
            operationResult = new LOVManager().GetGridData(vs, Convert.ToInt32(WeekValue), 2);

            var data1 = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetGriddata>().ToList();
            var model = data1.AsEnumerable();

            //return View(model);
            return Json(model, JsonRequestBehavior.AllowGet);
        }

        public ActionResult LTCheckSubmitReqStatus(string ValueStream, string WeekId)
        {
            ViewBag.AllRoles = Session["RoleList"];
            int vs = Convert.ToInt32(ValueStream);

            //Getting Request Status details   
            OperationResult operationResult = new OperationResult();
            operationResult = new LOVManager().CheckSubmitReqStatus(vs, Convert.ToInt32(WeekId), 3);

            var m = operationResult.Data.ToString();

            return Json(m, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult LTUserSubmit(List<GOSPA.Common.DTO.GetGriddata> jsonOfData)
        {
            var model = 0;
            OperationResult operationResult = new OperationResult();

            operationResult = new LOVManager().GetUserDetails1();
            var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserId == Convert.ToInt32(Session["LoginId"])).Take(1).ToList();

            if (jsonOfData.Count > 0)
            {
                int iWeeKId = Convert.ToInt32(jsonOfData[0].iWeekID);

                operationResult = new LOVManager().UpdateSubmitRequest(jsonOfData[0].iTimelineID,
                                                                       jsonOfData[0].iVSID,
                                                                       jsonOfData[0].iWeekID,
                                                                       data[0].UserName,
                                                                       Convert.ToInt32(Session["LoginId"]),
                                                                       (int)Models.RequestStatus.OpsSubmitted,
                                                                       Convert.ToInt32(Session["CurrentRole"]));
                //Send mail to Ops User/FC
                StringBuilder sb = new StringBuilder();
                sb.Append("<h2><center>Finance-GOSPA Tool: Leadership Team has finalized the datasheet.</center></h2>");
                sb.Append("<p>Hi All Focals,</p> ");
                sb.Append("<p>Leadership Team has finalized the datasheet for Jan-Week" + iWeeKId + ".</p>");
                //sb.Append("<html><head><style> table, th, td {border: 1px solid black;}</style></head><body>");
                //sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='4'><center><h4>Data sheet Details</h4></center></td></tr>");
                //sb.Append("<tr><th>User Name</th><td colspan='3'>" + data[0].UserName + "</ td ></ tr > ");
                //sb.Append("<tr><th>User Email</th><td colspan='3'>" + data[0].UserEmail + "</ td ></ tr > ");
                ////sb.Append("<tr><th>Value Stream</th><td colspan='3'>" + Session[""]result.Title + "</ td ></ tr > ");
                ////sb.Append("<tr><th>User WindowsId</th><td colspan='3'>" + result.WindowsId + "</ td ></ tr > ");
                ////sb.Append("<tr><th>User Role</th><td colspan='3'>" + resRole + "</ td ></ tr > ");
                ////sb.Append("<tr><th>User Active Status</th><td colspan='3' style='background-color: #FFCCCB; '>InActive</ td ></ tr > ");
                //sb.Append("</table></body></html>");

                ////sb.Append("<br />Please click the link to open the project :<a href='" + urlLink + "'>click here</a>");
                sb.Append("<p>Regards, <br/>Finance-GOSPA Tool Team.</p>");

                ///Get all Finance Controller users
                operationResult = new LOVManager().GetFCLTUserDetails((int)Models.UserRoleTypes.LeaderShipTeam);
                var LTUsers = ((IEnumerable)operationResult.Data).Cast<string>().ToList();

                string toreply = ConfigurationManager.AppSettings["ReplyToMail"];
                string subject = "Leadership Submitted/Closed the datasheet.";
                string toAddress = LTUsers[0].ToString();
                string toCC = data[0].UserEmail;

                var emailhelper = new EmailNotification();
                emailhelper.SendMailToAdmin(toreply, toAddress, toCC, subject, sb.ToString(), true);
            }
            //return View();
            return Json(model, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult LTUserReject(List<GOSPA.Common.DTO.GetGriddata> jsonOfData)
        {
            var model = 0;
            ViewBag.AllRoles = Session["RoleList"];

            OperationResult operationResult = new OperationResult();

            if (jsonOfData != null)
            {
                if (jsonOfData.Count > 0)
                {
                    operationResult = new LOVManager().GetUserDetails1();
                    //Get LT User details
                    var LtDetails = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserId == Convert.ToInt32(Session["LoginId"])).Take(1).ToList();

                    ///Get the Ops user Details
                    operationResult = new LOVManager().GetOpsUserDetails(jsonOfData[0].iTimelineID,
                                                                         jsonOfData[0].iVSID,
                                                                         jsonOfData[0].iWeekID);

                    var OpsDetails = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().ToList();


                    ///Get the FC user Details
                    operationResult = new LOVManager().GetRejectFCUserDetails(jsonOfData[0].iTimelineID,
                                                                              jsonOfData[0].iVSID,
                                                                              jsonOfData[0].iWeekID);

                    var FcsDetails = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().ToList();

                    //Update Req,ReqSH,ReqHis
                    operationResult = new LOVManager().UpdateRejectStatus(jsonOfData[0].iTimelineID,
                                                                          jsonOfData[0].iVSID,
                                                                          jsonOfData[0].iWeekID,
                                                                          LtDetails[0].UserName,
                                                                          Convert.ToInt32(Session["CurrentRole"]));
                    //Send mail to OpsUser
                    StringBuilder sb = new StringBuilder();
                    sb.Append("<h2><center>Finance-GOSPA Tool: Leadership Team has rejected the datasheet for some changes.</center></h2>");
                    sb.Append("<p>Hi " + OpsDetails[0].UserName + ",</ p > ");
                    sb.Append("<p>Leadership Team has rejected the datasheet for Jan-Week" + jsonOfData[0].iWeekID + ".</ p > ");
                    //sb.Append("<html><head><style> table, th, td {border: 1px solid black;}</style></head><body>");
                    //sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='4'><center><h4>Data sheet Details</h4></center></td></tr>");
                    //sb.Append("<tr><th>User Name</th><td colspan='3'>" + data[0].UserName + "</ td ></ tr > ");
                    //sb.Append("<tr><th>User Email</th><td colspan='3'>" + data[0].UserEmail + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Title</th><td colspan='3'>" + result.Title + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User WindowsId</th><td colspan='3'>" + result.WindowsId + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Role</th><td colspan='3'>" + resRole + "</ td ></ tr > ");
                    ////sb.Append("<tr><th>User Active Status</th><td colspan='3' style='background-color: #FFCCCB; '>InActive</ td ></ tr > ");
                    //sb.Append("</table></body></html>");

                    ////sb.Append("<br />Please click the link to open the project :<a href='" + urlLink + "'>click here</a>");
                    sb.Append("<p>Regards, <br/>Finance-GOSPA Tool Team.</p>");

                    /////Get all Finance Controller users
                    //operationResult = new LOVManager().GetFCLTUserDetails((int)Models.UserRoleTypes.LeaderShipTeam);
                    //var LTUsers = ((IEnumerable)operationResult.Data).Cast<string>().ToList();

                    string toreply = ConfigurationManager.AppSettings["ReplyToMail"];
                    string subject = "Finance Controller Rejected the datasheet for Changes";
                    string toAddress = OpsDetails[0].UserEmail.ToString();
                    string toCC = LtDetails[0].UserEmail + "," + FcsDetails[0].UserEmail;

                    var emailhelper = new EmailNotification();
                    emailhelper.SendMailToAdmin(toreply, toAddress, toCC, subject, sb.ToString(), true);
                }
            }

            return Json(model, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Export_to_Excel
        [HttpPost]
        public void ExporttoexcelLeadingIndicator(string fileName, int iYearId)
        {

            GOSPA_TestEntities db_context = new GOSPA_TestEntities();
            DataTable dt = new DataTable();
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            ExcelPackage pck = new ExcelPackage();

            //var vs = db_context.GetValueStreamList();


            int iUserID = Convert.ToInt32(Session["LoginId"]);
            int roleid = Convert.ToInt32(Session["CurrentRole"]);

            dt = GetLeadingIndicatorConsolidateddatatableforExel(iYearId, roleid, iUserID);


            List<LeadingIndicatorUomeasure> li = new List<Common.DTO.LeadingIndicatorUomeasure>();

            li = GetUoMeasureLeadinindicatortableData(dt);
            dt = SiteHelpers.HelperExtentions.ToDataTable<LeadingIndicatorUomeasure>(li);


            string[] ColumnsToBeDeleted = { "UoMeasure", "iOrder" };

            foreach (string ColName in ColumnsToBeDeleted)
            {
                if (dt.Columns.Contains(ColName))
                    dt.Columns.Remove(ColName);
            }


            ExcelWorksheet ws = pck.Workbook.Worksheets.Add("LeadingIndicatorConsolidatedData");
            ws.Cells["A1:J1"].LoadFromDataTable(dt, true);
            ws.DefaultColWidth = 25;

            ws.Cells.Style.Border.Top.Style = ExcelBorderStyle.Thick;
            ws.Cells.Style.Border.Bottom.Style = ExcelBorderStyle.Thick;
            ws.Cells.Style.Border.Left.Style = ExcelBorderStyle.Thick;
            ws.Cells.Style.Border.Right.Style = ExcelBorderStyle.Thick;

            ws.Cells.Style.Border.Top.Color.SetColor(System.Drawing.Color.White);
            ws.Cells.Style.Border.Bottom.Color.SetColor(System.Drawing.Color.White);
            ws.Cells.Style.Border.Left.Color.SetColor(System.Drawing.Color.White);
            ws.Cells.Style.Border.Right.Color.SetColor(System.Drawing.Color.White);
            var headerCell = ws.Cells["A1:J1"];
            headerCell.Style.Fill.PatternType = ExcelFillStyle.Solid;
            headerCell.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.BurlyWood);
            var headerFont = headerCell.Style.Font;
            headerFont.Bold = true;
            int totalRow = ws.Dimension.End.Row;
            int totalCol = ws.Dimension.End.Column;

            ws.Cells["A1"].AutoFitColumns();
            ws.Cells[ws.Dimension.Address].AutoFitColumns();
            int i, j;
            //ws.Column(8).Style.Numberformat.Format = "MM/dd/yyyy";
            //ws.Column(9).Style.Numberformat.Format = "MM/dd/yyyy";
            for (i = 4; i <= 12; i++)
            {

                ws.Column(i).OutlineLevel = 1;

                ws.Column(i).Collapsed = true;
            }

            //using (ExcelRange rng = ws.Cells[1, 1, totalRow, totalCol])
            //{
            //    rng.Style.Border.Top.Style = ExcelBorderStyle.Thin;
            //    rng.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            //    rng.Style.Border.Left.Style = ExcelBorderStyle.Thin;
            //    rng.Style.Border.Right.Style = ExcelBorderStyle.Thin;

            //    rng.Style.Border.Top.Color.SetColor(System.Drawing.Color.Black);
            //    rng.Style.Border.Bottom.Color.SetColor(System.Drawing.Color.Black);
            //    rng.Style.Border.Left.Color.SetColor(System.Drawing.Color.Black);
            //    rng.Style.Border.Right.Color.SetColor(System.Drawing.Color.Black);
            //}

            using (MemoryStream MyMemoryStream = new MemoryStream())
            {
                // file name with .xlsx extension  
                //string p_strPath = "D:\\code\\SapTesting\\Test applicationForExcel\\flies\\geeksforgeeks.xlsx";
                //string p_strPath = "\\blrfs\\interiors\\PLM\\03_USERS\\Anaswara\\GOSPA\\19_jan\\geeksforgeeks.xlsx";
                //D:\GOSPA\ExcelSamples
                string p_strPath = "D:\\GOSPA\\ExcelSamples\\" + fileName + ".xlsx";

                if (System.IO.File.Exists(p_strPath))
                    System.IO.File.Delete(p_strPath);

                // Create excel file on physical disk  
                FileStream objFileStrm = System.IO.File.Create(p_strPath);
                objFileStrm.Close();

                // Write content to excel file  
                System.IO.File.WriteAllBytes(p_strPath, pck.GetAsByteArray());
                //Close Excel package 
                pck.Dispose();
                Console.ReadKey();
            }
        }

        [HttpPost]
        public void ExporttoexcelConsolidateddatasheet(string fileName, int vSID, int Year)
        {

            GOSPA_TestEntities db_context = new GOSPA_TestEntities();
            DataTable dt = new DataTable();
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            ExcelPackage pck = new ExcelPackage();

            var vs = db_context.GetValueStreamList();
            if (vSID == 0)
            {

                int monthId = DateTime.Now.Month;
                int weekId = GetWeekNumberOfMonth();
                OperationResult operationResult = new OperationResult();
                int iUserID = Convert.ToInt32(Session["LoginId"]);
                int roleid = Convert.ToInt32(Session["CurrentRole"]);

                string allValueStream = db_context.tbl_ValueStream.Where(p => p.iVSID == vSID).Select(x => x.vcValueStream).SingleOrDefault();
                dt = GetConsolidateddatatable(vSID, weekId, monthId, Year, roleid, iUserID);


                List<ConsolidatedData> li = new List<Common.DTO.ConsolidatedData>();

                li = GetUoMeasureConsolidatedtableData(dt);
                dt =  SiteHelpers.HelperExtentions.ToDataTable<ConsolidatedData>(li);

                string[] ColumnsToBeDeleted = { "UoMeasure", "iOrder" };

                foreach (string ColName in ColumnsToBeDeleted)
                {
                    if (dt.Columns.Contains(ColName))
                        dt.Columns.Remove(ColName);
                }
                //dt.Columns.Remove("UoMeasure");
                //dt.Columns.Remove("iOrder");
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("BLRSite");
                ws.Cells["A1:J1"].LoadFromDataTable(dt, true);
                ws.DefaultColWidth = 25;

                ws.Cells.Style.Border.Top.Style = ExcelBorderStyle.Thick;
                ws.Cells.Style.Border.Bottom.Style = ExcelBorderStyle.Thick;
                ws.Cells.Style.Border.Left.Style = ExcelBorderStyle.Thick;
                ws.Cells.Style.Border.Right.Style = ExcelBorderStyle.Thick;

                ws.Cells.Style.Border.Top.Color.SetColor(System.Drawing.Color.White);
                ws.Cells.Style.Border.Bottom.Color.SetColor(System.Drawing.Color.White);
                ws.Cells.Style.Border.Left.Color.SetColor(System.Drawing.Color.White);
                ws.Cells.Style.Border.Right.Color.SetColor(System.Drawing.Color.White);
                var headerCell = ws.Cells["A1:EN1"];
                headerCell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                headerCell.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.BurlyWood);
                var headerFont = headerCell.Style.Font;

                headerFont.Bold = true;
                int totalRow = ws.Dimension.End.Row;
                int totalCol = ws.Dimension.End.Column;

                ws.Cells["A1"].AutoFitColumns();
                ws.Cells[ws.Dimension.Address].AutoFitColumns();
                int i, j;
                //ws.Column(8).Style.Numberformat.Format = "MM/dd/yyyy";
                //ws.Column(9).Style.Numberformat.Format = "MM/dd/yyyy";
                for (i = 4; i <= 12; i++)
                {
                    ws.Column(i).OutlineLevel = 1;
                    ws.Column(i).Collapsed = true;
                }
            }

            foreach (var item in vs)
            {
                int monthId = DateTime.Now.Month;
                int weekId = GetWeekNumberOfMonth();
                OperationResult operationResult = new OperationResult();
                int iUserID = Convert.ToInt32(Session["LoginId"]);
                int roleid = Convert.ToInt32(Session["CurrentRole"]);

                int eachvsid = db_context.tbl_ValueStream.Where(p => p.vcValueStream == item.vcValueStream).Select(x => x.iVSID).SingleOrDefault();
                dt = GetConsolidateddatatable(eachvsid, weekId, monthId, Year, roleid, iUserID);


                List<ConsolidatedData> li = new List<Common.DTO.ConsolidatedData>();

                li = GetUoMeasureConsolidatedtableData(dt);
                dt = SiteHelpers.HelperExtentions.ToDataTable<ConsolidatedData>(li);

                string[] ColumnsToBeDeleted = { "UoMeasure", "iOrder" };

                foreach (string ColName in ColumnsToBeDeleted)
                {
                    if (dt.Columns.Contains(ColName))
                        dt.Columns.Remove(ColName);
                }

                //dt.Columns.Remove("UoMeasure");
                //dt.Columns.Remove("iOrder");

                ExcelWorksheet ws = pck.Workbook.Worksheets.Add(item.vcValueStream);
                ws.Cells["A1:J1"].LoadFromDataTable(dt, true);
                ws.DefaultColWidth = 25;

                ws.Cells.Style.Border.Top.Style = ExcelBorderStyle.Thick;
                ws.Cells.Style.Border.Bottom.Style = ExcelBorderStyle.Thick;
                ws.Cells.Style.Border.Left.Style = ExcelBorderStyle.Thick;
                ws.Cells.Style.Border.Right.Style = ExcelBorderStyle.Thick;

                ws.Cells.Style.Border.Top.Color.SetColor(System.Drawing.Color.White);
                ws.Cells.Style.Border.Bottom.Color.SetColor(System.Drawing.Color.White);
                ws.Cells.Style.Border.Left.Color.SetColor(System.Drawing.Color.White);
                ws.Cells.Style.Border.Right.Color.SetColor(System.Drawing.Color.White);
                var headerCell = ws.Cells["A1:EN1"];
                headerCell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                headerCell.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.BurlyWood);
                var headerFont = headerCell.Style.Font;

                headerFont.Bold = true;
                int totalRow = ws.Dimension.End.Row;
                int totalCol = ws.Dimension.End.Column;

                ws.Cells["A1"].AutoFitColumns();
                ws.Cells[ws.Dimension.Address].AutoFitColumns();
                int i, j;
                //ws.Column(8).Style.Numberformat.Format = "MM/dd/yyyy";
                //ws.Column(9).Style.Numberformat.Format = "MM/dd/yyyy";
                for (i = 4; i <= 12; i++)
                {
                    ws.Column(i).OutlineLevel = 1;
                    ws.Column(i).Collapsed = true;
                }

            }
            using (MemoryStream MyMemoryStream = new MemoryStream())
            {
                // file name with .xlsx extension                
                string p_strPath = "D:\\GOSPA\\ExcelSamples\\" + fileName + ".xlsx";

                if (System.IO.File.Exists(p_strPath))
                    System.IO.File.Delete(p_strPath);

                // Create excel file on physical disk  
                FileStream objFileStrm = System.IO.File.Create(p_strPath);
                objFileStrm.Close();

                // Write content to excel file  
                System.IO.File.WriteAllBytes(p_strPath, pck.GetAsByteArray());
                //Close Excel package 
                pck.Dispose();
                Console.ReadKey();

                //Response.Clear();
                //Response.Buffer = true;
                //Response.Charset = "";
                //Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //Response.AddHeader("content-disposition", "attachment;filename=PMOExport.xlsx");

                //pck.SaveAs(MyMemoryStream);
                //MyMemoryStream.WriteTo(Response.OutputStream);
                //Response.Flush();
                //Response.End();

            }

        }

        private DataTable GetConsolidateddatatable(int vs, int weekId, int monthId, int year, int roleid, int iUserID)
        {
            //SqlCommand cmd = new SqlCommand("GetConsolidated_GridData1_test2", con);
            SqlCommand cmd = new SqlCommand("GetConsolidated_GridData_All", con);

            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@VSID", vs);//vs //2
            //cmd.Parameters.AddWithValue("@Weekid", weekId);//weekId //2
            //cmd.Parameters.AddWithValue("@MonthId", monthId);//monthId //2    
            //cmd.Parameters.AddWithValue("@iYearId", year);//Year //2021
            //cmd.Parameters.AddWithValue("@iRoleID", roleid);//roleid //3
            //cmd.Parameters.AddWithValue("@iUserid", iUserID);//iUserID //84


            cmd.Parameters.AddWithValue("@VSID", 2);//vs //2
            cmd.Parameters.AddWithValue("@Weekid", 2);//weekId //2
            cmd.Parameters.AddWithValue("@MonthId", 2);//monthId //2    
            cmd.Parameters.AddWithValue("@iYearId", 2021);//Year //2021
            cmd.Parameters.AddWithValue("@iRoleID", 3);//roleid //3
            cmd.Parameters.AddWithValue("@iUserid", 84);//iUserID //84



            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt1 = new DataTable();
            da.Fill(ds);
            dt1 = ds.Tables[0];
            return dt1;
        }


        public DataTable GetLeadingIndicatorConsolidateddatatableforExel(int iYearId, int iRoleID, int iUserid)
        {
            SqlCommand cmd = new SqlCommand("GetConsolidated_LeadIndicator_Excel", con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@iYearId", iYearId);//vs //2
            cmd.Parameters.AddWithValue("@iRoleID", iRoleID);//weekId //2
            cmd.Parameters.AddWithValue("@iUserid", iUserid);//monthId //2    


            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt1 = new DataTable();
            da.Fill(ds);
            dt1 = ds.Tables[2];
            return dt1;
        }

        private List<ConsolidatedData> GetUoMeasureConsolidatedtableData(DataTable dt1)
        {
            List<ConsolidatedData> li = new List<ConsolidatedData>();
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                ConsolidatedData cd = new ConsolidatedData();

                if (dt1.Rows[i]["UoMeasure"].ToString() == "$")
                {

                    cd.vcTypeName = dt1.Rows[i]["vcTypeName"].ToString();
                    cd.vcLovName = dt1.Rows[i]["vcLovName"].ToString();
                    cd.Jan_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_act"].ToString();
                    cd.Jan_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_plan"].ToString();
                    cd.Jan_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_LeHFM"].ToString();
                    cd.Jan_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_priorPA"].ToString();
                    cd.Jan_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_MTD"].ToString();
                    cd.Jan_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_est"].ToString();
                    cd.Jan_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_iVP"].ToString();
                    cd.Jan_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_iVartoLEHFM"].ToString();
                    cd.Jan_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_iVartoPriorPA"].ToString();
                    cd.Jan_isActuals = dt1.Rows[i]["Jan_isActuals"].ToString();
                    cd.Feb_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_act"].ToString();
                    cd.Feb_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_plan"].ToString();
                    cd.Feb_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_LeHFM"].ToString();
                    cd.Feb_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_priorPA"].ToString();
                    cd.Feb_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_MTD"].ToString();
                    cd.Feb_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_est"].ToString();
                    cd.Feb_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_iVP"].ToString();
                    cd.Feb_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_iVartoLEHFM"].ToString();
                    cd.FEB_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_iVartoPriorPA"].ToString();
                    cd.Feb_isActuals = dt1.Rows[i]["Feb_isActuals"].ToString();
                    cd.Mar_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_act"].ToString();
                    cd.Mar_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_plan"].ToString();
                    cd.Mar_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_LeHFM"].ToString();
                    cd.Mar_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_priorPA"].ToString();
                    cd.Mar_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_MTD"].ToString();
                    cd.Mar_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_est"].ToString();
                    cd.Mar_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_iVP"].ToString();
                    cd.Mar_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_iVartoLEHFM"].ToString();
                    cd.Mar_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_iVartoPriorPA"].ToString();
                    cd.Mar_isActuals = dt1.Rows[i]["Mar_isActuals"].ToString();
                    cd.Apr_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_act"].ToString();
                    cd.Apr_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_plan"].ToString();
                    cd.Apr_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_LeHFM"].ToString();
                    cd.Apr_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_priorPA"].ToString();
                    cd.Apr_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_MTD"].ToString();
                    cd.Apr_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_est"].ToString();
                    cd.Apr_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_iVP"].ToString();
                    cd.Apr_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_iVartoLEHFM"].ToString();
                    cd.Apr_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_iVartoPriorPA"].ToString();
                    cd.Apr_isActuals = dt1.Rows[i]["Apr_isActuals"].ToString();
                    cd.May_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_act"].ToString();
                    cd.May_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_plan"].ToString();
                    cd.May_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_LeHFM"].ToString();
                    cd.May_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_priorPA"].ToString();
                    cd.May_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_MTD"].ToString();
                    cd.May_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_est"].ToString();
                    cd.May_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_iVP"].ToString();
                    cd.May_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_iVartoLEHFM"].ToString();
                    cd.May_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_iVartoPriorPA"].ToString();
                    cd.May_isActuals = dt1.Rows[i]["May_isActuals"].ToString();
                    cd.Jun_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_act"].ToString();
                    cd.Jun_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_plan"].ToString();
                    cd.Jun_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_LeHFM"].ToString();
                    cd.Jun_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_priorPA"].ToString();
                    cd.Jun_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_MTD"].ToString();
                    cd.Jun_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_est"].ToString();
                    cd.Jun_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_iVP"].ToString();
                    cd.Jun_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_iVartoLEHFM"].ToString();
                    cd.Jun_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_iVartoPriorPA"].ToString();
                    cd.Jun_isActuals = dt1.Rows[i]["Jun_isActuals"].ToString();
                    cd.Jul_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_act"].ToString();
                    cd.Jul_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_plan"].ToString();
                    cd.Jul_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_LeHFM"].ToString();
                    cd.Jul_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_priorPA"].ToString();
                    cd.Jul_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_MTD"].ToString();
                    cd.Jul_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_est"].ToString();
                    cd.Jul_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_iVP"].ToString();
                    cd.Jul_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_iVartoLEHFM"].ToString();
                    cd.Jul_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_iVartoPriorPA"].ToString();
                    cd.Jul_isActuals = dt1.Rows[i]["Jul_isActuals"].ToString();
                    cd.Aug_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_act"].ToString();
                    cd.Aug_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_plan"].ToString();
                    cd.Aug_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_LeHFM"].ToString();
                    cd.Aug_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_priorPA"].ToString();
                    cd.Aug_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_MTD"].ToString();
                    cd.Aug_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_est"].ToString();
                    cd.Aug_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_iVP"].ToString();
                    cd.Aug_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_iVartoLEHFM"].ToString();
                    cd.Aug_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_iVartoPriorPA"].ToString();
                    cd.Aug_isActuals = dt1.Rows[i]["Aug_isActuals"].ToString();
                    cd.Sep_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_act"].ToString();
                    cd.Sep_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_plan"].ToString();
                    cd.Sep_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_LeHFM"].ToString();
                    cd.Sep_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_priorPA"].ToString();
                    cd.Sep_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_MTD"].ToString();
                    cd.Sep_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_est"].ToString();
                    cd.Sep_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_iVP"].ToString();
                    cd.Sep_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_iVartoLEHFM"].ToString();
                    cd.Sep_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_iVartoPriorPA"].ToString();
                    cd.Sep_isActuals = dt1.Rows[i]["Sep_isActuals"].ToString();
                    cd.Oct_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_act"].ToString();
                    cd.Oct_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_plan"].ToString();
                    cd.Oct_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_LeHFM"].ToString();
                    cd.Oct_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_priorPA"].ToString();
                    cd.Oct_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_MTD"].ToString();
                    cd.Oct_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_est"].ToString();
                    cd.Oct_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_iVP"].ToString();
                    cd.Oct_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_iVartoLEHFM"].ToString();
                    cd.Oct_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_iVartoPriorPA"].ToString();
                    cd.Oct_isActuals = dt1.Rows[i]["Oct_isActuals"].ToString();
                    cd.Nov_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_act"].ToString();
                    cd.Nov_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_plan"].ToString();
                    cd.Nov_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_LeHFM"].ToString();
                    cd.Nov_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_priorPA"].ToString();
                    cd.Nov_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_MTD"].ToString();
                    cd.Nov_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_est"].ToString();
                    cd.Nov_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_iVP"].ToString();
                    cd.Nov_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_iVartoLEHFM"].ToString();
                    cd.Nov_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_iVartoPriorPA"].ToString();
                    cd.Nov_isActuals = dt1.Rows[i]["Nov_isActuals"].ToString();
                    cd.Dec_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_act"].ToString();
                    cd.Dec_plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_plan"].ToString();
                    cd.Dec_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_LeHFM"].ToString();
                    cd.Dec_priorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_priorPA"].ToString();
                    cd.Dec_MTD = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_MTD"].ToString();
                    cd.Dec_est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_est"].ToString();
                    cd.Dec_iVP = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_iVP"].ToString();
                    cd.Dec_iVartoLEHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_iVartoLEHFM"].ToString();
                    cd.Dec_iVartoPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_iVartoPriorPA"].ToString();
                    cd.Dec_isActuals = dt1.Rows[i]["Dec_isActuals"].ToString();
                    cd.Q1Plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q1Plan"].ToString();
                    cd.Q1Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q1Est"].ToString();
                    cd.Q1Variance = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q1Variance"].ToString();
                    cd.Q1_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q1_act"].ToString();
                    cd.Q1_isActuals = dt1.Rows[i]["Q1_isActuals"].ToString();
                    cd.Q2Plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q2Plan"].ToString();
                    cd.Q2Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q2Est"].ToString();
                    cd.Q2Variance = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q2Variance"].ToString();
                    cd.Q2_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q2_act"].ToString();
                    cd.Q2_isActuals = dt1.Rows[i]["Q2_isActuals"].ToString();
                    cd.Q3Plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q3Plan"].ToString();
                    cd.Q3Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q3Est"].ToString();
                    cd.Q3Variance = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q3Variance"].ToString();
                    cd.Q3_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q3_act"].ToString();
                    cd.Q3_isActuals = dt1.Rows[i]["Q3_isActuals"].ToString();
                    cd.Q4Plan = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q4Plan"].ToString();
                    cd.Q4Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q4Est"].ToString();
                    cd.Q4Variance = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q4Variance"].ToString();
                    cd.Q4_act = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Q4_act"].ToString();
                    cd.Q4_isActuals = dt1.Rows[i]["Q4_isActuals"].ToString();
                    cd.Comments = dt1.Rows[i]["Comments"].ToString();
                }
                else
                {
                    cd.vcTypeName = dt1.Rows[i]["vcTypeName"].ToString();
                    cd.vcLovName = dt1.Rows[i]["vcLovName"].ToString();
                    cd.Jan_act = dt1.Rows[i]["Jan_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_plan = dt1.Rows[i]["Jan_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_LeHFM = dt1.Rows[i]["Jan_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_priorPA = dt1.Rows[i]["Jan_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_MTD = dt1.Rows[i]["Jan_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_est = dt1.Rows[i]["Jan_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_iVP = dt1.Rows[i]["Jan_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_iVartoLEHFM = dt1.Rows[i]["Jan_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_iVartoPriorPA = dt1.Rows[i]["Jan_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_isActuals = dt1.Rows[i]["Jan_isActuals"].ToString();
                    cd.Feb_act = dt1.Rows[i]["Feb_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_plan = dt1.Rows[i]["Feb_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_LeHFM = dt1.Rows[i]["Feb_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_priorPA = dt1.Rows[i]["Feb_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_MTD = dt1.Rows[i]["Feb_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_est = dt1.Rows[i]["Feb_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_iVP = dt1.Rows[i]["Feb_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_iVartoLEHFM = dt1.Rows[i]["Feb_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.FEB_iVartoPriorPA = dt1.Rows[i]["Feb_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_isActuals = dt1.Rows[i]["Feb_isActuals"].ToString();
                    cd.Mar_act = dt1.Rows[i]["Mar_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_plan = dt1.Rows[i]["Mar_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_LeHFM = dt1.Rows[i]["Mar_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_priorPA = dt1.Rows[i]["Mar_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_MTD = dt1.Rows[i]["Mar_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_est = dt1.Rows[i]["Mar_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_iVP = dt1.Rows[i]["Mar_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_iVartoLEHFM = dt1.Rows[i]["Mar_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_iVartoPriorPA = dt1.Rows[i]["Mar_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_isActuals = dt1.Rows[i]["Mar_isActuals"].ToString();
                    cd.Apr_act = dt1.Rows[i]["Apr_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_plan = dt1.Rows[i]["Apr_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_LeHFM = dt1.Rows[i]["Apr_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_priorPA = dt1.Rows[i]["Apr_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_MTD = dt1.Rows[i]["Apr_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_est = dt1.Rows[i]["Apr_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_iVP = dt1.Rows[i]["Apr_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_iVartoLEHFM = dt1.Rows[i]["Apr_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_iVartoPriorPA = dt1.Rows[i]["Apr_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_isActuals = dt1.Rows[i]["Apr_isActuals"].ToString();
                    cd.May_act = dt1.Rows[i]["May_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_plan = dt1.Rows[i]["May_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_LeHFM = dt1.Rows[i]["May_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_priorPA = dt1.Rows[i]["May_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_MTD = dt1.Rows[i]["May_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_est = dt1.Rows[i]["May_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_iVP = dt1.Rows[i]["May_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_iVartoLEHFM = dt1.Rows[i]["May_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_iVartoPriorPA = dt1.Rows[i]["May_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_isActuals = dt1.Rows[i]["May_isActuals"].ToString();
                    cd.Jun_act = dt1.Rows[i]["Jun_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_plan = dt1.Rows[i]["Jun_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_LeHFM = dt1.Rows[i]["Jun_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_priorPA = dt1.Rows[i]["Jun_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_MTD = dt1.Rows[i]["Jun_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_est = dt1.Rows[i]["Jun_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_iVP = dt1.Rows[i]["Jun_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_iVartoLEHFM = dt1.Rows[i]["Jun_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_iVartoPriorPA = dt1.Rows[i]["Jun_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_isActuals = dt1.Rows[i]["Jun_isActuals"].ToString();
                    cd.Jul_act = dt1.Rows[i]["Jul_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_plan = dt1.Rows[i]["Jul_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_LeHFM = dt1.Rows[i]["Jul_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_priorPA = dt1.Rows[i]["Jul_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_MTD = dt1.Rows[i]["Jul_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_est = dt1.Rows[i]["Jul_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_iVP = dt1.Rows[i]["Jul_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_iVartoLEHFM = dt1.Rows[i]["Jul_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_iVartoPriorPA = dt1.Rows[i]["Jul_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_isActuals = dt1.Rows[i]["Jul_isActuals"].ToString();
                    cd.Aug_act = dt1.Rows[i]["Aug_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_plan = dt1.Rows[i]["Aug_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_LeHFM = dt1.Rows[i]["Aug_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_priorPA = dt1.Rows[i]["Aug_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_MTD = dt1.Rows[i]["Aug_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_est = dt1.Rows[i]["Aug_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_iVP = dt1.Rows[i]["Aug_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_iVartoLEHFM = dt1.Rows[i]["Aug_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_iVartoPriorPA = dt1.Rows[i]["Aug_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_isActuals = dt1.Rows[i]["Aug_isActuals"].ToString();
                    cd.Sep_act = dt1.Rows[i]["Sep_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_plan = dt1.Rows[i]["Sep_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_LeHFM = dt1.Rows[i]["Sep_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_priorPA = dt1.Rows[i]["Sep_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_MTD = dt1.Rows[i]["Sep_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_est = dt1.Rows[i]["Sep_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_iVP = dt1.Rows[i]["Sep_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_iVartoLEHFM = dt1.Rows[i]["Sep_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_iVartoPriorPA = dt1.Rows[i]["Sep_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_isActuals = dt1.Rows[i]["Sep_isActuals"].ToString();
                    cd.Oct_act = dt1.Rows[i]["Oct_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_plan = dt1.Rows[i]["Oct_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_LeHFM = dt1.Rows[i]["Oct_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_priorPA = dt1.Rows[i]["Oct_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_MTD = dt1.Rows[i]["Oct_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_est = dt1.Rows[i]["Oct_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_iVP = dt1.Rows[i]["Oct_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_iVartoLEHFM = dt1.Rows[i]["Oct_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_iVartoPriorPA = dt1.Rows[i]["Oct_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_isActuals = dt1.Rows[i]["Oct_isActuals"].ToString();
                    cd.Nov_act = dt1.Rows[i]["Nov_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_plan = dt1.Rows[i]["Nov_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_LeHFM = dt1.Rows[i]["Nov_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_priorPA = dt1.Rows[i]["Nov_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_MTD = dt1.Rows[i]["Nov_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_est = dt1.Rows[i]["Nov_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_iVP = dt1.Rows[i]["Nov_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_iVartoLEHFM = dt1.Rows[i]["Nov_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_iVartoPriorPA = dt1.Rows[i]["Nov_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_isActuals = dt1.Rows[i]["Nov_isActuals"].ToString();
                    cd.Dec_act = dt1.Rows[i]["Dec_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_plan = dt1.Rows[i]["Dec_plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_LeHFM = dt1.Rows[i]["Dec_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_priorPA = dt1.Rows[i]["Dec_priorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_MTD = dt1.Rows[i]["Dec_MTD"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_est = dt1.Rows[i]["Dec_est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_iVP = dt1.Rows[i]["Dec_iVP"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_iVartoLEHFM = dt1.Rows[i]["Dec_iVartoLEHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_iVartoPriorPA = dt1.Rows[i]["Dec_iVartoPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_isActuals = dt1.Rows[i]["Dec_isActuals"].ToString();
                    cd.Q1Plan = dt1.Rows[i]["Q1Plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q1Est = dt1.Rows[i]["Q1Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q1Variance = dt1.Rows[i]["Q1Variance"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q1_act = dt1.Rows[i]["Q1_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q1_isActuals = dt1.Rows[i]["Q1_isActuals"].ToString();
                    cd.Q2Plan = dt1.Rows[i]["Q2Plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q2Est = dt1.Rows[i]["Q2Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q2Variance = dt1.Rows[i]["Q2Variance"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q2_act = dt1.Rows[i]["Q2_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q2_isActuals = dt1.Rows[i]["Q2_isActuals"].ToString();
                    cd.Q3Plan = dt1.Rows[i]["Q3Plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q3Est = dt1.Rows[i]["Q3Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q3Variance = dt1.Rows[i]["Q3Variance"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q3_act = dt1.Rows[i]["Q3_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q3_isActuals = dt1.Rows[i]["Q3_isActuals"].ToString();
                    cd.Q4Plan = dt1.Rows[i]["Q4Plan"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q4Est = dt1.Rows[i]["Q4Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q4Variance = dt1.Rows[i]["Q4Variance"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q4_act = dt1.Rows[i]["Q4_act"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Q4_isActuals = dt1.Rows[i]["Q4_isActuals"].ToString();
                    cd.Comments = dt1.Rows[i]["Comments"].ToString();
                }
                li.Add(cd);
            }
            return li;
        }


        private List<LeadingIndicatorUomeasure> GetUoMeasureLeadinindicatortableData(DataTable dt1)
        {
            List<LeadingIndicatorUomeasure> li = new List<LeadingIndicatorUomeasure>();
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                LeadingIndicatorUomeasure cd = new LeadingIndicatorUomeasure();

                if (dt1.Rows[i]["UoMeasure"].ToString() == "$")
                {

                    cd.vcLOVName = dt1.Rows[i]["vcLOVName"].ToString();
                    cd.Jan_Evacs_Actuals = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_Evacs_Actuals"].ToString();
                    cd.Jan_Seats_Actuals = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_Seats_Actuals"].ToString();
                    cd.Jan_Lighting_Actuals = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_Lighting_Actuals"].ToString();
                    cd.Jan_Actuation_Actuals = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_Actuation_Actuals"].ToString();
                    cd.Jan_Avionics_Actuals = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_Avionics_Actuals"].ToString();
                    cd.Jan_Water_Actuals = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_Water_Actuals"].ToString();
                    cd.Jan_TotalActuals = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jan_TotalActuals"].ToString();
                    cd.Feb_Evacs_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Evacs_LeHFM"].ToString();
                    cd.Feb_Seats_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Seats_LeHFM"].ToString();
                    cd.Feb_Lighting_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Lighting_LeHFM"].ToString();
                    cd.Feb_Actuation_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Actuation_LeHFM"].ToString();
                    cd.Feb_Avionics_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Avionics_LeHFM"].ToString();
                    cd.Feb_Water_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Water_LeHFM"].ToString();
                    cd.Feb_TotalLeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_TotalLeHFM"].ToString();
                    cd.Feb_Evacs_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Evacs_Est"].ToString();
                    cd.Feb_Seats_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Seats_Est"].ToString();
                    cd.Feb_Lighting_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Lighting_Est"].ToString();
                    cd.Feb_Actuation_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Actuation_Est"].ToString();
                    cd.Feb_Avionics_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Avionics_Est"].ToString();
                    cd.Feb_Water_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Water_Est"].ToString();
                    cd.Feb_TotalEstimate = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_TotalEstimate"].ToString();
                    cd.Feb_Evacs_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Evacs_PriorPa"].ToString();
                    cd.Feb_Seats_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Seats_PriorPa"].ToString();
                    cd.Feb_Lighting_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Lighting_PriorPa"].ToString();
                    cd.Feb_Actuation_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Actuation_PriorPa"].ToString();
                    cd.Feb_Avionics_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Avionics_PriorPa"].ToString();
                    cd.Feb_Water_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_Water_PriorPa"].ToString();
                    cd.Feb_TotalPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Feb_TotalPriorPA"].ToString();
                    cd.Mar_Evacs_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Evacs_LeHFM"].ToString();
                    cd.Mar_Seats_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Seats_LeHFM"].ToString();
                    cd.Mar_Lighting_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Lighting_LeHFM"].ToString();
                    cd.Mar_Actuation_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Actuation_LeHFM"].ToString();
                    cd.Mar_Avionics_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Avionics_LeHFM"].ToString();
                    cd.Mar_Water_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Water_LeHFM"].ToString();
                    cd.Mar_TotalLeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_TotalLeHFM"].ToString();
                    cd.Mar_Evacs_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Evacs_Est"].ToString();
                    cd.Mar_Seats_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Seats_Est"].ToString();
                    cd.Mar_Lighting_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Lighting_Est"].ToString();
                    cd.Mar_Actuation_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Actuation_Est"].ToString();
                    cd.Mar_Avionics_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Avionics_Est"].ToString();
                    cd.Mar_Water_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Water_Est"].ToString();
                    cd.Mar_TotalEstimate = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_TotalEstimate"].ToString();
                    cd.Mar_Evacs_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Evacs_PriorPa"].ToString();
                    cd.Mar_Seats_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Seats_PriorPa"].ToString();
                    cd.Mar_Lighting_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Lighting_PriorPa"].ToString();
                    cd.Mar_Actuation_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Actuation_PriorPa"].ToString();
                    cd.Mar_Avionics_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Avionics_PriorPa"].ToString();
                    cd.Mar_Water_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_Water_PriorPa"].ToString();
                    cd.Mar_TotalPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Mar_TotalPriorPA"].ToString();
                    cd.Apr_Evacs_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Evacs_LeHFM"].ToString();
                    cd.Apr_Seats_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Seats_LeHFM"].ToString();
                    cd.Apr_Lighting_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Lighting_LeHFM"].ToString();
                    cd.Apr_Actuation_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Actuation_LeHFM"].ToString();
                    cd.Apr_Avionics_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Avionics_LeHFM"].ToString();
                    cd.Apr_Water_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Water_LeHFM"].ToString();
                    cd.Apr_TotalLeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_TotalLeHFM"].ToString();
                    cd.Apr_Evacs_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Evacs_Est"].ToString();
                    cd.Apr_Seats_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Seats_Est"].ToString();
                    cd.Apr_Lighting_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Lighting_Est"].ToString();
                    cd.Apr_Actuation_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Actuation_Est"].ToString();
                    cd.Apr_Avionics_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Avionics_Est"].ToString();
                    cd.Apr_Water_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Water_Est"].ToString();
                    cd.Apr_TotalEstimate = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_TotalEstimate"].ToString();
                    cd.Apr_Evacs_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Evacs_PriorPa"].ToString();
                    cd.Apr_Seats_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Seats_PriorPa"].ToString();
                    cd.Apr_Lighting_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Lighting_PriorPa"].ToString();
                    cd.Apr_Actuation_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Actuation_PriorPa"].ToString();
                    cd.Apr_Avionics_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Avionics_PriorPa"].ToString();
                    cd.Apr_Water_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_Water_PriorPa"].ToString();
                    cd.Apr_TotalPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Apr_TotalPriorPA"].ToString();
                    cd.May_Evacs_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Evacs_LeHFM"].ToString();
                    cd.May_Seats_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Seats_LeHFM"].ToString();
                    cd.May_Lighting_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Lighting_LeHFM"].ToString();
                    cd.May_Actuation_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Actuation_LeHFM"].ToString();
                    cd.May_Avionics_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Avionics_LeHFM"].ToString();
                    cd.May_Water_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Water_LeHFM"].ToString();
                    cd.May_TotalLeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_TotalLeHFM"].ToString();
                    cd.May_Evacs_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Evacs_Est"].ToString();
                    cd.May_Seats_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Seats_Est"].ToString();
                    cd.May_Lighting_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Lighting_Est"].ToString();
                    cd.May_Actuation_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Actuation_Est"].ToString();
                    cd.May_Avionics_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Avionics_Est"].ToString();
                    cd.May_Water_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Water_Est"].ToString();
                    cd.May_TotalEstimate = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_TotalEstimate"].ToString();
                    cd.May_Evacs_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Evacs_PriorPa"].ToString();
                    cd.May_Seats_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Seats_PriorPa"].ToString();
                    cd.May_Lighting_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Lighting_PriorPa"].ToString();
                    cd.May_Actuation_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Actuation_PriorPa"].ToString();
                    cd.May_Avionics_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Avionics_PriorPa"].ToString();
                    cd.May_Water_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_Water_PriorPa"].ToString();
                    cd.May_TotalPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["May_TotalPriorPA"].ToString();
                    cd.Jun_Evacs_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Evacs_LeHFM"].ToString();
                    cd.Jun_Seats_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Seats_LeHFM"].ToString();
                    cd.Jun_Lighting_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Lighting_LeHFM"].ToString();
                    cd.Jun_Actuation_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Actuation_LeHFM"].ToString();
                    cd.Jun_Avionics_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Avionics_LeHFM"].ToString();
                    cd.Jun_Water_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Water_LeHFM"].ToString();
                    cd.Jun_TotalLeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_TotalLeHFM"].ToString();
                    cd.Jun_Evacs_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Evacs_Est"].ToString();
                    cd.Jun_Seats_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Seats_Est"].ToString();
                    cd.Jun_Lighting_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Lighting_Est"].ToString();
                    cd.Jun_Actuation_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Actuation_Est"].ToString();
                    cd.Jun_Avionics_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Avionics_Est"].ToString();
                    cd.Jun_Water_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Water_Est"].ToString();
                    cd.Jun_TotalEstimate = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_TotalEstimate"].ToString();
                    cd.Jun_Evacs_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Evacs_PriorPa"].ToString();
                    cd.Jun_Seats_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Seats_PriorPa"].ToString();
                    cd.Jun_Lighting_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Lighting_PriorPa"].ToString();
                    cd.Jun_Actuation_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Actuation_PriorPa"].ToString();
                    cd.Jun_Avionics_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Avionics_PriorPa"].ToString();
                    cd.Jun_Water_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_Water_PriorPa"].ToString();
                    cd.Jun_TotalPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jun_TotalPriorPA"].ToString();
                    cd.Jul_Evacs_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Evacs_LeHFM"].ToString();
                    cd.Jul_Seats_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Seats_LeHFM"].ToString();
                    cd.Jul_Lighting_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Lighting_LeHFM"].ToString();
                    cd.Jul_Actuation_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Actuation_LeHFM"].ToString();
                    cd.Jul_Avionics_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Avionics_LeHFM"].ToString();
                    cd.Jul_Water_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Water_LeHFM"].ToString();
                    cd.Jul_TotalLeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_TotalLeHFM"].ToString();
                    cd.Jul_Evacs_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Evacs_Est"].ToString();
                    cd.Jul_Seats_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Seats_Est"].ToString();
                    cd.Jul_Lighting_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Lighting_Est"].ToString();
                    cd.Jul_Actuation_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Actuation_Est"].ToString();
                    cd.Jul_Avionics_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Avionics_Est"].ToString();
                    cd.Jul_Water_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Water_Est"].ToString();
                    cd.Jul_TotalEstimate = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_TotalEstimate"].ToString();
                    cd.Jul_Evacs_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Evacs_PriorPa"].ToString();
                    cd.Jul_Seats_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Seats_PriorPa"].ToString();
                    cd.Jul_Lighting_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Lighting_PriorPa"].ToString();
                    cd.Jul_Actuation_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Actuation_PriorPa"].ToString();
                    cd.Jul_Avionics_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Avionics_PriorPa"].ToString();
                    cd.Jul_Water_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_Water_PriorPa"].ToString();
                    cd.Jul_TotalPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Jul_TotalPriorPA"].ToString();
                    cd.Aug_Evacs_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Evacs_LeHFM"].ToString();
                    cd.Aug_Seats_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Seats_LeHFM"].ToString();
                    cd.Aug_Lighting_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Lighting_LeHFM"].ToString();
                    cd.Aug_Actuation_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Actuation_LeHFM"].ToString();
                    cd.Aug_Avionics_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Avionics_LeHFM"].ToString();
                    cd.Aug_Water_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Water_LeHFM"].ToString();
                    cd.Aug_TotalLeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_TotalLeHFM"].ToString();
                    cd.Aug_Evacs_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Evacs_Est"].ToString();
                    cd.Aug_Seats_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Seats_Est"].ToString();
                    cd.Aug_Lighting_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Lighting_Est"].ToString();
                    cd.Aug_Actuation_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Actuation_Est"].ToString();
                    cd.Aug_Avionics_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Avionics_Est"].ToString();
                    cd.Aug_Water_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Water_Est"].ToString();
                    cd.Aug_TotalEstimate = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_TotalEstimate"].ToString();
                    cd.Aug_Evacs_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Evacs_PriorPa"].ToString();
                    cd.Aug_Seats_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Seats_PriorPa"].ToString();
                    cd.Aug_Lighting_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Lighting_PriorPa"].ToString();
                    cd.Aug_Actuation_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Actuation_PriorPa"].ToString();
                    cd.Aug_Avionics_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Avionics_PriorPa"].ToString();
                    cd.Aug_Water_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_Water_PriorPa"].ToString();
                    cd.Aug_TotalPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Aug_TotalPriorPA"].ToString();
                    cd.Sep_Evacs_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Evacs_LeHFM"].ToString();
                    cd.Sep_Seats_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Seats_LeHFM"].ToString();
                    cd.Sep_Lighting_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Lighting_LeHFM"].ToString();
                    cd.Sep_Actuation_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Actuation_LeHFM"].ToString();
                    cd.Sep_Avionics_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Avionics_LeHFM"].ToString();
                    cd.Sep_Water_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Water_LeHFM"].ToString();
                    cd.Sep_TotalLeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_TotalLeHFM"].ToString();
                    cd.Sep_Evacs_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Evacs_Est"].ToString();
                    cd.Sep_Seats_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Seats_Est"].ToString();
                    cd.Sep_Lighting_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Lighting_Est"].ToString();
                    cd.Sep_Actuation_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Actuation_Est"].ToString();
                    cd.Sep_Avionics_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Avionics_Est"].ToString();
                    cd.Sep_Water_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Water_Est"].ToString();
                    cd.Sep_TotalEstimate = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_TotalEstimate"].ToString();
                    cd.Sep_Evacs_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Evacs_PriorPa"].ToString();
                    cd.Sep_Seats_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Seats_PriorPa"].ToString();
                    cd.Sep_Lighting_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Lighting_PriorPa"].ToString();
                    cd.Sep_Actuation_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Actuation_PriorPa"].ToString();
                    cd.Sep_Avionics_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Avionics_PriorPa"].ToString();
                    cd.Sep_Water_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_Water_PriorPa"].ToString();
                    cd.Sep_TotalPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Sep_TotalPriorPA"].ToString();
                    cd.Oct_Evacs_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Evacs_LeHFM"].ToString();
                    cd.Oct_Seats_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Seats_LeHFM"].ToString();
                    cd.Oct_Lighting_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Lighting_LeHFM"].ToString();
                    cd.Oct_Actuation_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Actuation_LeHFM"].ToString();
                    cd.Oct_Avionics_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Avionics_LeHFM"].ToString();
                    cd.Oct_Water_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Water_LeHFM"].ToString();
                    cd.Oct_TotalLeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_TotalLeHFM"].ToString();
                    cd.Oct_Evacs_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Evacs_Est"].ToString();
                    cd.Oct_Seats_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Seats_Est"].ToString();
                    cd.Oct_Lighting_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Lighting_Est"].ToString();
                    cd.Oct_Actuation_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Actuation_Est"].ToString();
                    cd.Oct_Avionics_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Avionics_Est"].ToString();
                    cd.Oct_Water_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Water_Est"].ToString();
                    cd.Oct_TotalEstimate = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_TotalEstimate"].ToString();
                    cd.Oct_Evacs_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Evacs_PriorPa"].ToString();
                    cd.Oct_Seats_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Seats_PriorPa"].ToString();
                    cd.Oct_Lighting_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Lighting_PriorPa"].ToString();
                    cd.Oct_Actuation_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Actuation_PriorPa"].ToString();
                    cd.Oct_Avionics_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Avionics_PriorPa"].ToString();
                    cd.Oct_Water_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_Water_PriorPa"].ToString();
                    cd.Oct_TotalPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Oct_TotalPriorPA"].ToString();
                    cd.Nov_Evacs_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Evacs_LeHFM"].ToString();
                    cd.Nov_Seats_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Seats_LeHFM"].ToString();
                    cd.Nov_Lighting_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Lighting_LeHFM"].ToString();
                    cd.Nov_Actuation_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Actuation_LeHFM"].ToString();
                    cd.Nov_Avionics_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Avionics_LeHFM"].ToString();
                    cd.Nov_Water_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Water_LeHFM"].ToString();
                    cd.Nov_TotalLeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_TotalLeHFM"].ToString();
                    cd.Nov_Evacs_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Evacs_Est"].ToString();
                    cd.Nov_Seats_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Seats_Est"].ToString();
                    cd.Nov_Lighting_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Lighting_Est"].ToString();
                    cd.Nov_Actuation_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Actuation_Est"].ToString();
                    cd.Nov_Avionics_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Avionics_Est"].ToString();
                    cd.Nov_Water_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Water_Est"].ToString();
                    cd.Nov_TotalEstimate = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_TotalEstimate"].ToString();
                    cd.Nov_Evacs_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Evacs_PriorPa"].ToString();
                    cd.Nov_Seats_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Seats_PriorPa"].ToString();
                    cd.Nov_Lighting_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Lighting_PriorPa"].ToString();
                    cd.Nov_Actuation_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Actuation_PriorPa"].ToString();
                    cd.Nov_Avionics_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Avionics_PriorPa"].ToString();
                    cd.Nov_Water_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_Water_PriorPa"].ToString();
                    cd.Nov_TotalPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Nov_TotalPriorPA"].ToString();
                    cd.Dec_Evacs_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Evacs_LeHFM"].ToString();
                    cd.Dec_Seats_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Seats_LeHFM"].ToString();
                    cd.Dec_Lighting_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Lighting_LeHFM"].ToString();
                    cd.Dec_Actuation_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Actuation_LeHFM"].ToString();
                    cd.Dec_Avionics_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Avionics_LeHFM"].ToString();
                    cd.Dec_Water_LeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Water_LeHFM"].ToString();
                    cd.Dec_TotalLeHFM = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_TotalLeHFM"].ToString();
                    cd.Dec_Evacs_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Evacs_Est"].ToString();
                    cd.Dec_Seats_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Seats_Est"].ToString();
                    cd.Dec_Lighting_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Lighting_Est"].ToString();
                    cd.Dec_Actuation_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Actuation_Est"].ToString();
                    cd.Dec_Avionics_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Avionics_Est"].ToString();
                    cd.Dec_Water_Est = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Water_Est"].ToString();
                    cd.Dec_TotalEstimate = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_TotalEstimate"].ToString();
                    cd.Dec_Evacs_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Evacs_PriorPa"].ToString();
                    cd.Dec_Seats_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Seats_PriorPa"].ToString();
                    cd.Dec_Lighting_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Lighting_PriorPa"].ToString();
                    cd.Dec_Actuation_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Actuation_PriorPa"].ToString();
                    cd.Dec_Avionics_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Avionics_PriorPa"].ToString();
                    cd.Dec_Water_PriorPa = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_Water_PriorPa"].ToString();
                    cd.Dec_TotalPriorPA = dt1.Rows[i]["UoMeasure"].ToString() + dt1.Rows[i]["Dec_TotalPriorPA"].ToString();


                }
                else
                {
                    cd.vcLOVName = dt1.Rows[i]["vcLOVName"].ToString();
                    cd.Jan_Evacs_Actuals = dt1.Rows[i]["Jan_Evacs_Actuals"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_Seats_Actuals = dt1.Rows[i]["Jan_Seats_Actuals"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_Lighting_Actuals = dt1.Rows[i]["Jan_Lighting_Actuals"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_Actuation_Actuals = dt1.Rows[i]["Jan_Actuation_Actuals"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_Avionics_Actuals = dt1.Rows[i]["Jan_Avionics_Actuals"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_Water_Actuals = dt1.Rows[i]["Jan_Water_Actuals"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jan_TotalActuals = dt1.Rows[i]["Jan_TotalActuals"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Evacs_LeHFM = dt1.Rows[i]["Feb_Evacs_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Seats_LeHFM = dt1.Rows[i]["Feb_Seats_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Lighting_LeHFM = dt1.Rows[i]["Feb_Lighting_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Actuation_LeHFM = dt1.Rows[i]["Feb_Actuation_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Avionics_LeHFM = dt1.Rows[i]["Feb_Avionics_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Water_LeHFM = dt1.Rows[i]["Feb_Water_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_TotalLeHFM = dt1.Rows[i]["Feb_TotalLeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Evacs_Est = dt1.Rows[i]["Feb_Evacs_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Seats_Est = dt1.Rows[i]["Feb_Seats_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Lighting_Est = dt1.Rows[i]["Feb_Lighting_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Actuation_Est = dt1.Rows[i]["Feb_Actuation_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Avionics_Est = dt1.Rows[i]["Feb_Avionics_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Water_Est = dt1.Rows[i]["Feb_Water_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_TotalEstimate = dt1.Rows[i]["Feb_TotalEstimate"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Evacs_PriorPa = dt1.Rows[i]["Feb_Evacs_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Seats_PriorPa = dt1.Rows[i]["Feb_Seats_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Lighting_PriorPa = dt1.Rows[i]["Feb_Lighting_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Actuation_PriorPa = dt1.Rows[i]["Feb_Actuation_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Avionics_PriorPa = dt1.Rows[i]["Feb_Avionics_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_Water_PriorPa = dt1.Rows[i]["Feb_Water_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Feb_TotalPriorPA = dt1.Rows[i]["Feb_TotalPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Evacs_LeHFM = dt1.Rows[i]["Mar_Evacs_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Seats_LeHFM = dt1.Rows[i]["Mar_Seats_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Lighting_LeHFM = dt1.Rows[i]["Mar_Lighting_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Actuation_LeHFM = dt1.Rows[i]["Mar_Actuation_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Avionics_LeHFM = dt1.Rows[i]["Mar_Avionics_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Water_LeHFM = dt1.Rows[i]["Mar_Water_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_TotalLeHFM = dt1.Rows[i]["Mar_TotalLeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Evacs_Est = dt1.Rows[i]["Mar_Evacs_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Seats_Est = dt1.Rows[i]["Mar_Seats_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Lighting_Est = dt1.Rows[i]["Mar_Lighting_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Actuation_Est = dt1.Rows[i]["Mar_Actuation_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Avionics_Est = dt1.Rows[i]["Mar_Avionics_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Water_Est = dt1.Rows[i]["Mar_Water_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_TotalEstimate = dt1.Rows[i]["Mar_TotalEstimate"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Evacs_PriorPa = dt1.Rows[i]["Mar_Evacs_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Seats_PriorPa = dt1.Rows[i]["Mar_Seats_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Lighting_PriorPa = dt1.Rows[i]["Mar_Lighting_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Actuation_PriorPa = dt1.Rows[i]["Mar_Actuation_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Avionics_PriorPa = dt1.Rows[i]["Mar_Avionics_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_Water_PriorPa = dt1.Rows[i]["Mar_Water_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Mar_TotalPriorPA = dt1.Rows[i]["Mar_TotalPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Evacs_LeHFM = dt1.Rows[i]["Apr_Evacs_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Seats_LeHFM = dt1.Rows[i]["Apr_Seats_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Lighting_LeHFM = dt1.Rows[i]["Apr_Lighting_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Actuation_LeHFM = dt1.Rows[i]["Apr_Actuation_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Avionics_LeHFM = dt1.Rows[i]["Apr_Avionics_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Water_LeHFM = dt1.Rows[i]["Apr_Water_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_TotalLeHFM = dt1.Rows[i]["Apr_TotalLeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Evacs_Est = dt1.Rows[i]["Apr_Evacs_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Seats_Est = dt1.Rows[i]["Apr_Seats_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Lighting_Est = dt1.Rows[i]["Apr_Lighting_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Actuation_Est = dt1.Rows[i]["Apr_Actuation_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Avionics_Est = dt1.Rows[i]["Apr_Avionics_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Water_Est = dt1.Rows[i]["Apr_Water_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_TotalEstimate = dt1.Rows[i]["Apr_TotalEstimate"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Evacs_PriorPa = dt1.Rows[i]["Apr_Evacs_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Seats_PriorPa = dt1.Rows[i]["Apr_Seats_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Lighting_PriorPa = dt1.Rows[i]["Apr_Lighting_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Actuation_PriorPa = dt1.Rows[i]["Apr_Actuation_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Avionics_PriorPa = dt1.Rows[i]["Apr_Avionics_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_Water_PriorPa = dt1.Rows[i]["Apr_Water_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Apr_TotalPriorPA = dt1.Rows[i]["Apr_TotalPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Evacs_LeHFM = dt1.Rows[i]["May_Evacs_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Seats_LeHFM = dt1.Rows[i]["May_Seats_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Lighting_LeHFM = dt1.Rows[i]["May_Lighting_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Actuation_LeHFM = dt1.Rows[i]["May_Actuation_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Avionics_LeHFM = dt1.Rows[i]["May_Avionics_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Water_LeHFM = dt1.Rows[i]["May_Water_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_TotalLeHFM = dt1.Rows[i]["May_TotalLeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Evacs_Est = dt1.Rows[i]["May_Evacs_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Seats_Est = dt1.Rows[i]["May_Seats_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Lighting_Est = dt1.Rows[i]["May_Lighting_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Actuation_Est = dt1.Rows[i]["May_Actuation_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Avionics_Est = dt1.Rows[i]["May_Avionics_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Water_Est = dt1.Rows[i]["May_Water_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_TotalEstimate = dt1.Rows[i]["May_TotalEstimate"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Evacs_PriorPa = dt1.Rows[i]["May_Evacs_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Seats_PriorPa = dt1.Rows[i]["May_Seats_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Lighting_PriorPa = dt1.Rows[i]["May_Lighting_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Actuation_PriorPa = dt1.Rows[i]["May_Actuation_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Avionics_PriorPa = dt1.Rows[i]["May_Avionics_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_Water_PriorPa = dt1.Rows[i]["May_Water_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.May_TotalPriorPA = dt1.Rows[i]["May_TotalPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Evacs_LeHFM = dt1.Rows[i]["Jun_Evacs_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Seats_LeHFM = dt1.Rows[i]["Jun_Seats_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Lighting_LeHFM = dt1.Rows[i]["Jun_Lighting_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Actuation_LeHFM = dt1.Rows[i]["Jun_Actuation_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Avionics_LeHFM = dt1.Rows[i]["Jun_Avionics_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Water_LeHFM = dt1.Rows[i]["Jun_Water_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_TotalLeHFM = dt1.Rows[i]["Jun_TotalLeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Evacs_Est = dt1.Rows[i]["Jun_Evacs_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Seats_Est = dt1.Rows[i]["Jun_Seats_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Lighting_Est = dt1.Rows[i]["Jun_Lighting_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Actuation_Est = dt1.Rows[i]["Jun_Actuation_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Avionics_Est = dt1.Rows[i]["Jun_Avionics_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Water_Est = dt1.Rows[i]["Jun_Water_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_TotalEstimate = dt1.Rows[i]["Jun_TotalEstimate"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Evacs_PriorPa = dt1.Rows[i]["Jun_Evacs_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Seats_PriorPa = dt1.Rows[i]["Jun_Seats_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Lighting_PriorPa = dt1.Rows[i]["Jun_Lighting_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Actuation_PriorPa = dt1.Rows[i]["Jun_Actuation_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Avionics_PriorPa = dt1.Rows[i]["Jun_Avionics_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_Water_PriorPa = dt1.Rows[i]["Jun_Water_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jun_TotalPriorPA = dt1.Rows[i]["Jun_TotalPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Evacs_LeHFM = dt1.Rows[i]["Jul_Evacs_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Seats_LeHFM = dt1.Rows[i]["Jul_Seats_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Lighting_LeHFM = dt1.Rows[i]["Jul_Lighting_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Actuation_LeHFM = dt1.Rows[i]["Jul_Actuation_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Avionics_LeHFM = dt1.Rows[i]["Jul_Avionics_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Water_LeHFM = dt1.Rows[i]["Jul_Water_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_TotalLeHFM = dt1.Rows[i]["Jul_TotalLeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Evacs_Est = dt1.Rows[i]["Jul_Evacs_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Seats_Est = dt1.Rows[i]["Jul_Seats_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Lighting_Est = dt1.Rows[i]["Jul_Lighting_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Actuation_Est = dt1.Rows[i]["Jul_Actuation_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Avionics_Est = dt1.Rows[i]["Jul_Avionics_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Water_Est = dt1.Rows[i]["Jul_Water_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_TotalEstimate = dt1.Rows[i]["Jul_TotalEstimate"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Evacs_PriorPa = dt1.Rows[i]["Jul_Evacs_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Seats_PriorPa = dt1.Rows[i]["Jul_Seats_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Lighting_PriorPa = dt1.Rows[i]["Jul_Lighting_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Actuation_PriorPa = dt1.Rows[i]["Jul_Actuation_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Avionics_PriorPa = dt1.Rows[i]["Jul_Avionics_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_Water_PriorPa = dt1.Rows[i]["Jul_Water_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Jul_TotalPriorPA = dt1.Rows[i]["Jul_TotalPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Evacs_LeHFM = dt1.Rows[i]["Aug_Evacs_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Seats_LeHFM = dt1.Rows[i]["Aug_Seats_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Lighting_LeHFM = dt1.Rows[i]["Aug_Lighting_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Actuation_LeHFM = dt1.Rows[i]["Aug_Actuation_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Avionics_LeHFM = dt1.Rows[i]["Aug_Avionics_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Water_LeHFM = dt1.Rows[i]["Aug_Water_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_TotalLeHFM = dt1.Rows[i]["Aug_TotalLeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Evacs_Est = dt1.Rows[i]["Aug_Evacs_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Seats_Est = dt1.Rows[i]["Aug_Seats_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Lighting_Est = dt1.Rows[i]["Aug_Lighting_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Actuation_Est = dt1.Rows[i]["Aug_Actuation_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Avionics_Est = dt1.Rows[i]["Aug_Avionics_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Water_Est = dt1.Rows[i]["Aug_Water_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_TotalEstimate = dt1.Rows[i]["Aug_TotalEstimate"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Evacs_PriorPa = dt1.Rows[i]["Aug_Evacs_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Seats_PriorPa = dt1.Rows[i]["Aug_Seats_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Lighting_PriorPa = dt1.Rows[i]["Aug_Lighting_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Actuation_PriorPa = dt1.Rows[i]["Aug_Actuation_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Avionics_PriorPa = dt1.Rows[i]["Aug_Avionics_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_Water_PriorPa = dt1.Rows[i]["Aug_Water_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Aug_TotalPriorPA = dt1.Rows[i]["Aug_TotalPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Evacs_LeHFM = dt1.Rows[i]["Sep_Evacs_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Seats_LeHFM = dt1.Rows[i]["Sep_Seats_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Lighting_LeHFM = dt1.Rows[i]["Sep_Lighting_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Actuation_LeHFM = dt1.Rows[i]["Sep_Actuation_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Avionics_LeHFM = dt1.Rows[i]["Sep_Avionics_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Water_LeHFM = dt1.Rows[i]["Sep_Water_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_TotalLeHFM = dt1.Rows[i]["Sep_TotalLeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Evacs_Est = dt1.Rows[i]["Sep_Evacs_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Seats_Est = dt1.Rows[i]["Sep_Seats_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Lighting_Est = dt1.Rows[i]["Sep_Lighting_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Actuation_Est = dt1.Rows[i]["Sep_Actuation_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Avionics_Est = dt1.Rows[i]["Sep_Avionics_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Water_Est = dt1.Rows[i]["Sep_Water_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_TotalEstimate = dt1.Rows[i]["Sep_TotalEstimate"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Evacs_PriorPa = dt1.Rows[i]["Sep_Evacs_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Seats_PriorPa = dt1.Rows[i]["Sep_Seats_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Lighting_PriorPa = dt1.Rows[i]["Sep_Lighting_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Actuation_PriorPa = dt1.Rows[i]["Sep_Actuation_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Avionics_PriorPa = dt1.Rows[i]["Sep_Avionics_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_Water_PriorPa = dt1.Rows[i]["Sep_Water_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Sep_TotalPriorPA = dt1.Rows[i]["Sep_TotalPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Evacs_LeHFM = dt1.Rows[i]["Oct_Evacs_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Seats_LeHFM = dt1.Rows[i]["Oct_Seats_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Lighting_LeHFM = dt1.Rows[i]["Oct_Lighting_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Actuation_LeHFM = dt1.Rows[i]["Oct_Actuation_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Avionics_LeHFM = dt1.Rows[i]["Oct_Avionics_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Water_LeHFM = dt1.Rows[i]["Oct_Water_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_TotalLeHFM = dt1.Rows[i]["Oct_TotalLeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Evacs_Est = dt1.Rows[i]["Oct_Evacs_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Seats_Est = dt1.Rows[i]["Oct_Seats_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Lighting_Est = dt1.Rows[i]["Oct_Lighting_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Actuation_Est = dt1.Rows[i]["Oct_Actuation_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Avionics_Est = dt1.Rows[i]["Oct_Avionics_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Water_Est = dt1.Rows[i]["Oct_Water_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_TotalEstimate = dt1.Rows[i]["Oct_TotalEstimate"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Evacs_PriorPa = dt1.Rows[i]["Oct_Evacs_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Seats_PriorPa = dt1.Rows[i]["Oct_Seats_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Lighting_PriorPa = dt1.Rows[i]["Oct_Lighting_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Actuation_PriorPa = dt1.Rows[i]["Oct_Actuation_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Avionics_PriorPa = dt1.Rows[i]["Oct_Avionics_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_Water_PriorPa = dt1.Rows[i]["Oct_Water_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Oct_TotalPriorPA = dt1.Rows[i]["Oct_TotalPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Evacs_LeHFM = dt1.Rows[i]["Nov_Evacs_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Seats_LeHFM = dt1.Rows[i]["Nov_Seats_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Lighting_LeHFM = dt1.Rows[i]["Nov_Lighting_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Actuation_LeHFM = dt1.Rows[i]["Nov_Actuation_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Avionics_LeHFM = dt1.Rows[i]["Nov_Avionics_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Water_LeHFM = dt1.Rows[i]["Nov_Water_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_TotalLeHFM = dt1.Rows[i]["Nov_TotalLeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Evacs_Est = dt1.Rows[i]["Nov_Evacs_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Seats_Est = dt1.Rows[i]["Nov_Seats_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Lighting_Est = dt1.Rows[i]["Nov_Lighting_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Actuation_Est = dt1.Rows[i]["Nov_Actuation_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Avionics_Est = dt1.Rows[i]["Nov_Avionics_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Water_Est = dt1.Rows[i]["Nov_Water_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_TotalEstimate = dt1.Rows[i]["Nov_TotalEstimate"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Evacs_PriorPa = dt1.Rows[i]["Nov_Evacs_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Seats_PriorPa = dt1.Rows[i]["Nov_Seats_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Lighting_PriorPa = dt1.Rows[i]["Nov_Lighting_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Actuation_PriorPa = dt1.Rows[i]["Nov_Actuation_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Avionics_PriorPa = dt1.Rows[i]["Nov_Avionics_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_Water_PriorPa = dt1.Rows[i]["Nov_Water_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Nov_TotalPriorPA = dt1.Rows[i]["Nov_TotalPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Evacs_LeHFM = dt1.Rows[i]["Dec_Evacs_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Seats_LeHFM = dt1.Rows[i]["Dec_Seats_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Lighting_LeHFM = dt1.Rows[i]["Dec_Lighting_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Actuation_LeHFM = dt1.Rows[i]["Dec_Actuation_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Avionics_LeHFM = dt1.Rows[i]["Dec_Avionics_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Water_LeHFM = dt1.Rows[i]["Dec_Water_LeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_TotalLeHFM = dt1.Rows[i]["Dec_TotalLeHFM"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Evacs_Est = dt1.Rows[i]["Dec_Evacs_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Seats_Est = dt1.Rows[i]["Dec_Seats_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Lighting_Est = dt1.Rows[i]["Dec_Lighting_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Actuation_Est = dt1.Rows[i]["Dec_Actuation_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Avionics_Est = dt1.Rows[i]["Dec_Avionics_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Water_Est = dt1.Rows[i]["Dec_Water_Est"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_TotalEstimate = dt1.Rows[i]["Dec_TotalEstimate"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Evacs_PriorPa = dt1.Rows[i]["Dec_Evacs_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Seats_PriorPa = dt1.Rows[i]["Dec_Seats_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Lighting_PriorPa = dt1.Rows[i]["Dec_Lighting_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Actuation_PriorPa = dt1.Rows[i]["Dec_Actuation_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Avionics_PriorPa = dt1.Rows[i]["Dec_Avionics_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_Water_PriorPa = dt1.Rows[i]["Dec_Water_PriorPa"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();
                    cd.Dec_TotalPriorPA = dt1.Rows[i]["Dec_TotalPriorPA"].ToString() + dt1.Rows[i]["UoMeasure"].ToString();


                }
                li.Add(cd);
            }
            return li;
        }



        #endregion Export_to_Excel


        #region LeadIndicatorSummery

        public ActionResult LeadingIndicatorSummary()
        {
            ViewBag.AllRoles = Session["RoleList"];

            GOSPA_TestEntities dbContext = new GOSPA_TestEntities();
            ViewBag.Year = dbContext.tbl_Timeline.Select(p => p.iYear).Distinct();

            //Getting all Value stream data   
            OperationResult operationResult = new OperationResult();
            operationResult = new LOVManager().GetVSData();

            //var vsdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetValueStreamList>().ToList();
            //GetValueStreamList ddlAll = new GetValueStreamList();
            //ddlAll.vSId = 0;
            //ddlAll.vcValueStream = "All";
            //vsdata.Add(ddlAll);

            //var vsddl = from s in vsdata
            //            orderby s.vSId
            //            select s;
            //ViewBag.ValueStream = vsddl.ToList();

            return View();
        }

        [HttpPost]
        public ActionResult LeadIndicatorSummery_test(string Year)
        {
            ViewBag.AllRoles = Session["RoleList"];
            //int vs = Convert.ToInt32(Year);
            int vs = 1;
            int monthId = DateTime.Now.Month;
            int weekId = GetWeekNumberOfMonth();
            OperationResult operationResult = new OperationResult();
            //GetConsolidated_GridData1
            //GetConsolidated_LeadingIndicator
            SqlCommand cmd = new SqlCommand("GetConsolidated_LeadingIndicator", con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@VSID", vs);
            cmd.Parameters.AddWithValue("@MonthId", monthId);
            cmd.Parameters.AddWithValue("@Weekid", weekId);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt1 = new  DataTable();
            da.Fill(ds);
            dt1 = ds.Tables[0];

            //DataColumn newCol = new DataColumn("NewColumn", typeof(string));
            //newCol.AllowDBNull = true;
            //dt1.Columns.Add(newCol);
            //int i = 0;
            //foreach (DataRow row in dt1.Rows)
            //{                
            //    row["NewColumn"] = "You value"+i;
            //    i++;
            //}

            List<Dictionary<string, object>> lstPersons = GetTableRows(dt1);
            return Json(lstPersons, JsonRequestBehavior.AllowGet);
        }
        #endregion--LeadIndicatorSummery

        #region Consolidated sheets
        public ActionResult Consolidated_Sheet()
        {
            ViewBag.AllRoles = Session["RoleList"];
            //ViewBag.RollesArray = Session["rololeids"];
            //int iUserID =Convert.ToInt32(Session["userid"]);           

            //var ilist = (List<int>)Session["rololeids"];
            //int roleid = ilist[0];


            //int iUserID = Convert.ToInt32(Session["LoginId"]);
            //int roleid =Convert.ToInt32(Session["Workinguser"]);

            int iUserID = Convert.ToInt32(Session["LoginId"]);
            int roleid = Convert.ToInt32(Session["CurrentRole"]);


            //GOSPA_TestEntities dbContext = new GOSPA_TestEntities();
            //ViewBag.Year = dbContext.tbl_Timeline.Select(p => p.iYear).Distinct();
            OperationResult operationResultYear = new OperationResult();
            operationResultYear = new LOVManager().GetTimeLine();
            ViewBag.Year = ((IEnumerable)operationResultYear.Data);

            //Getting all Value stream data   
            OperationResult operationResult = new OperationResult();

            //operationResult = new LOVManager().GetVSData();

            operationResult = new LOVManager().GetValueStreamDetails_consolidated(roleid, iUserID);

            var vsdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetValueStreamDetails_consolidated>().ToList();
            GetValueStreamDetails_consolidated ddlAll = new GetValueStreamDetails_consolidated();
            ddlAll.iVSID = 0;
            ddlAll.vcValueStream = "All";
            vsdata.Add(ddlAll);

            var vsddl = from s in vsdata
                        orderby s.iVSID
                        select s;
            ViewBag.ValueStream = vsddl.ToList();

            return View();
        }

        [HttpPost]
        public ActionResult Consolidated_test(string ValueStream, int Year)
        {
            ViewBag.AllRoles = Session["RoleList"];

            int vs = Convert.ToInt32(ValueStream);
            int monthId = DateTime.Now.Month;
            int weekId = GetWeekNumberOfMonth();
            OperationResult operationResult = new OperationResult();
            int iUserID = Convert.ToInt32(Session["LoginId"]);
            int roleid = Convert.ToInt32(Session["CurrentRole"]);

            DataTable dtConsolidatedDta = Getdatatable(vs, weekId, monthId, Year, roleid, iUserID);

            #region--Commented
            //DataColumn newCol = new DataColumn("NewColumn", typeof(string));
            //newCol.AllowDBNull = true;
            //dt1.Columns.Add(newCol);
            //int i = 0;
            //foreach (DataRow row in dt1.Rows)
            //{                
            //    row["NewColumn"] = "You value"+i;
            //    i++;
            //}
            #endregion--Commented

            List<ConsolidatedData> li = GetUoMeasureConsolidatedtableData(dtConsolidatedDta);

            DataTable dt = ToDataTable(li);

            List<Dictionary<string, object>> lstPersons = GetTableRows(dt);

            return Json(lstPersons, JsonRequestBehavior.AllowGet);

            #region--Commented

            //operationResult = new LOVManager().GetConsolidatedData_test2(vs, monthId, weekId);


            //var data1 = ((IEnumerable)operationResult.Data).Cast<Common.DTO.ConsolidatedData>().ToList();
            //var model = data1.AsEnumerable();
            //return Json(model, JsonRequestBehavior.AllowGet);
            #endregion--Commented
        }

        private DataTable Getdatatable(int vs, int weekId, int monthId, int year, int roleid, int iUserID)
        {
            //SqlCommand cmd = new SqlCommand("GetConsolidated_GridData1_test2", con);
            SqlCommand cmd = new SqlCommand("GetConsolidated_GridData_All", con);

            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@VSID", vs);//vs //2
            cmd.Parameters.AddWithValue("@Weekid", weekId);//weekId //2
            cmd.Parameters.AddWithValue("@MonthId", monthId);//monthId //2    
            cmd.Parameters.AddWithValue("@iYearId", year);//Year //2021
            cmd.Parameters.AddWithValue("@iRoleID", roleid);//roleid //3
            cmd.Parameters.AddWithValue("@iUserid", iUserID);//iUserID //84

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt1 = new DataTable();
            da.Fill(ds);
            dt1 = ds.Tables[0];
            return dt1;
        }

      

        [NonAction]
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        public List<Dictionary<string, object>> GetTableRows(DataTable dtData)
        {
            List<Dictionary<string, object>> lstRows = new List<Dictionary<string, object>>();
            Dictionary<string, object> dictRow = null;

            foreach (DataRow dr in dtData.Rows)
            {
                dictRow = new Dictionary<string, object>();
                foreach (DataColumn col in dtData.Columns)
                {
                    dictRow.Add(col.ColumnName, dr[col]);
                }
                lstRows.Add(dictRow);
            }
            return lstRows;
        }

       

        [NonAction]
        public int GetWeekNumberOfMonth()
        {
            DateTime date = DateTime.Now;
            date = date.Date;
            DateTime firstMonthDay = new DateTime(date.Year, date.Month, 1);
            DateTime firstMonthMonday = firstMonthDay.AddDays((DayOfWeek.Monday + 7 - firstMonthDay.DayOfWeek) % 7);
            if (firstMonthMonday > date)
            {
                firstMonthDay = firstMonthDay.AddMonths(-1);
                firstMonthMonday = firstMonthDay.AddDays((DayOfWeek.Monday + 7 - firstMonthDay.DayOfWeek) % 7);
            }
            return (date - firstMonthMonday).Days / 7 + 1;
        }
        #endregion Consolidated sheets


    }
}