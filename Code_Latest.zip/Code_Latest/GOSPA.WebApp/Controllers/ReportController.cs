﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GOSPA.WebApp.Controllers
{
    public class ReportController : BaseController
    {
        // GET: Repor
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ReportOpsUser()
        {
            ViewBag.AllRoles = Session["RoleList"];
            return View();
        }

        public ActionResult ReportFCUser()
        {
            ViewBag.AllRoles = Session["RoleList"];
            return View();
        }

        public ActionResult ReportLTUser()
        {
            ViewBag.AllRoles = Session["RoleList"];
            return View();
        }
    }
}