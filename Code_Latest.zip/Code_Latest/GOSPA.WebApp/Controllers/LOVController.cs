﻿using SAP.Framework.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GOSPA.Business;
using GOSPA.Common.DTO;
using GOSPA.ExceptionHandler.Exception;
using System.Reflection;
using GOSPA.WebApp.SiteHelpers;
using System.Configuration;
using System.Text;
using PagedList;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Data;
using System.Data.Entity;
using System.Collections;
using GOSPA.WebApp.Models;
using GOSPA.DataModels;

namespace GOSPA.WebApp.Controllers
{
    public class LOVController : BaseController
    {
        #region ManageUsers

        #region ManageOpsUser

        /// <summary>
        /// Manage Ops users
        /// </summary>
        /// <param name="sortOrder">The sortOrder identifier</param>
        /// <param name="currentFilter">The currentFilter identifier</param>
        /// <param name="searchString">The searchString identifier</param>
        /// <param name="page">The page identifier</param>
        /// <returns></returns>
        public ActionResult ManageOpsUser(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetRolebased_UserList();

                //GetRolebased_UserList
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserRole == "Ops User").ToList();

                for (int i = 0; i < data.Count; i++)
                {
                    operationResult = new UserManager().GetOpsUSerValueStream(Convert.ToInt32(data[i].UserId), 1);

                    var vsdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetOpsUserList>().ToList().Select(x => x.vcValueStream);

                    //operationResult = new LOVManager().GetValueStreamData1();
                    //var valstream1 = ((IEnumerable)operationResult.Data).Cast<string>().ToList();

                    //data[0].AllValueStream = valstream1;

                    data[i].avs = string.Join(",", vsdata);
                }

                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Manage Ops user edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageOpsUserEdit(int id)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetUserDetails1();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserId == id).ToList();
                var model = data.AsEnumerable();

                //Commented
                operationResult = new LOVManager().GetValueStreamData1();
                var valstream1 = ((IEnumerable)operationResult.Data).Cast<string>().ToList();

                //operationResult = new UserManager().GetOpsUSerValueStream(Convert.ToInt32(data[0].UserId),1);

                //var valstream1 = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetOpsUserList>().ToList().Select(x => x.vcValueStream);
                GOSPA_TestEntities dbContext = new GOSPA_TestEntities();
                int iURIDres = (int)dbContext.tbl_UserRoleMapping.Where(p => p.iUserID == id && p.iRoleID == 1).Select(p => p.iURID).FirstOrDefault();

                var query = from uvm in dbContext.tbl_UserVSMapping
                            join vs in dbContext.tbl_ValueStream on uvm.iVSID equals vs.iVSID
                            where uvm.iUserRoleID == iURIDres && uvm.iUserID == id
                            select new { vs.vcValueStream };

                var ss = query.Select(p => p.vcValueStream).ToList();

                //var valstream1 = dbContext.tbl_UserVSMapping.Where(p => p.iUserRoleID == iURIDres && p.iUserID == iURIDres).ToList().Select(x => x.iVSID);


                var obj = new Models.GetUserList
                {
                    Id = data[0].UserId,
                    UserName = data[0].UserName,
                    UserEmail = data[0].UserEmail,
                    UserRole = data[0].UserRole,
                    CreatedBy = data[0].CreatedBy,
                    CreatedDate = data[0].CreatedDate,
                    AllValueStream = valstream1,
                    AssignedVS = ss.ToList()
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }


        //venkat

        public JsonResult UpdateUsers(UpdateValuestreams data)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                GOSPA_TestEntities dbContext = new GOSPA_TestEntities();
                //int iUserID = Convert.ToInt32(Session["LoginId"]);
                int iUserID = Convert.ToInt32(data.Id);
                int roleid = 1;

                ArrayList ar = new ArrayList();

                for (int i = 0; i < data.vs.Length; i++)
                {
                    string ss = data.vs[i];
                    int x = (int)dbContext.tbl_ValueStream.Where(p => p.vcValueStream == ss).Select(p => p.iVSID).FirstOrDefault();
                    ar.Add(x);
                }
                string dd = String.Join(",", ar.ToArray());

                int iURIDres = (int)dbContext.tbl_UserRoleMapping.Where(p => p.iUserID == iUserID && p.iRoleID == roleid).Select(p => p.iURID).FirstOrDefault();
                var ssss = dbContext.tbl_UserVSMapping.Where(p => p.iUserRoleID == iURIDres && p.iUserID == iUserID);
                dbContext.tbl_UserVSMapping.RemoveRange(ssss);
                dbContext.SaveChanges();
                List<tbl_UserVSMapping> obj = new List<tbl_UserVSMapping>();

                var list = dd.Split(',');

                for (int i = 0; i < list.Count(); i++)
                {
                    obj.Add(new tbl_UserVSMapping()
                    {
                        // iVSID   iUserID vcCreatedBy dCreatedDate    iUserRoleID
                        iVSID = Convert.ToInt32(list[i]),
                        iUserID = iUserID,
                        vcCreatedBy = data.UserName,
                        dCreatedDate = DateTime.Now,
                        iUserRoleID = iURIDres
                    });
                }

                dbContext.tbl_UserVSMapping.AddRange(obj);
                dbContext.SaveChanges();


                string sample = string.Empty;


                //iUserRoleID
                //iUserID
                //iVSID
                //data.vs[0]
                //Valuestreams --enum




                //ViewBag.AllRoles = Session["RoleList"];

                //OperationResult operationResult = new OperationResult();

                //operationResult = new LOVManager().GetUserDetails1();
                //var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.Id == id).ToList();
                //var model = data.AsEnumerable();

                //operationResult = new LOVManager().GetValueStreamData1();
                //var valstream1 = ((IEnumerable)operationResult.Data).Cast<string>().ToList();

                var obj2 = new Models.GetUserList
                {
                    Id = 1,
                    UserName = "sfdsdf",
                    UserEmail = "sdfsd",
                    UserRole = "sdf",
                    CreatedBy = "ssdf",

                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }


        public JsonResult UpdateFCDetails(UpdateValuestreams data)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                GOSPA_TestEntities dbContext = new GOSPA_TestEntities();
                //int iUserID = Convert.ToInt32(Session["LoginId"]);
                int iUserID = Convert.ToInt32(data.Id);
                int roleid = 2;

                ArrayList ar = new ArrayList();

                for (int i = 0; i < data.vs.Length; i++)
                {
                    string ss = data.vs[i];
                    int x = (int)dbContext.tbl_ValueStream.Where(p => p.vcValueStream == ss).Select(p => p.iVSID).FirstOrDefault();
                    ar.Add(x);
                }
                string dd = String.Join(",", ar.ToArray());

                int iURIDres = (int)dbContext.tbl_UserRoleMapping.Where(p => p.iUserID == iUserID && p.iRoleID == roleid).Select(p => p.iURID).FirstOrDefault();
                var ssss = dbContext.tbl_UserVSMapping.Where(p => p.iUserRoleID == iURIDres && p.iUserID == iUserID);
                dbContext.tbl_UserVSMapping.RemoveRange(ssss);
                dbContext.SaveChanges();
                List<tbl_UserVSMapping> obj = new List<tbl_UserVSMapping>();

                var list = dd.Split(',');

                for (int i = 0; i < list.Count(); i++)
                {
                    obj.Add(new tbl_UserVSMapping()
                    {
                        // iVSID   iUserID vcCreatedBy dCreatedDate    iUserRoleID
                        iVSID = Convert.ToInt32(list[i]),
                        iUserID = iUserID,
                        vcCreatedBy = data.UserName,
                        dCreatedDate = DateTime.Now,
                        iUserRoleID = iURIDres
                    });
                }
                dbContext.tbl_UserVSMapping.AddRange(obj);
                dbContext.SaveChanges();

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }


        //venkat






        #endregion

        #region ManageFinanceController
        /// <summary>
        /// Manage Ops users
        /// </summary>
        /// <param name="sortOrder">The sortOrder identifier</param>
        /// <param name="currentFilter">The currentFilter identifier</param>
        /// <param name="searchString">The searchString identifier</param>
        /// <param name="page">The page identifier</param>
        /// <returns></returns>
        public ActionResult ManageFinanceController(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetRolebased_UserList();//SP: GetRolebased_UserList
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserRole == "Financal Controller").ToList();

                int UserIdval;
                int iURIDres;
                for (int i = 0; i < data.Count; i++)
                {
                    UserIdval = Convert.ToInt32(data[i].UserId);
                    GOSPA_TestEntities dbContext = new GOSPA_TestEntities();
                    iURIDres = dbContext.tbl_UserRoleMapping.Where(p => p.iUserID == UserIdval && p.iRoleID == 2).Select(p => p.iURID).FirstOrDefault();

                    var query =
                                    from uvm in dbContext.tbl_UserVSMapping
                                    join vs in dbContext.tbl_ValueStream on uvm.iVSID equals vs.iVSID
                                    where uvm.iUserRoleID == iURIDres && uvm.iUserID == UserIdval
                                    select new { vs.vcValueStream };

                    List<string> ss = query.Select(p => p.vcValueStream).ToList();
                    data[i].avs = string.Join(",", ss);
                }


                //for (int i = 0; i < data.Count; i++)
                //{
                //    operationResult = new LOVManager().GetValusStreamDetails_consolidated(2, Convert.ToInt32(data[i].UserId));
                //    var vsdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetValusStreamDetails_consolidated>().ToList().Select(x => x.vcValueStream);
                //    data[i].avs = string.Join(",", vsdata);
                //}
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Manage Ops user edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageFinanceControllerEdit(int id)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetUserDetails1();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserId == id).ToList();
                var model = data.AsEnumerable();

                operationResult = new LOVManager().GetValueStreamData2();
                var valstream1 = ((IEnumerable)operationResult.Data).Cast<GetValueStreamDetails_consolidated>().ToList();
                
                var vs1 = valstream1.Select(p => p.iVSID).ToList();
                var vs2 = valstream1.Select(p => p.vcValueStream).ToList();

                GOSPA_TestEntities dbContext = new GOSPA_TestEntities();
                int iURIDres = (int)dbContext.tbl_UserRoleMapping.Where(p => p.iUserID == id && p.iRoleID == 2).Select(p => p.iURID).FirstOrDefault();

                var query =
                                from uvm in dbContext.tbl_UserVSMapping
                                join vs in dbContext.tbl_ValueStream on uvm.iVSID equals vs.iVSID
                                where uvm.iUserRoleID == iURIDres && uvm.iUserID == id
                                select new { vs.vcValueStream,vs.iVSID };

                var ss = query.Select(p => p.vcValueStream).ToList();
                var ssval = query.Select(p => p.iVSID).ToList();

                var obj = new Models.GetUserList
                {
                    Id = data[0].UserId,
                    UserName = data[0].UserName,
                    UserEmail = data[0].UserEmail,
                    UserRole = data[0].UserRole,
                    CreatedBy = data[0].CreatedBy,
                    CreatedDate = data[0].CreatedDate,
                    AllValueStream = vs2,
                    AllValueStream_val = vs1,
                    AssignedVS = ss.ToList(),
                    AssignedVal = ssval.ToList(),
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }
        #endregion

        #region ManageLT
        /// <summary>
        /// Manage Ops users
        /// </summary>
        /// <param name="sortOrder">The sortOrder identifier</param>
        /// <param name="currentFilter">The currentFilter identifier</param>
        /// <param name="searchString">The searchString identifier</param>
        /// <param name="page">The page identifier</param>
        /// <returns></returns>
        public ActionResult ManageLeadershipTeam(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetUserDetails1();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserRole == "Leadership Team").ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Manage Ops user edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageLeadershipTeamEdit(int id)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetUserDetails1();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.Id == id).ToList();
                var model = data.AsEnumerable();

                operationResult = new LOVManager().GetValueStreamData1();
                var valstream1 = ((IEnumerable)operationResult.Data).Cast<string>().ToList();

                var obj = new Models.GetUserList
                {
                    Id = data[0].Id,
                    UserName = data[0].UserName,
                    UserEmail = data[0].UserEmail,
                    UserRole = data[0].UserRole,
                    CreatedBy = data[0].CreatedBy,
                    CreatedDate = data[0].CreatedDate,
                    AllValueStream = valstream1,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }
        #endregion

        #region Manangeusers

        /// <summary>
        /// Manage users
        /// </summary>
        /// <param name="sortOrder">The sortOrder identifier</param>
        /// <param name="currentFilter">The currentFilter identifier</param>
        /// <param name="searchString">The searchString identifier</param>
        /// <param name="page">The page identifier</param>
        /// <returns></returns>
        public ActionResult ManageUsers(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                //var userDet = (this.dbContext as GOSPA_TestEntities).GetUserDetails(EmailId).ToList();
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                //operationResult = new LOVManager().GetUserDetails();
                //var data = ((IEnumerable)operationResult.Data).Cast<UserDetailsCommon>().ToList();
                //var model = data.AsEnumerable();

                operationResult = new LOVManager().GetUserDetails1();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Manage user edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageUserEdit(int id)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                //operationResult = new LOVManager().GetUserDetails();
                //var data = ((IEnumerable)operationResult.Data).Cast<UserDetailsCommon>().Where(x => x.iID == id).ToList();
                //var model = data.AsEnumerable();

                operationResult = new LOVManager().GetUserDetails1();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.Id == id).ToList();
                var model = data.AsEnumerable();

                operationResult = new LOVManager().GetValueStreamData();
                var valStream = ((IEnumerable)operationResult.Data).Cast<GetValueStreamList>().ToList();

                operationResult = new LOVManager().GetValueStreamData1();
                var valstream1 = ((IEnumerable)operationResult.Data).Cast<string>().ToList();

                //string[] srcValues = valStream. test.SourceCompany.ToString().Split(',');
                var obj = new Models.GetUserList
                {
                    Id = data[0].Id,
                    UserName = data[0].UserName,
                    UserEmail = data[0].UserEmail,
                    UserRole = data[0].UserRole,
                    CreatedBy = data[0].CreatedBy,
                    CreatedDate = data[0].CreatedDate,
                    AllValueStream = valstream1,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region InActiveUsers

        /// <summary>
        /// Inactive users
        /// </summary>
        /// <param name="sortOrder">The sortOrder identifier</param>
        /// <param name="currentFilter">The currentFilter identifier</param>
        /// <param name="searchString">The searchString identifier</param>
        /// <param name="page">The page identifier</param>
        /// <returns></returns>
        public ActionResult InActiveUsers(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetUserDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<UserDetailsCommon>().
                    Where(x => x.dStatus == Convert.ToBoolean(UserActiveStatus.InActive)).ToList();

                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Approve InActive users
        /// </summary>
        /// <param name="jsonOfData">The jsonOfData identifier</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ApproveInActiveUsers(Models.UserViewModel jsonOfData)
        {
            try
            {
                var model = 0;
                int userId = Convert.ToInt32(jsonOfData.Id);
                string UpdatedBy = Session["CurrentUser"].ToString();

                OperationResult operationResult = new OperationResult();
                operationResult = new UserManager().ApproveInActiveUsers(userId, UpdatedBy);

                ///Get Userdetails based on the userid,adminloginid
                operationResult = new LOVManager().GetUserDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<UserDetailsCommon>().Where(x => x.iID == userId).SingleOrDefault();

                if (operationResult.Success == true)
                {
                    //Send mail to user from Admin
                    string toreply = data.vcEmail;
                    string subject = "Admin approved the User registration request";
                    string toAddress = data.vcEmail;
                    string toCC = ConfigurationManager.AppSettings["AdminMail"];

                    StringBuilder sb = new StringBuilder();
                    sb.Append("<h2><center>Finance-GOSPA Tool: Admin Approval</center></h2>");
                    sb.Append("<p>Hi " + data.vcName + ",</p> ");
                    sb.Append("<p>Admin approved the registration request.</p>");
                    sb.Append("<html><head><style> table, th, td {border: 1px solid black;}</style></head><body>");
                    sb.Append("<table cellspacing='2' cellpadding='2'><tr><td colspan='4'><center><h4>User Details</h4></center></td></tr>");
                    sb.Append("<tr><th>User Name</th><td colspan='3'>" + data.vcName + "</ td ></ tr > ");
                    sb.Append("<tr><th>User Email</th><td colspan='3'>" + data.vcEmail + "</ td ></ tr > ");
                    sb.Append("<tr><th>User Title</th><td colspan='3'>" + data.Title + "</ td ></ tr > ");
                    sb.Append("<tr><th>User WindowsId</th><td colspan='3'>" + data.WindowsId + "</ td ></ tr > ");
                    sb.Append("<tr><th>User Role</th><td colspan='3'>Ops User</ td ></ tr > ");
                    sb.Append("<tr><th>User Active Status</th><td colspan='3' style='background-color: #ADFF2F; '>" + data.dStatus + "</ td ></ tr > ");
                    sb.Append("</table></body></html>");
                    //sb.Append("<br />Please click the link to open the project :<a href='" + urlLink + "'>click here</a>");
                    sb.Append("<p>Regards, <br/>Admin.</p>");

                    var emailhelper = new EmailNotification();
                    emailhelper.SendMailToAdmin(toreply, toAddress, toCC, subject, sb.ToString(), true);
                }

                return Json(model);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }
        #endregion

        //ApproveInActiveUsers
        //RejectInActiveUsers

        #endregion

        #region ManageLOV

        #region LOVType

        public ActionResult ManageLOVType(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                //var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 1).ToList();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().ToList();
                var model = data.AsEnumerable();

                int pageSize = 20;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Manage LOVType edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageLOVTypeEdit(long iLTYPEID)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.iLTYPEID == iLTYPEID).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    iLTYPEID = data[0].iLTYPEID,
                    vcTypeName = data[0].vcTypeName,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    iTotal = data[0].iTotal,
                    iLISActive=data[0].iLISActive,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        /// <summary>
        /// Add lov type
        /// </summary>
        /// <returns></returns>
        public ActionResult AddLOVType()
        {
            return View();
        }

        /// <summary>
        /// Validate lov type name details
        /// </summary>
        /// <param name="jsonOfData">The jsonOfData identifier</param>
        /// <returns></returns>
        public JsonResult ValidateTypeNameDetails(Models.LovViewModel jsonOfData)
        {
            try
            {
                ///Validating the existance of the records
                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().CheckLovTypeExistance(jsonOfData.vcTypeName,
                                                                         jsonOfData.iTotal);
                //operationResult = new LOVManager().InsertLovTypeName(jsonOfData[0].,
                //                                                     jsonOfData[0].iVSID,
                //                                                     jsonOfData[0].iWeekID,
                //                                                     data[0].UserName,
                //                                                           Convert.ToInt32(Session["LoginId"]),
                //                                                           (int)Models.RequestStatus.OpsSubmitted,
                //                                                           Convert.ToInt32(Session["CurrentRole"]));

                //return Json(entityListCount[0], JsonRequestBehavior.AllowGet);
                //return null;
                var m = operationResult.Data.ToString();

                return Json(m, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        /// <summary>
        /// Add lov type name with model
        /// </summary>
        /// <param name="model">The model</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult AddLOVTypeName(Models.LovViewModel model)
        {
            try
            {
                OperationResult opsresult = new OperationResult();

                //Getting the User details
                opsresult = new LOVManager().GetUserDetails1();
                var data = ((IEnumerable)opsresult.Data).Cast<Common.DTO.GetUserList>().Where(x => x.UserId == Convert.ToInt32(Session["LoginId"])).Take(1).ToList();

                opsresult = new LOVManager().InsertLovType(model.vcTypeName,
                                                           model.iTotal,
                                                           data[0].UserName);
                

                return RedirectToAction("ManageLOVType");
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Update Lov Type
        /// </summary>
        /// <param name="jsonOfData">The jsonOfData identifier</param>
        /// <returns></returns>
        //[HttpPost]
        public JsonResult UpdateLOVTypeDet(Models.GetLovDetList jsonOfData)
        {
            try
            {
                var model = 0;

                int userId = Convert.ToInt32(Session["LoginId"]);

                string UpdatedBy = Session["CurrentUser"].ToString();

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().UpdateLOVTypeDetails(Convert.ToInt32(jsonOfData.iLTYPEID),
                                                                        jsonOfData.vcTypeName,
                                                                        jsonOfData.iTotal,
                                                                        jsonOfData.iLISActive, userId);

                return Json(model);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region  LOVSubType
        public ActionResult ManageSubLOVType()
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var lovtypedata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().ToList();
                ViewBag.LOVType = lovtypedata.ToList();

                return View();
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Get 1s the yitc report.
        /// </summary>
        /// <returns></returns>
        public ActionResult GetLOVSubType()
        {
            try
            {
                return PartialView("_GetLOVSubType", null);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        ///// <summary>
        ///// Get lov sub type grid data
        ///// </summary>
        ///// <param name="LOVType">The lov type.</param>
        ///// <returns></returns>
        //[HttpPost]
        //public ActionResult getLOVSubTypeData(string LovTypeId)
        //{
        //    try
        //    {
        //        int iTypeId = Convert.ToInt32(LovTypeId);
        //        int UserId= Convert.ToInt32(Session["LoginId"]);

        //        ViewBag.AllRoles = Session["RoleList"];

        //        //string role = Convert.ToString((Session["CurrentUser"] as WBS_Template.Models.UserViewModel).Role);

        //        Session["LOVType"] = LovTypeId;

        //        OperationResult operationResult = new OperationResult();
        //        operationResult = new LOVManager().GetLovSubTypeDetails(iTypeId);

        //        var lovsubtypedata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().ToList();

        //        var joutput = new JavaScriptSerializer().Serialize(lovsubtypedata);

        //        var json = JsonConvert.SerializeObject(lovsubtypedata);

        //        if (lovsubtypedata.Count > 0)
        //        {
        //            ViewBag.SearchLOVSubTypeData = "Count";
        //            ViewBag.SearchLOVSubTypeCount = lovsubtypedata.Count;
        //            ViewBag.SearchNoLOVSubTypeDataCount = "No Data";
        //        }
        //        else
        //        {
        //            ViewBag.SearchLOVSubTypeData = "NoCount";
        //            ViewBag.SearchLOVSubTypeDataCount = lovsubtypedata.Count;
        //            ViewBag.SearchNoLOVSubTypeDataCount = "";
        //        }

        //        var list = JsonConvert.SerializeObject(result1year, Formatting.None,
        //        new JsonSerializerSettings()
        //        {
        //            ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
        //        });

        //        return Content(list, "application/json");
        //    }
        //    catch (GOSPAException exception)
        //    {

        //        LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
        //        return RedirectToAction("ErrorPage", "Home");
        //    }
        //    catch (Exception exception)
        //    {
        //        LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
        //        return RedirectToAction("ErrorPage", "Home");
        //    }
        //}

        #endregion

        #region LeadingIndicators

        public ActionResult ManageLeadingIndicators(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 1).ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Manage leading indicators edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageLeadingIndicatorsEdit(long LovId)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovId == LovId).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    LovId = data[0].LovId,
                    LovTypeId = data[0].LovTypeId,
                    vcLovName = data[0].vcLovName,
                    vcIUMeasure = data[0].vcIUMeasure,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    LovStatus = (int)Models.LOVStatus.Active,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        /// <summary>
        /// Update leading indicators
        /// </summary>
        /// <param name="jsonOfData">The jsonOfData identifier</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult UpdateLeadingIndDetails(Models.GetLovDetList jsonOfData)
        {
            try
            {
                var model = 0;

                int userId = Convert.ToInt32(Session["LoginId"]);

                string UpdatedBy = Session["CurrentUser"].ToString();

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().UpdateLeadingIndicators(Convert.ToInt32(jsonOfData.LovId),
                                                                           jsonOfData.vcLovName,
                                                                           jsonOfData.vcIUMeasure,
                                                                           jsonOfData.LovStatus, userId);

                return Json(model);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region Results
        public ActionResult ManageResults(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 2).ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Manage leading indicators edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageResultsEdit(long LovId)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovId == LovId).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    LovId = data[0].LovId,
                    LovTypeId = data[0].LovTypeId,
                    vcLovName = data[0].vcLovName,
                    vcIUMeasure = data[0].vcIUMeasure,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    LovStatus = (int)Models.LOVStatus.Active,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }
        /// <summary>
        /// Update results
        /// </summary>
        /// <param name="jsonOfData">The jsonOfData identifier</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult UpdateLOVDetails(Models.GetLovDetList jsonOfData)
        {
            try
            {
                var model = 0;

                int userId = Convert.ToInt32(Session["LoginId"]);

                string UpdatedBy = Session["CurrentUser"].ToString();

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().UpdateLeadingIndicators(Convert.ToInt32(jsonOfData.LovId),
                                                                           jsonOfData.vcLovName,
                                                                           jsonOfData.vcIUMeasure,
                                                                           jsonOfData.LovStatus, userId);

                return Json(model);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }
        #endregion

        #region Demand
        public ActionResult ManageDemand(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 3).ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Manage leading indicators edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageDemandEdit(long LovId)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovId == LovId).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    LovId = data[0].LovId,
                    LovTypeId = data[0].LovTypeId,
                    vcLovName = data[0].vcLovName,
                    vcIUMeasure = data[0].vcIUMeasure,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    LovStatus = (int)Models.LOVStatus.Active,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region Output
        public ActionResult ManageOutput(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 4).ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Manage leading indicators edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageOutputEdit(long LovId)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovId == LovId).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    LovId = data[0].LovId,
                    LovTypeId = data[0].LovTypeId,
                    vcLovName = data[0].vcLovName,
                    vcIUMeasure = data[0].vcIUMeasure,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    LovStatus = (int)Models.LOVStatus.Active,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region Overdue

        public ActionResult ManageOverdue(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 5).ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Manage leading indicators edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageOverdueEdit(long LovId)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovId == LovId).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    LovId = data[0].LovId,
                    LovTypeId = data[0].LovTypeId,
                    vcLovName = data[0].vcLovName,
                    vcIUMeasure = data[0].vcIUMeasure,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    LovStatus = (int)Models.LOVStatus.Active,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region InventoryBreakdown
        public ActionResult ManageInventoryBreakdown(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 6).ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }


        /// <summary>
        /// Manage leading indicators edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageInventoryBreakdownEdit(long LovId)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovId == LovId).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    LovId = data[0].LovId,
                    LovTypeId = data[0].LovTypeId,
                    vcLovName = data[0].vcLovName,
                    vcIUMeasure = data[0].vcIUMeasure,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    LovStatus = (int)Models.LOVStatus.Active,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region HeadCount
        public ActionResult ManageHeadCount(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 7).ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }


        /// <summary>
        /// Manage leading indicators edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageHeadCountEdit(long LovId)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovId == LovId).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    LovId = data[0].LovId,
                    LovTypeId = data[0].LovTypeId,
                    vcLovName = data[0].vcLovName,
                    vcIUMeasure = data[0].vcIUMeasure,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    LovStatus = (int)Models.LOVStatus.Active,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region Hours
        public ActionResult ManageHours(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 8).ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }


        /// <summary>
        /// Manage leading indicators edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageHoursEdit(long LovId)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovId == LovId).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    LovId = data[0].LovId,
                    LovTypeId = data[0].LovTypeId,
                    vcLovName = data[0].vcLovName,
                    vcIUMeasure = data[0].vcIUMeasure,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    LovStatus = (int)Models.LOVStatus.Active,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region Productivity
        public ActionResult ManageProductivity(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 9).ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }


        /// <summary>
        /// Manage leading indicators edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageProductivityEdit(long LovId)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovId == LovId).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    LovId = data[0].LovId,
                    LovTypeId = data[0].LovTypeId,
                    vcLovName = data[0].vcLovName,
                    vcIUMeasure = data[0].vcIUMeasure,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    LovStatus = (int)Models.LOVStatus.Active,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region EBIT

        public ActionResult ManageEBIT(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 10).ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }


        /// <summary>
        /// Manage leading indicators edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageEBITEdit(long LovId)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovId == LovId).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    LovId = data[0].LovId,
                    LovTypeId = data[0].LovTypeId,
                    vcLovName = data[0].vcLovName,
                    vcIUMeasure = data[0].vcIUMeasure,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    LovStatus = (int)Models.LOVStatus.Active,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region Capex
        public ActionResult ManageCapex(string sortOrder, string currentFilter, string searchString, int? page)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];
                if (searchString != null)
                {
                    searchString = searchString.Trim();
                }

                OperationResult operationResult = new OperationResult();
                operationResult = new LOVManager().GetLovDetails();

                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovTypeId == 11).ToList();
                var model = data.AsEnumerable();

                int pageSize = 8;
                int pageNumber = (page ?? 1);

                return View(model.ToPagedList(pageNumber, pageSize));
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        /// <summary>
        /// Manage leading indicators edit
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns></returns>
        public JsonResult ManageCapexEdit(long LovId)
        {
            try
            {
                ViewBag.AllRoles = Session["RoleList"];

                OperationResult operationResult = new OperationResult();

                operationResult = new LOVManager().GetLovDetails();
                var data = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetLovDetList>().Where(x => x.LovId == LovId).ToList();
                var model = data.AsEnumerable();

                var obj = new Models.GetLovDetList
                {
                    LovId = data[0].LovId,
                    LovTypeId = data[0].LovTypeId,
                    vcLovName = data[0].vcLovName,
                    vcIUMeasure = data[0].vcIUMeasure,
                    vcCreatedBy = data[0].vcCreatedBy,
                    dCreatedDate = data[0].dCreatedDate,
                    LovStatus = (int)Models.LOVStatus.Active,
                };

                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return null;
            }
        }

        #endregion

        #region--Upload

        public ActionResult UploadPlan()
        {
            try
            {
                OperationResult operationResultYear = new OperationResult();
                operationResultYear = new LOVManager().GetTimeLine();
                ViewBag.Year = ((IEnumerable)operationResultYear.Data);

                //Getting all Value stream data   
                OperationResult operationResult = new OperationResult();

                //operationResult = new LOVManager().GetVSData();

                operationResult = new LOVManager().GetValueStreamData();


                var vsdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetValueStreamList>().ToList();
                GetValueStreamList ddlAll = new GetValueStreamList();

                vsdata.Add(ddlAll);

                var vsddl = from s in vsdata
                            orderby s.vSId
                            select s;
                ViewBag.ValueStream = vsddl.ToList();
                    
                return View();
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        [HttpPost]
        public ActionResult UploadPlan(HttpPostedFileBase importFile, string ValueStream,int Year)
        {
            //if (importFile == null) return Json(new { Status = 0, Message = "No File Selected" });
            try
            {
                string filePath = string.Empty;
                OperationResult operationResultYear = new OperationResult();
                operationResultYear = new LOVManager().GetTimeLine();
                ViewBag.Year = ((IEnumerable)operationResultYear.Data);

                //Getting all Value stream data   
                OperationResult operationResult = new OperationResult();

                //operationResult = new LOVManager().GetVSData();

                operationResult = new LOVManager().GetValueStreamData();


                var vsdata = ((IEnumerable)operationResult.Data).Cast<Common.DTO.GetValueStreamList>().ToList();
                GetValueStreamList ddlAll = new GetValueStreamList();

                vsdata.Add(ddlAll);

                var vsddl = from s in vsdata
                            orderby s.vSId
                            select s;
                ViewBag.ValueStream = vsddl.ToList();

                if (importFile != null)
                {
                    string path = Server.MapPath("~/Uploads/");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    filePath = path + Path.GetFileName(importFile.FileName);

                    importFile.SaveAs(filePath);
                    var dtable = SiteHelpers.HelperExtentions.ExcelToDatatable(filePath);
                    OperationResult result = new OperationResult();
                    result = new ReportManager().SavePlan(dtable, ValueStream, Year);

                    




                }


                return View();
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }

        public ActionResult UploadActuals()
        {
            try
            {
                List<Uploadyearddl> ddlAll = new List<Uploadyearddl>
                {
                    new Uploadyearddl {yearid=1,year=2017 },
                    new Uploadyearddl {yearid=2,year=2018 }
                };
                //ddlAll.iVSID = 0;
                //ddlAll.vcValueStream = "All";
                //vsdata.Add(ddlAll);

                //var vsddl = from s in vsdata
                //            orderby s.iVSID
                //            select s;
                ViewBag.year = ddlAll.ToList();

                return View();
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }


        [HttpPost]
        public ActionResult UploadActuals(HttpPostedFileBase importFile)
        {
            //if (importFile == null) return Json(new { Status = 0, Message = "No File Selected" });
            try
            {
                string filePath = string.Empty;
                if (importFile != null)
                {
                    string path = Server.MapPath("~/Uploads/");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    filePath = path + Path.GetFileName(importFile.FileName);
                    string extension = Path.GetExtension(importFile.FileName);
                    importFile.SaveAs(filePath);

                    string conString = string.Empty;
                    switch (extension)
                    {
                        case ".xls": //Excel 97-03.
                            conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                            break;
                        case ".xlsx": //Excel 07 and above.
                            conString = ConfigurationManager.ConnectionStrings["Excel07ConString"].ConnectionString;
                            break;
                    }

                    DataTable dt = new DataTable();
                    DataTable dt2 = new DataTable();
                    conString = string.Format(conString, filePath);
                    Exceldatatable(conString, "Jan_", 1);
                    Exceldatatable(conString, "Feb_", 2);
                    Exceldatatable(conString, "Mar_", 3);
                    Exceldatatable(conString, "Apr_", 4);
                    Exceldatatable(conString, "May_", 5);
                    Exceldatatable(conString, "Jun_", 6);
                    Exceldatatable(conString, "Jul_", 7);
                    Exceldatatable(conString, "Aug_", 8);
                    Exceldatatable(conString, "Sep_", 9);
                    Exceldatatable(conString, "Oct_", 10);
                    Exceldatatable(conString, "Nov_", 11);
                    Exceldatatable(conString, "Dec_", 12);
                }
                return View();
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return RedirectToAction("ErrorPage", "Home");
            }
        }


        [NonAction]
        public void Exceldatatable(string conString, string appendtext, int monthId)
        {
            DataTable dt = new DataTable();

            using (OleDbConnection connExcel = new OleDbConnection(conString))
            {
                using (OleDbCommand cmdExcel = new OleDbCommand())
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        cmdExcel.Connection = connExcel;
                        //Get the name of First Sheet.                           

                        connExcel.Open();
                        DataTable dtExcelSchema;
                        dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        DataSet ds = new DataSet();

                        for (int i = 0; i < dtExcelSchema.Rows.Count; i++)
                        {
                            DataTable dtnew = new DataTable();
                            string sheetName = dtExcelSchema.Rows[i]["TABLE_NAME"].ToString();
                            connExcel.Close();

                            //Read Data from First Sheet.
                            connExcel.Open();
                            cmdExcel.CommandText = "SELECT vcTypeName,vcLovName," + appendtext + "act," + appendtext + "plan," + appendtext + "LeHFM," + appendtext + "priorPA," + appendtext + "MTD," + appendtext + "est," + appendtext + "iVP," + appendtext + "iVartoLEHFM," + appendtext + "iVartoPriorPA,VS,Year From [" + sheetName + "]"; ;
                            odaExcel.SelectCommand = cmdExcel;
                            odaExcel.Fill(dtnew);
                            dtnew.Columns.Add("MonthId", typeof(Int32));
                            foreach (DataRow row in dtnew.Rows)
                            {
                                row["MonthId"] = monthId;
                            }

                            dt.Merge(dtnew);

                        }
                        conString = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
                        using (SqlConnection con = new SqlConnection(conString))
                        {
                            using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                            {
                                //Set the database table name.
                                sqlBulkCopy.DestinationTableName = "dbo.tbl_actuals";
                                //[OPTIONAL]: Map the Excel columns with that of the database table                                
                                sqlBulkCopy.ColumnMappings.Add("vcTypeName", "vcTypeName");
                                sqlBulkCopy.ColumnMappings.Add("vcLovName", "vcLovName");
                                sqlBulkCopy.ColumnMappings.Add(appendtext + "act", "act");
                                sqlBulkCopy.ColumnMappings.Add(appendtext + "plan", "plan");
                                sqlBulkCopy.ColumnMappings.Add(appendtext + "LeHFM", "LeHFM");
                                sqlBulkCopy.ColumnMappings.Add(appendtext + "priorPA", "priorPA");
                                sqlBulkCopy.ColumnMappings.Add(appendtext + "MTD", "MTD");
                                sqlBulkCopy.ColumnMappings.Add(appendtext + "est", "est");
                                sqlBulkCopy.ColumnMappings.Add(appendtext + "iVP", "iVP");
                                sqlBulkCopy.ColumnMappings.Add(appendtext + "iVartoLEHFM", "iVartoLEHFM");
                                sqlBulkCopy.ColumnMappings.Add(appendtext + "iVartoPriorPA", "iVartoPriorPA");
                                sqlBulkCopy.ColumnMappings.Add("VS", "VS");
                                sqlBulkCopy.ColumnMappings.Add("MonthId", "MonthId");
                                sqlBulkCopy.ColumnMappings.Add("Year", "Year");

                                con.Open();
                                sqlBulkCopy.WriteToServer(dt);
                                con.Close();
                            }
                        }
                    }
                }
            }

        }
        #endregion--Upload


        #endregion
    }
}