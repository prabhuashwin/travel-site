﻿using GOSPA.DataAccess.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOSPA.WebApp.SiteHelpers
{
    /// <summary>
    /// Notification Type
    /// </summary>
    public enum NotificationType
    {
        /// <summary>
        /// The process
        /// </summary>
        Process,
        /// <summary>
        /// The reminder
        /// </summary>
        Reminder
    }
    interface INotification
    {
        /// <summary>
        /// Notifies the stake holder.
        /// </summary>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="unitofwork">The unitofwork.</param>
        /// <param name="notificationtype">The notificationtype.</param>
        void NotifyStakeHolder(long requestId, UnitOfWork unitofwork, NotificationType notificationtype);
    }
}
