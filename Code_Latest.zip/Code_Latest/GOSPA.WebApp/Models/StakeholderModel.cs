﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GOSPA.WebApp.Models
{
    public class StakeholderModel
    {
    }
    /// <summary>
    ///
    /// </summary>
    public enum RequestStakeholderType
    {
        /// <summary>
        /// The OpsUser
        /// </summary>
        OpsUser = 0,
        /// <summary>
        /// The Finance Controller
        /// </summary>
        FinanceController = 1,
        /// <summary>
        /// The LeadershipTeam
        /// </summary>
        LeadershipTeam = 2,
    }

    /// <summary>
    ///
    /// </summary>
    public enum RequestStakeholderStatus
    {
        /// <summary>
        /// The not reached
        /// </summary>
        [Display(Name = "Not Reached")]
        NotReached,
        /// <summary>
        /// The pending
        /// </summary>
        [Display(Name = "Pending")]
        Pending,
        /// <summary>
        /// The cancelled
        /// </summary>
        [Display(Name = "Cancelled")]
        Cancelled,
        /// <summary>
        /// The approved
        /// </summary>
        [Display(Name = "Approved")]
        Approved,
        /// <summary>
        /// The waiting user input
        /// </summary>
        [Display(Name = "Waiting For User Input")]
        WaitingUserInput,
        /// <summary>
        /// The submitted
        /// </summary>
        [Display(Name = "Submitted")]
        Submitted,
    }
}