﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
*
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name          :             LovViewModel.cs
* File Desc          :             This file contains code pertaining to the class for
*                                   LOV View Model.
*                    
*
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 10-Apr-2019        Ashwin/Govind           Initial Creation
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GOSPA.WebApp.Models;

namespace GOSPA.WebApp.Models
{
    /// <summary>
    /// Enum for LOV Type
    /// </summary>
    public enum LOVType
    {
        /// <summary>
        /// All
        /// </summary>
        All,
        /// <summary>
        /// The pmo
        /// </summary>
        PMO,
        /// <summary>
        /// The itc
        /// </summary>
        ITC
    }

    /// <summary>
    /// Enum for LOV Status
    /// </summary>
    public enum LOVStatus
    {
        /// <summary>
        /// The in active
        /// </summary>
        InActive,
        /// <summary>
        /// The active
        /// </summary>
        Active,
        /// <summary>
        /// The closed
        /// </summary>
        Closed
    }

    /// <summary>
    /// LOV View Model
    /// </summary>
    public class LovViewModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LovViewModel"/> class.
        /// </summary>
        public LovViewModel()
        {
            FilterList = new List<long>();
        }

        public long iLTYPEID { get; set; }

        public string vcTypeName { get; set; }

        public int iTotal { get; set; }

        public int iLISActive { get; set; }

        public string vcLOVName { get; set; }

        public string vcIUMeasure { get; set; }

        public string vcCreatedBy { get; set; }

        public int iISActive { get; set; }

        public DateTime dCreatedDate { get; set; }

        public int iSTotal { get; set; }

        public int iOrder { get; set; }

        /// <summary>
        /// Gets or sets the filter list.
        /// </summary>
        /// <value>
        /// The filter list.
        /// </value>
        public List<long> FilterList { get; set; }
    }

    /// <summary>
    ///
    /// </summary>
    public class VW_GetUserDetails
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public long Id { get; set; }
        /// <summary>
        /// Gets or sets the name of the user.
        /// </summary>
        /// <value>
        /// The name of the user.
        /// </value>
        public string UserName { get; set; }
        /// <summary>
        /// Gets or sets the login identifier.
        /// </summary>
        /// <value>
        /// The login identifier.
        /// </value>
        public string LoginId { get; set; }
        /// <summary>
        /// Gets or sets the user email.
        /// </summary>
        /// <value>
        /// The user email.
        /// </value>
        public string UserEmail { get; set; }
        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>
        /// The title.
        /// </value>
        public string Title { get; set; }
        /// <summary>
        /// Gets or sets the user role.
        /// </summary>
        /// <value>
        /// The user role.
        /// </value>
        public UserRoleTypes UserRole { get; set; }
        /// <summary>
        /// Gets or sets the user status.
        /// </summary>
        /// <value>
        /// The user status.
        /// </value>
        public LOVStatus UserStatus { get; set; }
    }
    public class UpdateValuestreams
    {
        public string Id { get; set; }
        public string LoginId { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string[] vs { get; set; }
    }

    public class GetUserList
    {
        public long Id { get; set; }
        public string UserName { get; set; }
        public string LoginId { get; set; }
        public string UserEmail { get; set; }
        public string Title { get; set; }
        public string CreatedBy { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd MMM yyyy}")]
        public DateTime CreatedDate { get; set; }
        public string UserRole { get; set; }
        public Nullable<int> UserStatus { get; set; }

        public List<string> AllValueStream { get; set; }
        public List<int> AllValueStream_val { get; set; }
        public List<string> AssignedVS { get; set; }
        public List<int> AssignedVal { get; set; }

    }
    public class Uploadyearddl
    {
        public int yearid { get; set; }
        public int year { get; set; }
    }


    public class VM_LOVList_User
    {
        public long vSId { get; set; }
        public string vcValueStream { get; set; }
    }

    public class GetGriddata
    {
        public string vcTypeName { get; set; }
        public string vcLovName { get; set; }
        public int iYear { get; set; }
        public int imONth { get; set; }
        public int iTimelineID { get; set; }
        public int iVSID { get; set; }
        public Nullable<double> iplan { get; set; }
        public Nullable<double> iLE_HFM { get; set; }
        public Nullable<double> iPriorPA { get; set; }
        public Nullable<double> iMTD { get; set; }
        public Nullable<double> iActuals { get; set; }
        public Nullable<double> iEST { get; set; }
        public Nullable<double> iVP { get; set; }
        public Nullable<double> iVartoLEHFM { get; set; }
        public Nullable<double> iVartoPriorPA { get; set; }
        public string Comments { get; set; }
        public Nullable<int> iIsMonthData { get; set; }
        public Nullable<int> iQuarterID { get; set; }
        public Nullable<int> iWeekID { get; set; }
    }

    public class GetLovDetList
    {
        public long LovId { get; set; }
        public long LovTypeId { get; set; }
        public string vcTypeName { get; set; }
        public string vcLovName { get; set; }
        public string vcIUMeasure { get; set; }
        public Nullable<DateTime> dCreatedDate { get; set; }
        public string vcCreatedBy { get; set; }
        public Nullable<int> LovStatus { get; set; }
        public long iLTYPEID { get; set; }
        public int iTotal { get; set; }
        public int iLISActive { get; set; }
        public int iISActive { get; set; }
        public int iSTotal { get; set; }
        public int iOrder { get; set; }
    }

}