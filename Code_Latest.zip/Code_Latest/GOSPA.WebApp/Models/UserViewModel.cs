﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GOSPA.WebApp.Models
{
    /// <summary>
    /// Enum for User Role Types
    /// </summary>
    public enum UserRoleTypes
    {
        
        /// The Operations User
        /// </summary>
        [Display(Name = "OPS User")]
        OPSUser = 1,
        /// <summary>
        /// The Finance Controller
        /// </summary>
        [Display(Name = "Financial Controller")]
        FinancialController = 2,
        /// <summary>
        /// The Leadership Team
        /// </summary>
        [Display(Name = "LeaderShip Team")]
        LeaderShipTeam = 3,
        /// <summary>
        /// Admin Operations User
        /// </summary>
        /// <summary>
        [Display(Name = "Admin")]
        Admin = 4,

        /// <summary>
        /// The Sbu head 
        /// </summary>
        [Display(Name = "SBU Head")]
        SBUHead = 5
    }

    public class UserViewModel
    {

        public long Id { get; set; }

        public string Name { get; set; }

        public string WindowsId { get; set; }

        public string Email { get; set; }

        public UserRoleTypes Role { get; set; }

        public int RoleId { get; set; }
    }

    public enum UserActiveStatus
    {
        /// <summary>
        /// The new
        /// </summary>
        InActive,
        /// <summary>
        /// The active
        /// </summary>
        Active
    }
}