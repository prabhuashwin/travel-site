﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GOSPA.WebApp.Models
{
    public class RequestViewModel
    {
    }

    public enum RequestStatus
    {
        /// <summary>
        /// The draft
        /// </summary>
        Draft,
        // <summary>
        /// The Ops user submitted
        /// </summary>
        OpsSubmitted,
        // <summary>
        /// The FC user submitted
        /// </summary>
        FCSubmitted,
        /// <summary>
        /// The finalized
        /// </summary>
        Finalized,
        /// <summary>
        /// The notassigned
        /// </summary>
        NotAssigned,
        /// <summary>
        /// The FCRejection
        /// </summary>
        FCRejection,
        /// <summary>
        /// The LTRejection
        LTRejection
    }

    public class RequestModel
    {
        public long RId { get; set; }
        public int iSheetID { get; set; }
        public int iRequestedById { get; set; }
        public int iRStatus { get; set; }
        public Nullable<DateTime> dRequestedOn { get; set; }
        public Nullable<DateTime> dUpdatedOn { get; set; }
        public int iRejectionCount { get; set; }
        public string vComments { get; set; }

    }
}