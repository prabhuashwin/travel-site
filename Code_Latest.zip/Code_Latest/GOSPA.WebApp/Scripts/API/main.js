var columnDefs = [
    {
        headerName: 'Monthly',
        children: [
            { headerName: 'Leading Indicators', field: 'Leading Indicators', width: 300, filter: 'agTextColumnFilter', pinned: 'left' },
        ]
    },
    {
        headerName: 'Week1',
        children: [
    { headerName: 'Nov Actuals', field: 'Actuals', width: 250 },
    { headerName: 'Dec Plan', columnGroupShow: 'open', field: 'Dec Plan', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec LE FHM', columnGroupShow: 'open', field: 'Dec LE FHM', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec Prior PA', columnGroupShow: 'open', field: 'Dec Prior PA', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec MTD', columnGroupShow: 'open', field: 'Dec MTD', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec Est', columnGroupShow: 'open', field: 'Dec Est', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec VP', columnGroupShow: 'open', field: 'Dec VP', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec Var LE FHM', columnGroupShow: 'open', field: 'Dec Var LE FHM', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec Var Prior PA', columnGroupShow: 'open', field: 'Dec Var Prior PA', width: 150, filter: 'agNumberColumnFilter' },
        ]
    },
    {
        headerName: 'Week2',
        children: [
            { headerName: '', field: '', width: 250 },
            { headerName: 'Jan Plan', columnGroupShow: 'open', field: 'Jan Plan', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan LE FHM', columnGroupShow: 'open', field: 'Jan LE FHM', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan Prior PA', columnGroupShow: 'open', field: 'Jan Prior PA', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan MTD', columnGroupShow: 'open', field: 'Jan MTD', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan Est', columnGroupShow: 'open', field: 'Jan Est', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan VP', columnGroupShow: 'open', field: 'Jan VP', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan Var LE FHM', columnGroupShow: 'open', field: 'Jan Var LE FHM', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan Var Prior PA', columnGroupShow: 'open', field: 'Jan Var Prior PA', width: 150, filter: 'agNumberColumnFilter' },
        ]
    },
    {
        headerName: 'Quarter',
        children: [
            { headerName: '', field: '', width: 250 },
            { headerName: 'Q3 Plan', columnGroupShow: 'open', field: 'Q3 Plan', editable: 'true', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Q3 Est', columnGroupShow: 'open', field: 'Q3 Est', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Q3 variance', columnGroupShow: 'open', field: 'Q3 variance', width: 150, filter: 'agNumberColumnFilter' },
        ]
    },
{
    headerName: 'Comments',
    children: [
        { headerName: 'Comments', columnGroupShow: 'open', field: 'Comments', editable: 'true', width: 300, filter: 'agNumberColumnFilter' },
    ]
},
//{
//    headerName: '2020',
//    children: [
//        { headerName: '', field: '', width: 70 },
//        { headerName: 'January', columnGroupShow: 'open', field: 'JanuaryP2', width: 100, filter: 'agNumberColumnFilter' },
//        { headerName: 'February', columnGroupShow: 'open', field: 'FebruaryP2', width: 100, filter: 'agNumberColumnFilter' },
//        { headerName: 'March', columnGroupShow: 'open', field: 'MarchP2', width: 100, filter: 'agNumberColumnFilter' },
//        { headerName: 'April', columnGroupShow: 'open', field: 'AprilP2', width: 100, filter: 'agNumberColumnFilter' },
//        { headerName: 'May', columnGroupShow: 'open', field: 'MayP2', width: 100, filter: 'agNumberColumnFilter' },
//        { headerName: 'June', columnGroupShow: 'open', field: 'JuneP2', width: 100, filter: 'agNumberColumnFilter' },
//        { headerName: 'July', columnGroupShow: 'open', field: 'JulyP2', width: 100, filter: 'agNumberColumnFilter' },
//        { headerName: 'August', columnGroupShow: 'open', field: 'AugustP2', width: 100, filter: 'agNumberColumnFilter' },
//        { headerName: 'September', columnGroupShow: 'open', field: 'SeptemberP2', width: 100, filter: 'agNumberColumnFilter' },
//        { headerName: 'October', columnGroupShow: 'open', field: 'OctoberP2', width: 100, filter: 'agNumberColumnFilter' },
//        { headerName: 'November', columnGroupShow: 'open', field: 'NovemberP2', width: 100, filter: 'agNumberColumnFilter' },
//        { headerName: 'December', columnGroupShow: 'open', field: 'DecemberP2', width: 100, filter: 'agNumberColumnFilter' }
//    ]
//},
//{
//    headerName: '',
//    children: [
//        { headerName: 'Cumulative Actuals', field: 'athlete', width: 150, filter: 'agTextColumnFilter' },
//        { headerName: 'Budget Remaining', field: 'BudgetRemaining', width: 90, filter: 'agNumberColumnFilter' },
//        { headerName: 'Budget Utilized', field: 'BudgetUtilized', width: 120 },
//        { headerName: 'Comments', field: 'Comments', width: 120 }
//    ]
//},
];

var gridOptions = {
    defaultColDef: {
        sortable: true,
        resizable: true,
        filter: true,
        editable: true,
        onCellValueChanged: function (params) {
            //alert("Cell value changed");
            //alert(params.newValue);
            if (params.oldValue != params.newValue) {
                params.colDef.cellStyle = function (params) {
                    return { backgroundColor: 'green' };
                }
            }
        }
    },
    debug: true,
    columnDefs: columnDefs,
    suppressLoadingOverlay: true,
    rowData: null
};

// setup the grid after the page has finished loading
//document.addEventListener('DOMContentLoaded', function () {
//$('#dvLItbl').empty();

let LIDiv = document.querySelector('#dvLItbl');
new agGrid.Grid(LIDiv, gridOptions);

$.getJSON("/Scripts/API/LeadingIndicator_JSON.json", function (json) {
    gridOptions.api.setRowData(json);
});

//});