﻿ManageLov = function () {
    this.searchTargets = {
        textControl: null,
        valueControl: null,
        idControl: null,
        entityNameControl: null,
        entityAddressControl: null
    };

    this.SCometClassifier = function (mode) {
        if (mode === 'close') {
            document.getElementById("pnlAddLOV").style.display = "none";
            document.getElementById('tabScometClassifier').click();
        }
        else {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("wbs-vertical-tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            document.getElementById("pnlAddLOV").style.display = "block";
            $('#pnlAddLOV').attr("display", "block");
            $.ajax({
                cache: false,
                type: "GET",
                url: "/LOV/AddLOV_SCometClassifier",
                contentType: "application/json; charset=utf-8",
                beforeSend: function () {
                    apiCommon.ShowWait(true);
                },
                success: function (response) {
                    $('#pnlAddLOV').html(response);
                },
                error: function (response) {
                    alert(response);

                },
                complete: function (jqXHR, textStatus) {
                    apiCommon.CloseWait();
                }
            });
        }
    };

    this.AddITCFocal = function (mode) {
        if (mode === 'close') {
            document.getElementById("pnlITCFocal").style.display = "none";
            document.getElementById('tabITCFocal').click();
        }
        else {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("wbs-vertical-tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            document.getElementById("pnlAddLOV").style.display = "block";
            $('#pnlAddLOV').attr("display", "block");
            $.ajax({
                cache: false,
                type: "GET",
                url: "/LOV/AddLOV_ITCFocal",
                contentType: "application/json; charset=utf-8",
                beforeSend: function () {
                    apiCommon.ShowWait(true);
                },
                success: function (response) {
                    $('#pnlAddLOV').html(response);
                },
                error: function (response) {
                    alert(response);

                },
                complete: function (jqXHR, textStatus) {
                    apiCommon.CloseWait();
                }
            });
        }
    };

    this.InitiateSearch = function (targetTextControl, targetValueControl, targetIdControl) {
        var targetText = $('#' + targetTextControl)[0];
        var targetValue = $('#' + targetValueControl)[0];
        if (targetIdControl !== "undefined" && targetIdControl.length > 0) {
            var targetId = $('#' + targetIdControl)[0];
            this.searchTargets.idControl = targetId;
        }
        this.searchTargets.textControl = targetText;
        this.searchTargets.valueControl = targetValue;

        $('#tblSearchResult').find("tr:gt(0)").remove();
        $('#pnlSearchPerson').modal('show');

    };

    this.SearchPeople = function () {
        var firstName = $('#txtSearchFN').val();
        var lastName = $('#txtSearchLN').val();
        if ((firstName === "undefined" || firstName.length <= 2) && (lastName === "undefined" || lastName.length <= 2)) {
            alert('Please provide First Name or Last Name');
            return;
        }
        apiCommon.SearchUser(firstName, lastName, document.getElementById("tblSearchResult"), "SearchPeopleValidate");
    };

    this.SearchPeopleValidate = function (elem) {
        var tr = $(elem).parent().parent();
        var searchType = $("#txtLOVName").val();
        var role = 1;
        //if (searchType == "Approver") {
        //    role = 2

        //}
        var winId = tr[0].cells[0].children[0].innerText;
        var usrModel = {
            Name: tr[0].cells[1].innerText,
            Email: tr[0].cells[3].innerText,
            WindowsId: winId,
            Title: tr[0].cells[2].innerText,
            Role: role

        };
        textControl = this.searchTargets.textControl;
        valueControl = this.searchTargets.valueControl;
        idControl = this.searchTargets.idControl;
        $.ajax({
            type: "POST",
            url: "/Home/GetLOVUserDetails",
            data: '{model:' + JSON.stringify(usrModel) + '}',
            contentType: "application/json; charset=utf-8",
            beforeSend: function () {
                apiCommon.ShowWait(true);
            },
            success: function (response) {
                if (textControl != null) {
                    $(textControl).val(response.Name);
                }
                if (valueControl != null) {
                    $(valueControl).val(response.Email);
                }
                if (idControl != null) {
                    $(idControl).val(response.Id);
                }
            },
            error: function (xhr, errortext) {
                apiCommon.HandleError(xhr);
            },
            complete: function () {
                apiCommon.CloseWait();
                $('#pnlSearchPerson').modal('hide');
            }
        });
    };

    this.ValidateAddITCFocal = function () {
        var res = true;
        res = apiCommon.ValidateForm();
        //if ($('#txtLOVValue4').val().length <= 0 && res == true) {
        //    apiCommon.Notify("Validation Error", "No Source Company selected.", "Error");
        //    res = false;
        //}

        return res;
    }

    function ToJavaScriptDate(value) { //To Parse Date from the Returned Parsed Date
        var pattern = /Date\(([^)]+)\)/;
        var results = pattern.exec(value);
        var dt = new Date(parseFloat(results[1]));
        return (dt.getMonth() + 1) + "/" + dt.getDate() + "/" + dt.getFullYear();
    }

    this.InitiateManageUsers = function (data) {

        var id = data;

        var vals = $("#SelectedItems option").map(function () {
            return this.text;
        }).get().join(',');

        var updatedValues = $('#SelectedItems option').text();

        $.ajax({
            url: '/LOV/ManageUserEdit',
            dataType: "json",
            data: "id=" + id,
            type: "GET",
            success: function (result) {
                $("#SelectBox2").empty();
                $("#SelectedItems").empty();
                console.log(result);
                
                $("#txtUserName").val(result.UserName);
                $("#txtUserEmail").val(result.UserEmail);
                $("#txtRole").val(result.UserRole);
                $('#SelectBox2').val(result.AllValueStream);
                $('#SelectedItems').val(result.AllValueStream);

                var mySelect = $('#SelectBox2');
                $.each(result.AllValueStream, function (val, text) {
                    mySelect.append(
                        $('<option></option>').val(val).html(text)
                    );
                });

                //var separatedArray = result.AllValueStream.split(',');

                var mySelect2 = $('#SelectedItems');
                $.each(result.AllValueStream, function (val, text) {
                    mySelect2.append(
                        $('<option></option>').val(val).html(text)
                    );
                });

                //var element = document.getElementById('SelectedItems');

                //sortSelect(element);
                
                //if (result.UserRole === 0) {
                //    $("div.id_101 select").val("0");
                //}
                //else if (result.UserRole === 1) {
                //    $("div.id_101 select").val("1");
                //}
                //else if (result.UserRole === 2) {
                //    $("div.id_101 select").val("2");
                //}
                //else if (result.UserRole === 3) {
                //    $("div.id_101 select").val("3");
                //}
                //else if (result.UserRole === 4) {
                //    $("div.id_101 select").val("4");
                //}

                //if (result.UserStatus === 1) {
                //    $("div.id_100 select").val("1");
                //}
                //else {
                //    $("div.id_100 select").val("0");
                //}

                $('#pnlUserDetailsEdit').modal('show');
            }
        });

    };

    this.InitiateManageOpsUsers = function (data) {

        var id = data;

        var vals = $("#SelectedItems option").map(function () {
            return this.text;
        }).get().join(',');

        var updatedValues = $('#SelectedItems option').text();

        $.ajax({
            url: '/LOV/ManageOpsUserEdit',
            dataType: "json",
            data: "id=" + id,
            type: "GET",
            success: function (result) {
                //$("#SelectBox2").empty();
                //$("#SelectedItems").empty();
                //console.log(result);
                $("#txtUserId").val(result.Id)
                $("#txtUserName").val(result.UserName);
                $("#txtUserEmail").val(result.UserEmail);
                $("#txtRole").val(result.UserRole);
               // $('#SelectBox2').val(result.AssignedVS[0]);
                //$('#SelectedItems').val(result.AllValueStream);
                //$("#SelectBox2 option").remove();
                var mySelect = $('#SelectBox2');
                $.each(result.AllValueStream, function (val, text) {
                    //var optionVal = $(this).val();
                   
                    if ($('#SelectBox2 option[value="' + val + '"]').length == 0) {

                        mySelect.append(
                            $('<option></option>').val(val).html(text)
                        );
                    }
                });
                //$("#SelectBox2 > [value=" + result.AssignedVS[0] + "]").attr("selected", "true");
                $("#SelectBox2 option").each(function () {
                    if ($(this).html() == result.AssignedVS[0]) {
                        $(this).attr("selected", "selected");
                        return;
                    }
                });

                //var element = document.getElementById('SelectedItems');

                //sortSelect(element);

                //if (result.UserRole === 0) {
                //    $("div.id_101 select").val("0");
                //}
                //else if (result.UserRole === 1) {
                //    $("div.id_101 select").val("1");
                //}
                //else if (result.UserRole === 2) {
                //    $("div.id_101 select").val("2");
                //}
                //else if (result.UserRole === 3) {
                //    $("div.id_101 select").val("3");
                //}
                //else if (result.UserRole === 4) {
                //    $("div.id_101 select").val("4");
                //}

                //if (result.UserStatus === 1) {
                //    $("div.id_100 select").val("1");
                //}
                //else {
                //    $("div.id_100 select").val("0");
                //}

                $('#pnlUserDetailsEdit').modal('show');
            }
        });

    };

    this.InitiateManageFinanceController = function (data) {

        var id = data;

        var vals = $("#SelectedItems option").map(function () {
            return this.text;
        }).get().join(',');

        var updatedValues = $('#SelectedItems option').text();

        $.ajax({
            url: '/LOV/ManageFinanceControllerEdit',
            dataType: "json",
            data: "id=" + id,
            type: "GET",
            success: function (result) {
                $("#SelectBox2").empty();
                $("#SelectedItems").empty();
                console.log(result);
                $("#txtUserId").val(result.Id)
                $("#txtUserName").val(result.UserName);
                $("#txtUserEmail").val(result.UserEmail);
                $("#txtRole").val(result.UserRole);
                $('#SelectBox2').val(result.AllValueStream);
                $('#SelectedItems').val(result.AssignedVS);
                var itemsToAdd = [];

                var avsval = result.AllValueStream_val
                var arr = avsval.toString().split(',');

                var i = 0;
                var mySelect = $('#SelectBox2');
                $.each(result.AllValueStream, function (val, text) {
                    mySelect.append(
                        $('<option  value=' + avsval[i] + '></option>').val(val).html(text)
                    );
                    i++;
                });

                //var separatedArray = result.AllValueStream.split(',');

                var mySelect2 = $('#SelectedItems');

                var j = 0;
                var jarr = result.AssignedVal;
                $.each(result.AssignedVS, function (val, text) {
                    mySelect2.append(
                        $('<option value=' + jarr[j] + '></option>').val(val).html(text)
                    );
                    j++;
                });

                //var element = document.getElementById('SelectedItems');

                //sortSelect(element);

                //if (result.UserStatus === 1) {
                //    $("div.id_100 select").val("1");
                //}
                //else {
                //    $("div.id_100 select").val("0");
                //}

                $('#pnlFCDetailsEdit').modal('show');
            }
        });

    };

    this.InitiateManageLeadershipTeam = function (data) {

        var id = data;

        var vals = $("#SelectedItems option").map(function () {
            return this.text;
        }).get().join(',');

        var updatedValues = $('#SelectedItems option').text();

        $.ajax({
            url: '/LOV/ManageLeadershipTeamEdit',
            dataType: "json",
            data: "id=" + id,
            type: "GET",
            success: function (result) {
                $("#SelectBox2").empty();
                $("#SelectedItems").empty();
                console.log(result);

                $("#txtUserName").val(result.UserName);
                $("#txtUserEmail").val(result.UserEmail);
                $("#txtRole").val(result.UserRole);
                $('#SelectBox2').val(result.AllValueStream);
                $('#SelectedItems').val(result.AllValueStream);

                var mySelect = $('#SelectBox2');
                $.each(result.AllValueStream, function (val, text) {
                    mySelect.append(
                        $('<option></option>').val(val).html(text)
                    );
                });

                //var separatedArray = result.AllValueStream.split(',');

                var mySelect2 = $('#SelectedItems');
                $.each(result.AllValueStream, function (val, text) {
                    mySelect2.append(
                        $('<option></option>').val(val).html(text)
                    );
                });

                //var element = document.getElementById('SelectedItems');

                //sortSelect(element);


                $('#pnlLTDetailsEdit').modal('show');
            }
        });

    };

    this.InitiateApproveInActiveUser = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ApproveInActiveUser',
            dataType: "json",
            data: "id=" + id,
            type: "POST",
            success: function (result) {
                console.log(result);

                $("#txtUserName").val(result.UserName);
                $("#txtUserEmail").val(result.UserEmail);
                $("#txtTitle").val(result.Title);

                if (result.UserRole === 0) {
                    $("div.id_101 select").val("0");
                }
                else if (result.UserRole === 1) {
                    $("div.id_101 select").val("1");
                }
                else if (result.UserRole === 2) {
                    $("div.id_101 select").val("2");
                }
                else if (result.UserRole === 3) {
                    $("div.id_101 select").val("3");
                }
                else if (result.UserRole === 4) {
                    $("div.id_101 select").val("4");
                }

                if (result.UserStatus === 1) {
                    $("div.id_100 select").val("1");
                }
                else {
                    $("div.id_100 select").val("0");
                }

                $('#pnlUserDetailsEdit').modal('show');
            }
        });

    };

    this.InitiateRejectInActiveUser = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/RejectInActiveUser',
            dataType: "json",
            data: "id=" + id,
            type: "GET",
            success: function (result) {
                console.log(result);

                $("#txtUserName").val(result.UserName);
                $("#txtUserEmail").val(result.UserEmail);
                $("#txtTitle").val(result.Title);

                if (result.UserRole === 0) {
                    $("div.id_101 select").val("0");
                }
                else if (result.UserRole === 1) {
                    $("div.id_101 select").val("1");
                }
                else if (result.UserRole === 2) {
                    $("div.id_101 select").val("2");
                }
                else if (result.UserRole === 3) {
                    $("div.id_101 select").val("3");
                }
                else if (result.UserRole === 4) {
                    $("div.id_101 select").val("4");
                }

                if (result.UserStatus === 1) {
                    $("div.id_100 select").val("1");
                }
                else {
                    $("div.id_100 select").val("0");
                }

                $('#pnlUserDetailsEdit').modal('show');
            }
        });

    };

    this.ValidateSubmit = function () {
        apiCommon.ShowWait(true, "Submitting the request...");
        var res = true;
        //Basic Validation
        res = apiCommon.ValidateForm();
        if (res) {
            var overseasAuthType = $("#txtOtherType1 option:selected").val();
            var overseasAuthNumber = $('#txtOtherType2').val();

            var isFound = false;
            if (overseasAuthType > 0) {
                isFound = true;
            }

            if (isFound == true) {
                if (overseasAuthType == "850") {
                    $('#txtOtherType1').removeClass("bg-warning");
                    $('#txtOtherType2').removeClass("bg-warning");
                }
                else {
                    $('#txtOtherType2').addClass("bg-warning");
                }
            }
            else if (isFound == false) {
                $('#txtOtherType1').addClass("bg-warning");
                $('#txtOtherType2').addClass("bg-warning");
                $('#txtOtherType1').removeClass("bg-warning");
                $('#txtOtherType2').removeClass("bg-warning");
                res = false;
            }
        }
        if (res == false) {
            apiCommon.CloseWait();
            apiCommon.Notify("Validation Error", "Please validate Overseas Authorization Type or Overseas Authorization Number.", "Error");
        }
        return res;
    };

    this.InitiateManageLOVType = function (data) {
        var id = data;

        $.ajax({
            url: '/LOV/ManageLOVTypeEdit',
            dataType: "json",
            data: "iLTYPEID=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtiLTYPEID").val(result.iLTYPEID);
                $("#txtvcTypeName").val(result.vcTypeName);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtisTotal').val(result.iTotal);
                $('#txtisActive').val(result.iLISActive);

                if (result.iTotal === 1) {
                    $("div.id_100 select").val("1");
                }
                else {
                    $("div.id_100 select").val("0");
                }

                if (result.iLISActive === 1) {
                    $("div.id_101 select").val("1");
                }
                else {
                    $("div.id_101 select").val("0");
                }
                $('#pnlLOVTypeEdit').modal('show');
            }
        });
    };

    this.InitiateManageLeadingIndicators = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ManageLeadingIndicatorsEdit',
            dataType: "json",
            data: "LovId=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtLovId").val(result.LovId);
                $("#txtLovTypeId").val(result.LovTypeId);
                $("#txtvcLovName").val(result.vcLovName);
                $("#txtvcIUMeasures").val(result.vcIUMeasure);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtLOVStatus').val(result.iISActive);

                if (result.LOVStatus === 1) {
                    $("div.id_100 select").val("0");
                }
                else {
                    $("div.id_100 select").val("1");
                }

                $('#pnlLeadingIndDetailsEdit').modal('show');
            }
        });
    };

    this.InitiateManageResults = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ManageResultsEdit',
            dataType: "json",
            data: "LovId=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtLovId").val(result.LovId);
                $("#txtLovTypeId").val(result.LovTypeId);
                $("#txtvcLovName").val(result.vcLovName);
                $("#txtvcIUMeasures").val(result.vcIUMeasure);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtLOVStatus').val(result.iISActive);

                if (result.LOVStatus === 1) {
                    $("div.id_100 select").val("0");
                }
                else {
                    $("div.id_100 select").val("1");
                }

                $('#pnlResultDetailsEdit').modal('show');
            }
        });
    };

    this.InitiateManageDemand = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ManageDemandEdit',
            dataType: "json",
            data: "LovId=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtLovId").val(result.LovId);
                $("#txtLovTypeId").val(result.LovTypeId);
                $("#txtvcLovName").val(result.vcLovName);
                $("#txtvcIUMeasures").val(result.vcIUMeasure);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtLOVStatus').val(result.iISActive);

                if (result.LOVStatus === 1) {
                    $("div.id_100 select").val("0");
                }
                else {
                    $("div.id_100 select").val("1");
                }

                $('#pnlDemandDetailsEdit').modal('show');
            }
        });
    };

    this.InitiateManageOutput = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ManageOutputEdit',
            dataType: "json",
            data: "LovId=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtLovId").val(result.LovId);
                $("#txtLovTypeId").val(result.LovTypeId);
                $("#txtvcLovName").val(result.vcLovName);
                $("#txtvcIUMeasures").val(result.vcIUMeasure);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtLOVStatus').val(result.iISActive);

                if (result.LOVStatus === 1) {
                    $("div.id_100 select").val("0");
                }
                else {
                    $("div.id_100 select").val("1");
                }

                $('#pnlOutputDetailsEdit').modal('show');
            }
        });
    };
    
    this.InitiateManageOverdue = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ManageOverdueEdit',
            dataType: "json",
            data: "LovId=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtLovId").val(result.LovId);
                $("#txtLovTypeId").val(result.LovTypeId);
                $("#txtvcLovName").val(result.vcLovName);
                $("#txtvcIUMeasures").val(result.vcIUMeasure);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtLOVStatus').val(result.iISActive);

                if (result.LOVStatus === 1) {
                    $("div.id_100 select").val("0");
                }
                else {
                    $("div.id_100 select").val("1");
                }

                $('#pnlOverdueDetailsEdit').modal('show');
            }
        });
    };

    this.InitiateManageInventoryBreakdown = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ManageInventoryBreakdownEdit',
            dataType: "json",
            data: "LovId=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtLovId").val(result.LovId);
                $("#txtLovTypeId").val(result.LovTypeId);
                $("#txtvcLovName").val(result.vcLovName);
                $("#txtvcIUMeasures").val(result.vcIUMeasure);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtLOVStatus').val(result.iISActive);

                if (result.LOVStatus === 1) {
                    $("div.id_100 select").val("0");
                }
                else {
                    $("div.id_100 select").val("1");
                }

                $('#pnlInventoryBreakdownDetailsEdit').modal('show');
            }
        });
    };

    this.InitiateManageHeadCount = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ManageHeadCountEdit',
            dataType: "json",
            data: "LovId=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtLovId").val(result.LovId);
                $("#txtLovTypeId").val(result.LovTypeId);
                $("#txtvcLovName").val(result.vcLovName);
                $("#txtvcIUMeasures").val(result.vcIUMeasure);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtLOVStatus').val(result.iISActive);

                if (result.LOVStatus === 1) {
                    $("div.id_100 select").val("0");
                }
                else {
                    $("div.id_100 select").val("1");
                }

                $('#pnlHeadCountDetailsEdit').modal('show');
            }
        });
    };

    this.InitiateManageHours = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ManageHoursEdit',
            dataType: "json",
            data: "LovId=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtLovId").val(result.LovId);
                $("#txtLovTypeId").val(result.LovTypeId);
                $("#txtvcLovName").val(result.vcLovName);
                $("#txtvcIUMeasures").val(result.vcIUMeasure);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtLOVStatus').val(result.iISActive);

                if (result.LOVStatus === 1) {
                    $("div.id_100 select").val("0");
                }
                else {
                    $("div.id_100 select").val("1");
                }

                $('#pnlHoursDetailsEdit').modal('show');
            }
        });
    };

    this.InitiateManageProductivity = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ManageProductivityEdit',
            dataType: "json",
            data: "LovId=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtLovId").val(result.LovId);
                $("#txtLovTypeId").val(result.LovTypeId);
                $("#txtvcLovName").val(result.vcLovName);
                $("#txtvcIUMeasures").val(result.vcIUMeasure);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtLOVStatus').val(result.iISActive);

                if (result.LOVStatus === 1) {
                    $("div.id_100 select").val("0");
                }
                else {
                    $("div.id_100 select").val("1");
                }

                $('#pnlProductivityDetailsEdit').modal('show');
            }
        });
    };

    this.InitiateManageEBIT = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ManageEBITEdit',
            dataType: "json",
            data: "LovId=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtLovId").val(result.LovId);
                $("#txtLovTypeId").val(result.LovTypeId);
                $("#txtvcLovName").val(result.vcLovName);
                $("#txtvcIUMeasures").val(result.vcIUMeasure);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtLOVStatus').val(result.iISActive);

                if (result.LOVStatus === 1) {
                    $("div.id_100 select").val("0");
                }
                else {
                    $("div.id_100 select").val("1");
                }

                $('#pnlEBITDetailsEdit').modal('show');
            }
        });
    };

    this.InitiateManageCapex = function (data) {

        var id = data;

        $.ajax({
            url: '/LOV/ManageCapexEdit',
            dataType: "json",
            data: "LovId=" + id,
            type: "GET",
            success: function (result) {

                var Createddate = ToJavaScriptDate(result.dCreatedDate);

                $("#txtLovId").val(result.LovId);
                $("#txtLovTypeId").val(result.LovTypeId);
                $("#txtvcLovName").val(result.vcLovName);
                $("#txtvcIUMeasures").val(result.vcIUMeasure);
                $("#txtvcCreatedBy").val(result.vcCreatedBy);
                $('#txtdCreatedDate').val(Createddate);
                $('#txtLOVStatus').val(result.iISActive);

                if (result.LOVStatus === 1) {
                    $("div.id_100 select").val("0");
                }
                else {
                    $("div.id_100 select").val("1");
                }

                $('#pnlCapexDetailsEdit').modal('show');
            }
        });
    };

    this.WeekTypeChange = function (elem) {

        alert(elem);
        //$('#pnlAddEditTask_Discipline').val("");
        //$('#pnlAddEditTask_WorkCenter').val("");

        //var endUse = $("#txtEndUse").val();
        //var endUseText = $("#txtEndUse option:selected").text();
        //var customVal = $('#EditStatus').val();
        //var selectedId = $("#SourceCompanyList").val();
        //var selectedText = $("#SourceCompanyList option:selected").text();

        //var selectedType = "";
        //if (typeof elem.selectedIndex == "undefined" || elem.selectedIndex.length <= 0) {
        //    selectedType = $('#txtProjectType option[selected="selected"]').text();
        //}
        //else {
        //    selectedType = elem.options[elem.selectedIndex].text;
        //}

        //var strOption = '<option value="{0}">{1}</option>';

        //if (selectedTypeText === 'EVMS') {
        //    $('#pnlAddEditTask_TaskDesc').css('visibility', 'hidden');
        //    $('#pnlAddEditTask_TaskDescText').css('visibility', 'visible');
        //}
        //else {
        //    $('#pnlAddEditTask_TaskDesc').css('visibility', 'visible');
        //    $('#pnlAddEditTask_TaskDescText').css('visibility', 'hidden');
        //}
    };
}