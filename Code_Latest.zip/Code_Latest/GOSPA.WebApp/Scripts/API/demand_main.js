var columnDefs = [
    {
        headerName: 'Monthly',
        children: [
            { headerName: 'Demand', field: 'Demand', width: 220, filter: 'agTextColumnFilter', pinned: 'left' },
        ]
    },
    {
        headerName: 'Week1',
        children: [
    { headerName: 'Nov Actuals', field: 'Actuals', width: 150 },
    { headerName: 'Dec Plan', columnGroupShow: 'open', field: 'Dec Plan', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec LE FHM', columnGroupShow: 'open', field: 'Dec LE FHM', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec Prior PA', columnGroupShow: 'open', field: 'Dec Prior PA', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec MTD', columnGroupShow: 'open', field: 'Dec MTD', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec Est', columnGroupShow: 'open', field: 'Dec Est', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec VP', columnGroupShow: 'open', field: 'Dec VP', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec Var LE FHM', columnGroupShow: 'open', field: 'Dec Var LE FHM', width: 150, filter: 'agNumberColumnFilter' },
    { headerName: 'Dec Var Prior PA', columnGroupShow: 'open', field: 'Dec Var Prior PA', width: 150, filter: 'agNumberColumnFilter' },
        ]
    },
    {
        headerName: 'Week2',
        children: [
            { headerName: '', field: '', width: 150 },
            { headerName: 'Jan Plan', columnGroupShow: 'open', field: 'Jan Plan', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan LE FHM', columnGroupShow: 'open', field: 'Jan LE FHM', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan Prior PA', columnGroupShow: 'open', field: 'Jan Prior PA', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan MTD', columnGroupShow: 'open', field: 'Jan MTD', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan Est', columnGroupShow: 'open', field: 'Jan Est', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan VP', columnGroupShow: 'open', field: 'Jan VP', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan Var LE FHM', columnGroupShow: 'open', field: 'Jan Var LE FHM', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Jan Var Prior PA', columnGroupShow: 'open', field: 'Jan Var Prior PA', width: 150, filter: 'agNumberColumnFilter' },
        ]
    },
    {
        headerName: 'Quarter',
        children: [
            { headerName: '', field: '', width: 150 },
            { headerName: 'Q3 Plan', columnGroupShow: 'open', field: 'Q3 Plan', editable: 'true', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Q3 Est', columnGroupShow: 'open', field: 'Q3 Est', width: 150, filter: 'agNumberColumnFilter' },
            { headerName: 'Q3 variance', columnGroupShow: 'open', field: 'Q3 variance', width: 150, filter: 'agNumberColumnFilter' },
        ]
    },
{
    headerName: 'Comments',
    children: [
        { headerName: 'Comments', columnGroupShow: 'open', field: 'Comments', editable: 'true', width: 250, filter: 'agNumberColumnFilter' },
    ]
}
];

var gridOptions = {
    defaultColDef: {
        sortable: true,
        resizable: true,
        filter: true,
        editable: true,
        onCellValueChanged: function (params) {
            alert("Cell value changed");
            alert(params.newValue);
            if (params.oldValue != params.newValue) {
                params.colDef.cellStyle = function (params) {
                    return { backgroundColor: 'lightgreen' };
                }
            }
        }
    },
    debug: true,
    columnDefs: columnDefs,
    suppressLoadingOverlay: true,
    rowData: null
};

// setup the grid after the page has finished loading
//document.addEventListener('DOMContentLoaded', function () {
    //alert("afsfsfsdf");
    //$('#dvLItbl').empty();
    //$('#dvdemandtbl').empty();

    let demandDiv = document.querySelector('#dvdemandtbl');
    new agGrid.Grid(demandDiv, gridOptions);

    $.getJSON("/Scripts/API/Demand_JSON.json", function (json) {
        gridOptions.api.setRowData(json);
    });
//});