﻿Common = function () {
    var loading;
    var currUserName = "";
    var role = "";

    //this.ShowWait = function (isBlocking, txt) {
    //    loading = document.getElementsByClassName("loading")[0];
    //    loading.style.display = "block";
    //    if (isBlocking) {
    //        loading.style.height = "100%";
    //        loading.style.backgroundColor = "white";
    //        loading.style.opacity = "0.5";
    //    }
    //    else {
    //        loading.style.height = "25px";
    //        loading.style.backgroundColor = "#17a2b8";
    //        loading.style.opacity = "10";
    //    }

    //    if (typeof txt != "undefined" && txt.length > 0) {
    //        loading.getElementsByTagName("span")[0].innerHTML = txt;
    //    }
    //};

    //this.CloseWait = function () {
    //    loading.style.display = "none";
    //    loading.getElementsByTagName("span")[0].innerHTML = "";
    //};

    this.SearchUser = function (fn, ln, target, targetFunctionName) {
        var self = this;

        $.ajax({
            type: "POST",
            url: "/Home/SearchUser",
            data: '{firstName:' + JSON.stringify(fn) + ',lastName:' + JSON.stringify(ln) + '}',
            contentType: "application/json; charset=utf-8",
            beforeSend: function () {
                //self.ShowWait(true, "Searching...");
            },
            success: function (response) {

                $(target).find("tr:gt(0)").remove();

                jQuery.each(response, function (i, item) {
                    if (typeof targetFunctionName !== "undefined" && targetFunctionName.length > 0) {
                        $(target).append(
                         '<tr><td><span>' + item.WindowsId + '</span><input type="hidden" value="' + item.Domain + '"/></td><td>'
                         + item.Name + '</td><td>' + item.Title + '</td><td>' + item.Email
                         + '</td><td><button type="button" class="btn btn-link" onclick="apiMain.' + targetFunctionName + '(this);">Register</button></td></tr>'
                         );
                    }
                    else {
                        $(target).append(
                         '<tr><td><span>' + item.WindowsId + '</span><input type="hidden" value="' + item.Domain + '"/></td><td>'
                         + item.Name + '</td><td>' + item.Title + '</td><td>' + item.Email
                         + '</td><td><button class="btn btn-link" onclick="apiCommon.ValidateUserSelect(this);">Register</button></td></tr>'
                         );
                    }
                });
            },
            error: function (response) {
                alert(response);
            },
            complete: function (jqXHR, textStatus) {
                //self.CloseWait();
            }
        });
    };

    this.ValidateUserSelect = function (elem) {
        var selectedRole = $("#EnumDropDown option:selected").val();
        //alert(selectedRole);
        $.ajax({
            async: false,
            type: "POST",
            url: "/Home/GetWindowsUserId",
            contentType: "application/json; charset=utf-8",
            success: function (response) {
                currUserName = response;
                //Make a DB Call
                //pass username,role to the API..
                var usrModel = {
                    name: currUserName,
                    roleId: selectedRole
                };
                $.ajax({
                    type: "POST",
                    url: "/Home/Register",
                    data: '{model:' + JSON.stringify(usrModel) + '}',
                    //data: { 'name': currUserName, 'roleId': selectedRole },
                    contentType: "application/json; charset=utf-8",
                    success: function (response) {
                        //window.open('/Home/Login', "_self");
                        apiCommon.Notify("Registration Successful", "User registered Successfully", "");
                    },
                    error: function (response) {
                        alert(response);
                    },
                    complete: function (jqXHR, textStatus) {
                    }
                });
            },
            error: function (response) {
                return;
            },
            complete: function (jqXHR, textStatus) {
            }
        });

        ////get row
        //var tr = $(elem).parent().parent();
        //var winId = tr[0].cells[0].children[0].innerText;

        //var winIdArr = winId.split('\\');
        //var currUserArr = currUserName.split('\\');
        //if (winIdArr[0].toUpperCase() == currUserArr[0].replace('\"', '').toUpperCase() && winIdArr[1].toUpperCase() == currUserArr[1].replace('\"', '').toUpperCase()) {
        //    var usrModel = {
        //        Name: tr[0].cells[1].innerText,
        //        Email: tr[0].cells[3].innerText,
        //        WindowsId: winId,
        //        Title: tr[0].cells[2].innerText,
        //        Role: 1

        //    };

        //    $.ajax({
        //        type: "POST",
        //        url: "/Home/Login",
        //        data: '{model:' + JSON.stringify(usrModel) + '}',
        //        contentType: "application/json; charset=utf-8",
        //        success: function (response) {
        //            window.open('/Home/Login', "_self");
        //        },
        //        error: function (response) {
        //            alert(response);
        //        },
        //        complete: function (jqXHR, textStatus) {
        //        }
        //    });
        //}
        //else {
        //    alert('Incorrect or Invalid User Selected.');
        //}


    }

    this.SearchUserApi = function (returnfield) {

    };

    this.Notify = function (header, message, type) {
        var messageHtml = '<div  class="alert {2}"><p>{1} </p></div>';
        messageHtml = messageHtml.replace('{1}', message);
        if (type) {
            if (type === "Error") {
                messageHtml = messageHtml.replace('{2}', 'alert-danger');
            }
            else if (type === "Warning") {
                messageHtml = messageHtml.replace('{2}', 'alert-warning');
            }
            else {
                messageHtml = messageHtml.replace('{2}', 'alert-info');
            }
        }
        else {
            messageHtml = messageHtml.replace('{2}', 'alert-info');
        }
        $('#pnlNotification .modal-title')[0].innerHTML = header;
        $('#pnlNotification .modal-body')[0].innerHTML = messageHtml;
        $('#pnlNotification').modal('show');
    };

    //this.SubmitNotify = function (header, message, type) {
    //    var messageHtml = '<div  class="alert {2}"><p>{1} </p></div>';
    //    messageHtml = messageHtml.replace('{1}', message);
    //    if (type) {
    //        if (type === "Error") {
    //            messageHtml = messageHtml.replace('{2}', 'alert-danger');
    //        }
    //        else if (type === "Warning") {
    //            messageHtml = messageHtml.replace('{2}', 'alert-warning');
    //        }
    //        else {
    //            messageHtml = messageHtml.replace('{2}', 'alert-info');
    //        }
    //    }
    //    else {
    //        messageHtml = messageHtml.replace('{2}', 'alert-info');
    //    }
    //    $('#pnlSubmitNotification .modal-title')[0].innerHTML = header;
    //    $('#pnlSubmitNotification .modal-body')[0].innerHTML = messageHtml;
    //    $('#pnlSubmitNotification').modal('show');
    //};

    this.NotifyCustom = function (header, listMessage, type) {
        var messageHtml = '<div  class="alert {2}">{1}</div>';

        var displayMessage = '<ul>';


        for (var i in listMessage) {
            if (i > 0) {
                displayMessage += '<li>' + listMessage[i].messageType + ':- ' + listMessage[i].message + '</li>';
            }
        }

        displayMessage += '</ul>';
        messageHtml = messageHtml.replace('{1}', displayMessage);

        if (type) {
            if (type === "Error") {
                messageHtml = messageHtml.replace('{2}', 'alert-danger');
            }
            else if (type === "Warning") {
                messageHtml = messageHtml.replace('{2}', 'alert-warning');
            }
            else {
                messageHtml = messageHtml.replace('{2}', 'alert-info');
            }
        }
        else {
            messageHtml = messageHtml.replace('{2}', 'alert-info');
        }
        $('#pnlNotification .modal-title')[0].innerHTML = header;
        $('#pnlNotification .modal-body')[0].innerHTML = messageHtml;
        $('#pnlNotification').modal('show');
    };

    this.ShowDropDown = function (elem) {
        var dropdowns = document.getElementsByClassName("wbs-dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('wbs-dropdown-show')) {
                openDropdown.classList.remove('wbs-dropdown-show');
            }
        }
        $(elem).next("div").toggleClass("wbs-dropdown-show");
    }

    this.OpenVerticalTab = function (evt, tabname, partialPath) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("wbs-vertical-tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("wbs-vertical-tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(tabname).style.display = "block";
        // evt.currentTarget.className += " active";
        if (typeof partialPath !== "undefined" && partialPath.length > 0) {
            $.ajax({
                cache: false,
                type: "GET",
                url: partialPath,
                contentType: "application/json; charset=utf-8",
                beforeSend: function () {
                    apiCommon.ShowWait();
                },
                success: function (response) {
                    $('#' + tabname).html(response);
                },
                error: function (response) {
                    alert(response);

                },
                complete: function (jqXHR, textStatus) {
                    apiCommon.CloseWait();
                }
            });
        }
    };

    this.ValidateForm = function () {

        var cntArr = document.getElementsByClassName("wbs-validate");
        var isValid = true;
        jQuery.each(cntArr, function (i, item) {

            if (item.type == "select-one") {
                var selIndex = item.value;
                if (typeof selIndex == "undefined" || selIndex.length <= 0) {
                    item.classList.add("border");
                    item.classList.add("border-danger");
                    isValid = false;
                }
            }
                //else if (item.type == "button") {
                //    var selIndex = item.value;
                //    if (typeof selIndex == "undefined" || selIndex.length <= 0) {
                //        item.classList.add("border");
                //        item.classList.add("border-danger");
                //        isValid = false;
                //    }
                //}
            else if (item.type == "text" || item.type == "textarea") {
                var txtField = item.value;
                var validationType = item.getAttribute("wbsvalidate");
                if (validationType == "required" && txtField.length <= 2) {
                    item.classList.add("border");
                    item.classList.add("border-danger");
                    isValid = false;
                }
            }
        });
        if (isValid == false) {
            apiCommon.Notify("Validation Error", "Some inputs are missing or invalid.", "Error");
        }
        return isValid;
    };

    this.ValidateFormWithoutPopUp = function () {

        var cntArr = document.getElementsByClassName("wbs-validate");
        var isValid = true;
        jQuery.each(cntArr, function (i, item) {

            if (item.type == "select-one") {
                var selIndex = item.value;
                if (typeof selIndex == "undefined" || selIndex.length <= 0) {
                    item.classList.add("border");
                    item.classList.add("border-danger");
                    isValid = false;
                }
            }
                //else if (item.type == "button") {
                //    var selIndex = item.value;
                //    if (typeof selIndex == "undefined" || selIndex.length <= 0) {
                //        item.classList.add("border");
                //        item.classList.add("border-danger");
                //        isValid = false;
                //    }
                //}
            else if (item.type == "text" || item.type == "textarea") {
                var txtField = item.value;
                var validationType = item.getAttribute("wbsvalidate");
                if (validationType == "required" && txtField.length <= 2) {
                    item.classList.add("border");
                    item.classList.add("border-danger");
                    isValid = false;
                }
            }
        });

        return isValid;
    };

    this.ClearValidation = function (elem) {
        if (elem.classList.length > 0) {
            if (elem.classList.contains("border")) {
                elem.classList.remove("border");
            }

            if (elem.classList.contains("border-danger")) {
                elem.classList.remove("border-danger");
            }
        }
    };

    this.HandleError = function (xhr) {
        apiCommon.Notify("Error", xhr.statusText, "Error");
    };

    this.ShowHelpFile = function (elem) {
        $.ajax({
            type: "GET",
            url: "/Home/HelpPage",
            error: function (response) {
                alert(response);
            },
            success: function (response) {
                var url = 'Help/CreateNewProject.html';
                var myWindow = window.open(url, "width=800,height=600");
                console.log(response);
            }
        });
    }

    this.WeekTypeChange = function (elem) {

        var currentmonth = "";
        var previousmonth = "";
        var todaydate = new Date();

        var currentMonth = todaydate.toLocaleString('en-us', { month: 'short' }); /* Jun */
        var lastMonth = todaydate.toLocaleString('en-us', { month: 'short' }); /* Jun */

        var selectedWeek = "";
        selectedWeek = elem.options[elem.selectedIndex].text;

        //Compare the selectedWeek month contains present month or previous month
        if (selectedWeek.includes("Actuals")) {
            ///alert("Inside");
            ///Estimates could be disabled
            //$('#pnlActEstData .Select').prop("disabled", "disabled");
            //$("#pnlActEstData option:contains('Select')").attr('selected', 'selected');
            
            $('#pnlActEstData .Actuals').prop("disabled", false);
            $('#pnlActEstData .Estimates').prop("disabled", "disabled");

        }
        else {
            ///Actuals could be disabled
            $('#pnlActEstData .Actuals').prop("disabled", "disabled");
            $('#pnlActEstData .Estimates').prop("disabled", false);
        }
    };

    this.ValueStreamChange = function (elem) {

        //var selectedvs = "";
        //selectedvs = elem.options[elem.selectedIndex].text;
        var selectedVsid = $(elem).val();
        
        $.ajax({
            url: '/Home/GetWeekList',
            dataType: "json",
            data: { 'selectedVsid': selectedVsid },
            type: "POST",
            success: function (result) {
                //projectExists = result;
                //if (result === 'Project Exists') {
                //    apiCommon.Notify("Validation Error", "Project has already been created with the same name", "Error");
                //}
            }
        });
    };
};