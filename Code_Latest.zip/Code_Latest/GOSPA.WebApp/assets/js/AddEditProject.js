﻿function initiateAddEditTask() {
    $('#pnlAddEditTask').modal({ backdrop: 'static' });
}

function changeDiscipline(elem) {
    var value = $("#pnlAddEditTask_Discipline option:selected").val();
    $('#pnlAddEditTask_WorkCenter').val(value);
}

function addTask() {
    $('#tblProjectTasks').append('<tr>'
        + '<td>' + $('#pnlAddEditTask_TaskDesc option:selected').val() + '</td>'
        + '<td>'+ $("#pnlAddEditTask_Discipline option:selected").text()+'</td>'
        + '<td>' + $('#pnlAddEditTask_WorkCenter').val() + '</td></tr>');

    $('#pnlAddEditTask').modal('hide');
}