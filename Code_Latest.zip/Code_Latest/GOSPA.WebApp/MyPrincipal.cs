﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Principal;
using System.DirectoryServices.AccountManagement;

namespace GOSPA.WebApp
{
    public class MyPrincipal : IPrincipal
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MyPrincipal"/> class.
        /// </summary>
        /// <param name="identity">The identity.</param>
        public MyPrincipal(MyIdentity identity)
        {
            Identity = identity;

        }
        /// <summary>
        /// Gets the identity.
        /// </summary>
        /// <value>
        /// The identity.
        /// </value>
        public MyIdentity Identity { get; private set; }

        /// <summary>
        /// Gets the identity.
        /// </summary>
        /// <value>
        /// The identity.
        /// </value>
        IIdentity IPrincipal.Identity { get { return this.Identity; } }

        /// <summary>
        /// Determines whether [is in role] [the specified role].
        /// </summary>
        /// <param name="role">The role.</param>
        /// <returns>
        ///   <c>true</c> if [is in role] [the specified role]; otherwise, <c>false</c>.
        /// </returns>
        /// <exception cref="NotImplementedException"></exception>
        public bool IsInRole(string role)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Performs an implicit conversion from <see cref="MyPrincipal"/> to <see cref="Principal"/>.
        /// </summary>
        /// <param name="v">The v.</param>
        /// <returns>
        /// The result of the conversion.
        /// </returns>
        /// <exception cref="NotImplementedException"></exception>
        public static implicit operator Principal(MyPrincipal v)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    ///
    /// </summary>
    public class MyIdentity : IIdentity
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MyIdentity"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="authenticationType">Type of the authentication.</param>
        /// <param name="isAuthenticated">if set to <c>true</c> [is authenticated].</param>
        /// <param name="userId">The user identifier.</param>
        public MyIdentity(string name, string authenticationType, bool isAuthenticated, Guid userId)
        {
            Name = name;
            AuthenticationType = authenticationType;
            IsAuthenticated = isAuthenticated;
            UserId = userId;
        }

        #region IIdentity
        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; private set; }
        /// <summary>
        /// Gets the type of the authentication.
        /// </summary>
        /// <value>
        /// The type of the authentication.
        /// </value>
        public string AuthenticationType { get; private set; }
        /// <summary>
        /// Gets a value indicating whether this instance is authenticated.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is authenticated; otherwise, <c>false</c>.
        /// </value>
        public bool IsAuthenticated { get; private set; }
        #endregion

        /// <summary>
        /// Gets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public Guid UserId { get; private set; }
    }
}