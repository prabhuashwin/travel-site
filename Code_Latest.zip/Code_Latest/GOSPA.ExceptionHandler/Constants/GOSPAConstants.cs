﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    GOSPAConstants.cs
* File Desc   :    This file contains code pertaining to class for Constants.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 28-Oct-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOSPA.ExceptionHandler.Constants
{
    public class GOSPAConstants
    {
        public const string GenericGaurdMsg = "{0}: Please provide proper value.";
    }
}
