﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    LogUtilities.cs
* File Desc   :    This file contains code pertaining to static class for Log Utilities.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System.Diagnostics;

namespace SAP.Framework.Logging
{
    /// <summary>
    /// 
    /// </summary>
    public static class LogUtilities
    {
        /// <summary>
        /// Logs the message.
        /// </summary>
        /// <param name="eventMessage">The message.</param>
        /// <param name="priority">The priority.</param>
        /// <param name="className">Name of the class.</param>
        /// <param name="methodName">Name of the method.</param>
        public static void LogEvent(string eventMessage, LogPriorityId priority = LogPriorityId.High,
            string className = "NotAvailable", string methodName = "NotAvailable")
        {
            Log(
                eventMessage,
                LoggingCategory.Event,
                priority,
                TraceEventType.Information,
                className,
                methodName,
                0);
        }

        /// <summary>
        /// Logs the exception.
        /// </summary>
        /// <param name="exception">The exception.</param>
        /// <param name="priority">The priority.</param>
        /// <param name="className">Name of the class.</param>
        /// <param name="methodName">Name of the method.</param>
        public static void LogException(System.Exception exception, LogPriorityId priority = LogPriorityId.High,
            string className = "NotAvailable", string methodName = "NotAvailable")
        {
            Log(
                exception.ToString(),
                LoggingCategory.Error,
                priority,
                TraceEventType.Error,
                className,
                methodName,
                0);
        }

        /// <summary>
        /// Logs the performance parameter.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="className">Name of the class.</param>
        /// <param name="methodName">Name of the method.</param>
        public static void LogPerformanceParam(string message, string className = "NotAvailable",
            string methodName = "NotAvailable")
        {
            Log(
                message,
                LoggingCategory.PerformanceParam,
                LogPriorityId.Medium,
                TraceEventType.Information,
                className,
                methodName,
                0);
        }

        /// <summary>
        /// Logs the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="loggingCategory">The logging category.</param>
        /// <param name="priority">The priority.</param>
        /// <param name="traceEventType">Type of the trace event.</param>
        /// <param name="className">Name of the class.</param>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="networkId">The fire network identifier.</param>
        private static void Log(string message, LoggingCategory loggingCategory, LogPriorityId priority,
            TraceEventType traceEventType, string className, string methodName, int networkId)
        {
            Logging.DoLog(new LogEntry
            {
                MessageDetails = message,
                LogCategory = loggingCategory,
                LogPriority = priority,
                LogEventType = traceEventType,
                ClassName = "Class Name = " + className,
                MethodName = "Method Name = " + methodName,
                NetworkId = networkId
            });
        }
    }
}