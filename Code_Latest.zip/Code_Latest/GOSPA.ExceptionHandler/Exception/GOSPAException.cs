﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    GOSPAException.cs
* File Desc   :    This file contains code pertaining to class for GOSPAException.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 28-Oct-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using GOSPA.Common.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOSPA.ExceptionHandler.Exception
{
    public class GOSPAException : System.Exception
    {
        
        public GOSPAException()
        {
            Result = new OperationResult();
        }
                
        public GOSPAException(MessageCode code, string message)
            : base(message)
        {
            Result = new OperationResult { Success = false, MCode = code, Message = message };
        }
        
        public OperationResult Result { get; set; }
    }
}
