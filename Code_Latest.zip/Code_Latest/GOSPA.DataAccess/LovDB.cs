﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GOSPA.DataAccess.Interfaces;
using GOSPA.DataModels;
using SAP.Framework.Logging;
using System.Reflection;
using System.Data.SqlClient;
using System.Data.Entity;
using GOSPA.Common.DTO;
using GOSPA.ExceptionHandler.Exception;

namespace GOSPA.DataAccess
{
    public class LovDB : ILovDB
    {
        private GOSPA_TestEntities dbContext;

        public LovDB(GOSPA_TestEntities dbContext)
        {
            this.dbContext = dbContext;
        }

        public List<GetValueStreamList> GetValueStreamDet()
        {
            try
            {
                var vsDet = (this.dbContext as GOSPA_TestEntities).GetValueStreamList().ToList();

                List<GetValueStreamList> vsrdet = new List<GetValueStreamList>();

                foreach (var item in vsDet)
                {
                    GetValueStreamList res = new GetValueStreamList();

                    res.vSId = item.iVSID;
                    res.vcValueStream = item.vcValueStream;

                    vsrdet.Add(res);
                }

                return vsrdet;
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<GetValueStreamList> GetFCValueStreamDet(int UserId)
        {
            try
            {
                var vsDet = (this.dbContext as GOSPA_TestEntities).GetFCValueStreamList(UserId).ToList();

                List<GetValueStreamList> vsrdet = new List<GetValueStreamList>();

                foreach (var item in vsDet)
                {
                    GetValueStreamList res = new GetValueStreamList();

                    res.vSId = item.iVSID;
                    res.vcValueStream = item.vcValueStream;

                    vsrdet.Add(res);
                }

                return vsrdet;
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<string> GetValueStreamDet1()
        {
            try
            {
                var vsDet = (this.dbContext as GOSPA_TestEntities).GetValueStreamList().ToList();

                List<string> vsrdet = new List<string>();

                foreach (var item in vsDet)
                {
                    List<string> res = new List<string>();

                    vsrdet.Add(item.vcValueStream);
                }

                return vsrdet;
                //return vsDet;
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<GetValueStreamDetails_consolidated> GetValueStreamDet2()
        {
            try
            {
                var vsDet = (this.dbContext as GOSPA_TestEntities).GetValueStreamList().ToList();

                List<GetValueStreamDetails_consolidated> vsrdet = new List<GetValueStreamDetails_consolidated>();

                foreach (var item in vsDet)
                {
                    GetValueStreamDetails_consolidated res = new GetValueStreamDetails_consolidated();
                    res.iVSID = item.iVSID;
                    res.vcValueStream = item.vcValueStream;
                    vsrdet.Add(res);
                }

                return vsrdet;
                //return vsDet;
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public bool InsertDemandDet(string vcTypeName, string vcLovName, int weekid, int LEFHM, int PriorPA, int MTD, int UserId)
        {
            try
            {
                //Inserting into Temp table
                tbl_Temp_WeekGosData tempWSGD = new tbl_Temp_WeekGosData();
                tempWSGD.vcTypeName = vcTypeName;
                tempWSGD.vcLovName = vcLovName;
                tempWSGD.iWeekID = weekid;
                tempWSGD.iLe_HFM = LEFHM;
                tempWSGD.iPriorPA = PriorPA;
                tempWSGD.iMTD = MTD;
                tempWSGD.vcCreatedby = UserId;
                tempWSGD.dcreateDate = DateTime.UtcNow;

                this.dbContext.Entry(tempWSGD).State = EntityState.Added;
                dbContext.SaveChanges();

                return this.dbContext.SaveChanges() > 0;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<GetLovDetList> GetManageLOVDet()
        {
            try
            {
                //Fetching Lov list details

                var lovDet = (this.dbContext as GOSPA_TestEntities).GetLOVDetList().ToList();

                List<GetLovDetList> lovvaldet = new List<GetLovDetList>();

                foreach (var item in lovDet)
                {
                    GetLovDetList res = new GetLovDetList();

                    //res.LovId = item.iLOVID;
                    res.iLTYPEID = item.iLTYPEID;
                    res.vcTypeName = item.vcTypeName;
                    //res.vcLovName = item.vcLOVName;
                    //res.vcIUMeasure = item.vcIUMeasure;
                    res.vcCreatedBy = item.vcName;
                    res.dCreatedDate = item.dCreatedDate ?? DateTime.Now;
                    res.iTotal = item.iIsTotal;
                    res.iLISActive = Convert.ToInt32(item.iLISActive);
                    lovvaldet.Add(res);
                }

                return lovvaldet;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<GetLovDetList> GetManageDynLOVDet()
        {
            try
            {
                //Fetching Lov list details

                var lovDet = (this.dbContext as GOSPA_TestEntities).GetDynamicLOVDetList().ToList();

                List<GetLovDetList> lovvaldet = new List<GetLovDetList>();

                foreach (var item in lovDet)
                {
                    GetLovDetList res = new GetLovDetList();

                    res.LovTypeId = item.iLTYPEID;
                    res.vcTypeName = item.vcTypeName;
                    lovvaldet.Add(res);
                }
                return lovvaldet;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public bool UpdateLeadingIndicators(int LovId, string LovName, string UMeasure,
                                            int? LovStatus, int UserId)
        {
            try
            {
                //Updating tbl_Lov data
                tbl_LOV lovInfoDB = new tbl_LOV();
                lovInfoDB.vcLOVName = LovName;
                lovInfoDB.vcIUMeasure = UMeasure;
                lovInfoDB.iISActive = LovStatus;

                var entity = dbContext.tbl_LOV.FirstOrDefault(i => i.iLOVID == LovId);
                if (entity == null)
                {
                    //handle error:
                    throw new Exception("Issue not found");
                }
                else
                {
                    entity.vcLOVName = LovName;
                    entity.vcIUMeasure = UMeasure;
                    entity.iISActive = LovStatus;
                }
                dbContext.Entry(entity).Property("vcLOVName").IsModified = true;
                dbContext.Entry(entity).Property("vcIUMeasure").IsModified = true;
                dbContext.Entry(entity).Property("iISActive").IsModified = true;

                //here we update the properties:
                dbContext.SaveChanges();

                return true;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public bool UpdateDemandDetails(int iWGDId, double iLE_HFM, double iMTD, double iEST,double iActuals, string Comments, int UserId)
        {
            try
            {
                //Updating tbl_WeekGosData data
                tbl_WeekGosData wsgData = new tbl_WeekGosData();
                wsgData.iLe_HFM = iLE_HFM;
                wsgData.iMTD = iMTD;
                wsgData.iEST = iEST;
                wsgData.iActuals = iActuals;
                wsgData.Comments = Comments;
                wsgData.vcUpdatedby = UserId;

                var entity = dbContext.tbl_WeekGosData.FirstOrDefault(i => i.iWGDID == iWGDId);
                if (entity == null)
                {
                    //handle error:
                    throw new Exception("Issue not found");
                }
                else
                {
                    entity.iLe_HFM = iLE_HFM;
                    entity.iMTD = iMTD;
                    entity.iEST = iEST;
                    entity.iActuals = iActuals;
                    entity.Comments = Comments;
                    entity.dUpdatedDate = DateTime.UtcNow;
                    entity.vcUpdatedby = UserId;
                }

                dbContext.Entry(entity).Property("iLe_HFM").IsModified = true;
                dbContext.Entry(entity).Property("iMTD").IsModified = true;
                dbContext.Entry(entity).Property("iEST").IsModified = true;
                dbContext.Entry(entity).Property("iActuals").IsModified = true;
                dbContext.Entry(entity).Property("Comments").IsModified = true;
                dbContext.Entry(entity).Property("dUpdatedDate").IsModified = true;
                dbContext.Entry(entity).Property("vcUpdatedby").IsModified = true;

                ///Insert 1 record in tbl_GOSheet

                ///Insert into tb_Request table based on id from tbl_GoSheet
                ///Insert into tbl_RequestHistory based on id from tbl_Request

                //here we update the properties:
                dbContext.SaveChanges();

                return true;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public bool InsertRequestTable(int TimelineId, int VsId, int? Weekid, string Username, int UserId, int rStatus)
        {
            try
            {
                //Inserting into tbl_GOSSheet
                tbl_GOSSheet sheetDB = new tbl_GOSSheet();
                sheetDB.iTimeLineID = TimelineId;
                sheetDB.iVSID = VsId;
                sheetDB.iWeekID = Weekid;
                sheetDB.vcCreatedBy = Username;
                sheetDB.dCreatedDate = DateTime.Now;

                this.dbContext.Entry(sheetDB).State = EntityState.Added;
                dbContext.SaveChanges();

                //Get the GOSheetId based on useremail
                var sheetDet = (this.dbContext as GOSPA_TestEntities).GetUserSheetDetails(Username, TimelineId, VsId, Weekid).ToList();

                //Inserting into tbl_Request data
                tbl_Request reqDB = new tbl_Request();
                reqDB.iSheetID = sheetDet[0].iSheetID;
                reqDB.iRequestedById = UserId;
                reqDB.dRequestedOn = DateTime.UtcNow;
                reqDB.iRStatus = rStatus;
                reqDB.iRejectionCount = 0;
                reqDB.vComments = string.Empty;

                this.dbContext.Entry(reqDB).State = EntityState.Added;
                dbContext.SaveChanges();

                //Get the GOSheetId based on useremail
                var reqDet = (this.dbContext as GOSPA_TestEntities).GetReqSheetDetails(sheetDet[0].iSheetID, UserId).ToList();

                //Inserting into tbl_RequestHistory
                tbl_RequestHistory reqHDB = new tbl_RequestHistory();
                reqHDB.iRequestId = Convert.ToInt32(reqDet[0].iRid);
                reqHDB.vRemarks = "OpsUser Saved";
                reqHDB.vCurrentStakeholder = Username;
                reqHDB.dCreatedOn = DateTime.Now;

                this.dbContext.Entry(reqHDB).State = EntityState.Added;
                return this.dbContext.SaveChanges() > 0;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public bool ValidateRequestSheet(int TimelineId, int VSId, int? Weekid)
        {
            try
            {
                //Get the GOSheetId based on TimeLine,VSid,WeekId

                var sheetDet = (this.dbContext as GOSPA_TestEntities).GetSheetDetails(TimelineId, VSId, Weekid).ToList();
                if (sheetDet.Count > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public bool InsertIntoReqHistoryTable(int TimelineId, int VsId, int? Weekid, string Username, int UserId, int RoleId)
        {
            try
            {
                ///Building Remarks based on user role
                string remarks = string.Empty;
                if (RoleId == 1)
                {
                    remarks = "OpsUser Saved";
                }
                else if (RoleId == 2)
                {
                    remarks = "FC User Saved";
                }
                else if (RoleId == 3)
                {
                    remarks = "LT User Saved";
                }
                //Get the GOSheetId based on useremail
                var reqDet = (this.dbContext as GOSPA_TestEntities).GetReqDetails(TimelineId, VsId, Weekid).ToList();

                //Inserting into tbl_RequestHistory
                tbl_RequestHistory reqHDB = new tbl_RequestHistory();
                reqHDB.iRequestId = Convert.ToInt32(reqDet[0].iRid);
                reqHDB.vRemarks = remarks;
                reqHDB.vCurrentStakeholder = Username;
                reqHDB.dCreatedOn = DateTime.Now;

                this.dbContext.Entry(reqHDB).State = EntityState.Added;
                return this.dbContext.SaveChanges() > 0;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<string> GetFCLTDetails(int RoleId)
        {
            try
            {
                var fcltDet = (this.dbContext as GOSPA_TestEntities).GetFCUserDetails(RoleId).ToList();

                return fcltDet;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int UpdateSubmitRequestTable(int TimelineId, int VsId, int? Weekid, string Username, int UserId, int rStatus, int Role)
        {
            try
            {
                //Update the Request,RequestSH,ReqHistory based on TimeLine,Weekid,Vsid
                var sheetDet = (this.dbContext as GOSPA_TestEntities).UpdateReqSheetDetails(TimelineId, Weekid, VsId, Username, Role).ToList();

                //(this.dbContext as GOSPA_TestEntities).UpdateReqSheetDetails(TimelineId, VsId, Weekid, Username, Role);

                return sheetDet[0].Value;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public bool UpdateLOVT(int? Weekid, int VsId, int TimelineId, string LovType)
        {
            try
            {
                //Update the Totals for Rows
                var sheetDet = (this.dbContext as GOSPA_TestEntities).UpdateLOVTotals(Weekid, VsId, TimelineId, LovType).ToString();

                return true;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<GetWeekList> GetWeekDataDet(DateTime cdate, int vsid)
        {
            try
            {
                var wkDet = (this.dbContext as GOSPA_TestEntities).GetWeekDataList(cdate, vsid).ToList();

                List<GetWeekList> wkdet = new List<GetWeekList>();

                foreach (var item in wkDet)
                {
                    GetWeekList res = new GetWeekList();

                    res.weekId = Convert.ToInt32(item.weekId);
                    res.vcWeekName = item.vcWeekName;

                    wkdet.Add(res);
                }

                return wkdet;
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<int> GetTimeLine()
        {
            List<int> yearDetails = new List<int>();
            try {

                yearDetails= (this.dbContext as GOSPA_TestEntities).tbl_Timeline.Select(p => p.iYear).Distinct().ToList();
                return yearDetails;
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

 public bool InsertLovTypeTable(string vcTypeName, int iTotal, string UserName)
        {
            try
            {
                //Inserting into LOV Type table
                tbl_LOVTYPE lovtype = new tbl_LOVTYPE();
                lovtype.vcTypeName = vcTypeName;
                lovtype.iIsTotal = iTotal;
                lovtype.vcCreatedBy = UserName;
                lovtype.dCreatedDate = DateTime.UtcNow;
                lovtype.iLISActive = 1;


                this.dbContext.Entry(lovtype).State = EntityState.Added;
                dbContext.SaveChanges();

                return this.dbContext.SaveChanges() > 0;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public List<GetValueStreamDetails_consolidated> GetValueStreamDetails(int roleid, int iUserID)
        {
            try
            {
                var vsDet = (this.dbContext as GOSPA_TestEntities).GetValusStreamDetails_consolidated(roleid, iUserID).ToList();

                List<GetValueStreamDetails_consolidated> vsrdet = new List<GetValueStreamDetails_consolidated>();

                foreach (var item in vsDet)
                {
                    GetValueStreamDetails_consolidated res = new GetValueStreamDetails_consolidated();

                    res.iVSID = item.iVSID;
                    res.vcValueStream = item.vcValueStream;

                    vsrdet.Add(res);
                }

                return vsrdet;
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
 public bool UpdateLOVTypeDet(int iLTYPEID, string vcTypeName, int iTotal, int iLISActive, int UserId)
        {
            try
            {
                //Updating tbl_LovType data
                tbl_LOVTYPE lovtypeInfoDB = new tbl_LOVTYPE();
                lovtypeInfoDB.vcTypeName = vcTypeName;
                lovtypeInfoDB.iIsTotal = iTotal;
                lovtypeInfoDB.iLISActive = iLISActive;

                var entity = dbContext.tbl_LOVTYPE.FirstOrDefault(i => i.iLTYPEID == iLTYPEID);
                if (entity == null)
                {
                    //handle error:
                    throw new Exception("Issue not found");
                }
                else
                {
                    entity.vcTypeName = vcTypeName;
                    entity.iIsTotal = iTotal;
                    entity.iLISActive = iLISActive;
                }
                dbContext.Entry(entity).Property("vcTypeName").IsModified = true;
                dbContext.Entry(entity).Property("iIsTotal").IsModified = true;
                dbContext.Entry(entity).Property("iLISActive").IsModified = true;

                //here we update the properties:
                dbContext.SaveChanges();

                return true;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #region

        public bool UpdateRejectStatusTable(int TimelineId, int VsId, int? Weekid, string Username, int Role)
        {
            try
            {
                //Update the Request,RequestSH,ReqHistory based on TimeLine,Weekid,Vsid
                var sheetDet = (this.dbContext as GOSPA_TestEntities).UpdateRejectStatus(TimelineId, VsId, Weekid, Username, Role).ToList();

                return true;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        #endregion


    }
}
