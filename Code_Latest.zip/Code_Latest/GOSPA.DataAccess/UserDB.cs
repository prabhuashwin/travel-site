﻿using GOSPA.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GOSPA.DataModels;
using SAP.Framework.Logging;
using System.Reflection;
using System.Data.SqlClient;
using System.Data.Entity;
using GOSPA.Common.DTO;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Core.Objects;
using System.Configuration;
using System.Collections;
using GOSPA.DataAccess;

namespace GOSPA.DataAccess
{
    public class UserDB : IUserDB
    {
        private GOSPA_TestEntities dbContext;

        //private static List<SelectListItem> repo;
        public UserDB(GOSPA_TestEntities dbContext)
        {
            this.dbContext = dbContext;
        }
        public tbl_User GetUser(string userName)
        {
            throw new NotImplementedException();
        }

        public bool RegisterUser(string Name, string EmailId, int RoleId, string Title, string WindowsId)
        {
            try
            {
                //Inserting into tbl_user data
                tbl_User userInfoDB = new tbl_User();
                userInfoDB.vcName = Name;
                userInfoDB.vcEmail = EmailId;
                userInfoDB.vcCreatedBy = Name;
                userInfoDB.vcTitle = Title;
                userInfoDB.vcWindowsId = WindowsId;
                userInfoDB.dStatus = false;
                userInfoDB.dCreatedDate = DateTime.UtcNow;
                userInfoDB.iARoleID = RoleId;

                this.dbContext.Entry(userInfoDB).State = EntityState.Added;
                dbContext.SaveChanges();

                //Fetch the inserted user details
                var userDet = (this.dbContext as GOSPA_TestEntities).GetUserDetails(EmailId).ToList();

                //Inserting into tbl_userrolemapping
                tbl_UserRoleMapping userRoleMapInfoDB = new tbl_UserRoleMapping();
                userRoleMapInfoDB.iUserID = userDet[0].iID;
                userRoleMapInfoDB.iRoleID = RoleId;
                userRoleMapInfoDB.vcCreatedBy = Name;
                userRoleMapInfoDB.dCreatedDate = DateTime.UtcNow;

                this.dbContext.Entry(userRoleMapInfoDB).State = EntityState.Added;

                return this.dbContext.SaveChanges() > 0;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<UserDetailsCommon> GetManageUserDet()
        {
            try
            {
                //Fetching user details

                List<tbl_User> userlist = new List<tbl_User>();
                userlist = dbContext.tbl_User.ToList();

                List<UserDetailsCommon> usrdet = new List<UserDetailsCommon>();

                foreach (var item in userlist)
                {
                    UserDetailsCommon res = new UserDetailsCommon();

                    res.iID = item.iID;
                    res.vcName = item.vcName;
                    res.vcEmail = item.vcEmail;
                    res.vcCreatedBy = item.vcCreatedBy;
                    res.dCreatedDate = item.dCreatedDate;
                    res.dStatus = item.dStatus;
                    res.iARoleId = Convert.ToInt32(item.iARoleID);
                    res.Title = item.vcTitle;
                    res.WindowsId = item.vcWindowsId;

                    //foreach (var roleitem in item.tbl_UserRoleMapping)
                    //{
                    //    res.RoleId = roleitem.iRoleID;
                    //}
                    usrdet.Add(res);

                }

                //usrdet = (dbContext as GOSPA_TestEntities).GetManageUserDetails().ToList();

                return usrdet;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<GetUserList> GetRolebased_UserList()
        {
            try
            {
                //Fetching user list details

                var userDet = (this.dbContext as GOSPA_TestEntities).GetRolebased_UserList().ToList();

                List<GetUserList> usrdet = new List<GetUserList>();

                foreach (var item in userDet)
                {
                    GetUserList res = new GetUserList();

                    // res.Id = item.iURID;//Commented
                    res.UserId = item.UserId;
                    res.UserName = item.UserName;
                    res.UserEmail = item.UserEmail;
                    res.Title = item.Title;
                    res.UserRole = item.UserRole;
                    res.CreatedBy = item.CreatedBy;
                    res.CreatedDate = item.CreatedDate ?? DateTime.Now;
                    usrdet.Add(res);
                }

                return usrdet;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public UserDetailsCommon GetManageUserDet(string WindowsId)
        {
            //Fetching user details
            var userlist = dbContext.tbl_User.SingleOrDefault(user => user.vcWindowsId == WindowsId);

            UserDetailsCommon res = new UserDetailsCommon();

            if (userlist != null)
            {
                res.iID = userlist.iID;
                res.vcName = userlist.vcName;
                res.vcEmail = userlist.vcEmail;
                res.vcCreatedBy = userlist.vcCreatedBy;
                res.dCreatedDate = userlist.dCreatedDate;
                res.dStatus = userlist.dStatus;
                res.Title = userlist.vcTitle;
                res.WindowsId = userlist.vcWindowsId;
                res.iARoleId = Convert.ToInt32(userlist.iARoleID);

                List<int> usrRoles = new List<int>();

                foreach (var roleitem in userlist.tbl_UserRoleMapping)
                {
                    usrRoles.Add(roleitem.iRoleID);
                }
                res.RoleId = new List<int>();

                res.RoleId.AddRange(usrRoles);
            }
            return res;
        }

        public List<UserDetailsCommon> GetManageInActiveUserDet()
        {
            try
            {
                List<tbl_User> inActuserlist = new List<tbl_User>();
                inActuserlist = dbContext.tbl_User.Where(x => x.dStatus == false).ToList();

                List<UserDetailsCommon> inActusrdet = new List<UserDetailsCommon>();

                foreach (var item in inActuserlist)
                {
                    UserDetailsCommon res = new UserDetailsCommon();

                    res.iID = item.iID;
                    res.vcName = item.vcName;
                    res.vcEmail = item.vcEmail;
                    res.vcCreatedBy = item.vcCreatedBy;
                    res.dCreatedDate = item.dCreatedDate;
                    res.dStatus = item.dStatus;

                    inActusrdet.Add(res);
                }

                return inActusrdet;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public bool UpdateUser(int UserId, string UpdatedBy)
        {
            try
            {
                //Updating tbl_user data
                tbl_User userInfoDB = new tbl_User();
                userInfoDB.dStatus = true;
                userInfoDB.dUpdatedDate = DateTime.UtcNow;
                userInfoDB.vcUpdatedBy = UpdatedBy;

                var entity = dbContext.tbl_User.FirstOrDefault(i => i.iID == UserId);
                if (entity == null)
                {
                    //handle error:
                    throw new Exception("Issue not found");
                }
                else
                {
                    entity.dStatus = true;
                    entity.vcUpdatedBy = UpdatedBy;
                    entity.dUpdatedDate = DateTime.UtcNow;
                }
                dbContext.Entry(entity).Property("dStatus").IsModified = true;
                dbContext.Entry(entity).Property("dUpdatedDate").IsModified = true;
                dbContext.Entry(entity).Property("vcUpdatedBy").IsModified = true;

                //here we update the properties:
                //dbContext.Entry(entity).CurrentValues.SetValues(entity);
                dbContext.SaveChanges();


                //dbContext.Entry(userInfoDB).State = EntityState.Modified;
                //dbContext.SaveChanges();

                return true;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<int> GetUserRole(int UserId)
        {
            //Fetching user details
            var userlist = dbContext.tbl_User.SingleOrDefault(user => user.iID == UserId);

            UserDetailsCommon res = new UserDetailsCommon();

            List<int> usrRoles = new List<int>();

            if (userlist != null)
            {
                foreach (var roleitem in userlist.tbl_UserRoleMapping)
                {
                    usrRoles.Add(roleitem.iRoleID);
                }
                res.RoleId = new List<int>();

                res.RoleId.AddRange(usrRoles);
            }
            return usrRoles;
        }

        public bool UpdateUserRole(int UserId, int roleId)
        {
            try
            {
                //Updating active role id in tbl_user
                tbl_User userInfoDB = new tbl_User();

                var entity = dbContext.tbl_User.FirstOrDefault(i => i.iID == UserId);
                if (entity != null)
                {
                    entity.iARoleID = roleId;
                    entity.dUpdatedDate = DateTime.UtcNow;
                }
                else
                {
                    //handle error:
                    throw new Exception("Issue not found");
                }

                dbContext.Entry(entity).Property("iARoleID").IsModified = true;
                dbContext.Entry(entity).Property("dUpdatedDate").IsModified = true;
                dbContext.SaveChanges();

                return true;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<GetUserList> GetManageUserDet1()
        {
            try
            {
                //Fetching user list details
                var userDet = (this.dbContext as GOSPA_TestEntities).GetUserList().ToList();

                List<GetUserList> usrdet = new List<GetUserList>();

                foreach (var item in userDet)
                {
                    GetUserList res = new GetUserList();

                    res.Id = item.UserId;
                    res.UserId = item.UserId;
                    res.UserName = item.UserName;
                    res.UserEmail = item.UserEmail;
                    res.Title = item.Title;
                    res.UserRole = item.UserRole;
                    res.CreatedBy = item.CreatedBy;
                    res.CreatedDate = item.CreatedDate ?? DateTime.Now;
                    usrdet.Add(res);
                }

                return usrdet;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<GetGriddata> GetGridDataDet(int ValueStream, int WeekId,int TimelineId)
        {
            try
            {
                DataSet ds = new DataSet();
                var ds1 = new DataSet();
                var ds2 = new DataSet();

                ////Fetching user list details
                //using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectGOSPA"].ConnectionString))
                //{
                //    SqlCommand sqlComm = new SqlCommand("GetGridData1", conn);
                //    sqlComm.Parameters.AddWithValue("@VSID", ValueStream);

                //    sqlComm.CommandType = CommandType.StoredProcedure;

                //    SqlDataAdapter da = new SqlDataAdapter();
                //    da.SelectCommand = sqlComm;

                //    da.Fill(ds);

                //    ds.Tables[0].Merge(ds.Tables[1]);
                //}

                //List<DataRow> rows = ds.Tables[0].Rows.Cast<DataRow>().ToList();

                ////List<GetGriddata> people = AutoMapper.Mapper.DynamicMap<IDataReader, List<GetGriddata>>(ds.CreateDataReader());
                //DataTable dt = new DataTable();
                //dt = ds.Tables[0];

                //List<GetGriddata> objList = dt.DataTableToList<GetGriddata>();


                var gridDet = (this.dbContext as GOSPA_TestEntities).GetGridData(ValueStream, WeekId, TimelineId).ToList();

                List<GetGriddata> grddet = new List<GetGriddata>();

                foreach (var item in gridDet)
                {
                    GetGriddata res = new GetGriddata();

                    res.iWGDID = item.iWGDID;
                    res.iTimelineID = item.iTimelineID;
                    res.iLOVID = item.iLOVID;
                    res.iMonth = item.iMonth;
                    res.iYear = item.iYear;
                    res.iWeekID = item.iWeekID;
                    res.vcTypeName = item.vcTypeName;
                    res.vcLovName = item.vcLovName;
                    res.iplan = item.iplan;
                    res.iLE_HFM = item.iLE_HFM;
                    res.iPriorPA = item.iPriorPA;
                    res.iActuals = item.iActuals;
                    res.iMTD = item.iMTD;
                    res.iEST = item.iEST;
                    res.iVP = item.iVP;
                    res.iVartoLEHFM = item.iVartoLEHFM;
                    res.iVartoPriorPA = item.iVartoPriorPA;
                    res.Comments = item.Comments;
                    res.iWeekID = item.iWeekID;
                    res.iVSID = item.iVSID;
                    res.UOM = item.UOM;

                    grddet.Add(res);
                }

                return grddet;

                //return objList;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }


        public List<GetGriddata> GetGridDataDetActuals(int ValueStream, int WeekId)
        {
            try
            {
                DataSet ds = new DataSet();
                var ds1 = new DataSet();
                var ds2 = new DataSet();

                var gridDet = (this.dbContext as GOSPA_TestEntities).GetGridData_Actuals(ValueStream, WeekId).ToList();

                List<GetGriddata> grddet = new List<GetGriddata>();

                foreach (var item in gridDet)
                {
                    GetGriddata res = new GetGriddata();

                    res.iWGDID = item.iWGDID;
                    res.iTimelineID = item.iTimelineID;
                    res.iLOVID = item.iLOVID;
                    res.iMonth = item.iMonth;
                    res.iYear = item.iYear;
                    res.iWeekID = item.iWeekID;
                    res.vcTypeName = item.vcTypeName;
                    res.vcLovName = item.vcLovName;
                    res.iplan = item.iplan;
                    res.iLE_HFM = item.iLE_HFM;
                    res.iPriorPA = item.iPriorPA;
                    res.iActuals = item.iActuals;
                    res.iMTD = item.iMTD;
                    //res.iEST = item.iEST;
                    res.iVP = item.iVP;
                    res.iVartoLEHFM = item.iVartoLEHFM;
                    res.iVartoPriorPA = item.iVartoPriorPA;
                    res.Comments = item.Comments;
                    res.iWeekID = item.iWeekID;
                    res.iVSID = item.iVSID;
                    res.UOM = item.UOM;

                    grddet.Add(res);
                }

                return grddet;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public List<GetOpsUserList> GetOpsUSerValueStreamDet(int UserId, int RoleId)
        {
            try
            {
                //Fetching ops user value stream details
                var ospsuservsDet = (this.dbContext as GOSPA_TestEntities).GetOpsUserValueStreamList(UserId, RoleId).ToList();

                List<GetOpsUserList> opsusrdet = new List<GetOpsUserList>();

                foreach (var item in ospsuservsDet)
                {
                    GetOpsUserList res = new GetOpsUserList();

                    res.iUserID = item.iID;
                    res.iVSID = item.iVSID;
                    res.vcValueStream = item.vcValueStream;
                    opsusrdet.Add(res);
                }

                return opsusrdet;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int CheckSubmitReqStatusDet(int ValueStream, int WeekId,int TimelineId)
        {
            try
            {
                var reqDet = (this.dbContext as GOSPA_TestEntities).CheckSubmitReqStatusDet(ValueStream, WeekId, TimelineId).SingleOrDefault();

                if (reqDet != null)
                {
                    return reqDet.Value;
                }
                else
                    return 100;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int FetchTimelineDet(int Year, int MonthId)
        {
            try
            {
                var timelineDet = (this.dbContext as GOSPA_TestEntities).FetchTimelineDet(Year, MonthId).SingleOrDefault();

                if (timelineDet != null)
                {
                    return timelineDet.Value;
                }
                else
                    return 0;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<GetUserList> GetOpsUserDet(int TimelineId, int VsId, int? Weekid)
        {
            try
            {
                List<GetUserList> userDet = new List<GetUserList>();

                var OpsDet = (this.dbContext as GOSPA_TestEntities).GetOpsUserDetails(TimelineId, VsId, Weekid).ToList();

                foreach (var item in OpsDet)
                {
                    GetUserList res = new GetUserList();

                    res.Id = item.iID;
                    res.UserName = item.vcName;
                    res.UserEmail = item.vcEmail;
                    userDet.Add(res);
                }

                return userDet;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<GetUserList> GetRejectFcUserDet(int TimelineId, int VsId, int? Weekid)
        {
            try
            {
                List<GetUserList> userDet = new List<GetUserList>();

                var OpsDet = (this.dbContext as GOSPA_TestEntities).GetRejectFcUserDetails(TimelineId, VsId, Weekid).ToList();

                foreach (var item in OpsDet)
                {
                    GetUserList res = new GetUserList();

                    res.Id = item.iID;
                    res.UserName = item.vcName;
                    res.UserEmail = item.vcEmail;
                    userDet.Add(res);
                }

                return userDet;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int GetMonthDet(int TimelineId)
        {
            try
            {
                var mDet = (this.dbContext as GOSPA_TestEntities).GetMonthDet(TimelineId).SingleOrDefault();

                if (mDet != null)
                {
                    return mDet.Value;
                }
                else
                    return 0;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public int CheckLovTypeExistanceDet(string vcTypeName, int iTotal)
        {
            try
            {
                var lovstatusDet = (this.dbContext as GOSPA_TestEntities).CheckLovTypeExistanceDet(vcTypeName, iTotal).SingleOrDefault();

                if (lovstatusDet != null)
                {
                    return lovstatusDet.Value;
                }
                else
                    return 100;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

    }
}
