﻿using GOSPA.Common.DTO;
using GOSPA.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOSPA.DataAccess.Interfaces
{
    public interface IUserDB
    {
        tbl_User GetUser(string userName);
        bool RegisterUser(string EmailId, string Name, int RoleId, string Title, string WindowsId);

        UserDetailsCommon GetManageUserDet(string WindowsId);

        List<GetUserList> GetManageUserDet1();
    }
}
