﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GOSPA.Common.DTO;
using GOSPA.DataModels;

namespace GOSPA.DataAccess.Interfaces
{
    public interface ILovDB
    {
        List<GetValueStreamList> GetValueStreamDet();
    }
}
