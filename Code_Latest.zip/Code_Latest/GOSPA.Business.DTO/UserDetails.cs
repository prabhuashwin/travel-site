﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOSPA.Business.DTO
{
    public class UserDetails
    {
        public int iID { get; set; }
        public string vcName { get; set; }
        public string vcEmail { get; set; }
        public Nullable<System.DateTime> dCreatedDate { get; set; }
        public string dCreatedBy { get; set; }
        public Nullable<bool> dStatus { get; set; }
    }
}
