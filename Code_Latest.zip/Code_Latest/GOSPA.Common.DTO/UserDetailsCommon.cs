﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOSPA.Common.DTO
{
    public class UserDetailsCommon
    {
        public int iID { get; set; }
        public string vcName { get; set; }
        public string vcEmail { get; set; }
        public Nullable<System.DateTime> dCreatedDate { get; set; }
        public string vcCreatedBy { get; set; }
        public Nullable<bool> dStatus { get; set; }
        public List<int> RoleId { get; set; }
        public string Title { get; set; }
        public string WindowsId { get; set; }
        public int iARoleId { get; set; }
        public string vcUpdatedBy { get; set; }
        public Nullable<System.DateTime> dUpdatedDate { get; set; }
    }

    public class GetUserList
    {
        public long Id { get; set; }
        public string UserName { get; set; }
        public string LoginId { get; set; }
        public string UserEmail { get; set; }
        public string Title { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UserRole { get; set; }
        public Nullable<int> UserStatus { get; set; }
        public long UserId { get; set; }
        public List<string> AllValueStream { get; set; }
        public string avs { get; set; }
    }

    public class GetOpsUserList
    {
        public int iUserID { get; set; }

        public int iVSID { get; set; }

        public string vcValueStream { get; set; }
    }

}
