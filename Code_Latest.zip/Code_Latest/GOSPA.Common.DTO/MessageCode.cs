﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    MessageCode.cs
* File Desc   :    This file contains code pertaining to DTO for Message Code class.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOSPA.Common.DTO
{
    public enum MessageCode
    {
        /// <summary>
        /// Represent operation failed
        /// </summary>
        OperationFailed = 0,

        /// <summary>
        /// Represent operation successful
        /// </summary>
        OperationSuccessful = 1,

        /// <summary>
        /// Represent UserDoesNotExist
        /// </summary>
        UserDoesNotExist = 2,

        /// <summary>
        /// Represent NonNegative
        /// </summary>
        NonNegative = 4,

        /// <summary>
        /// Represent InvalidEmailId
        /// </summary>
        InvalidEmailId = 5,

        /// <summary>
        /// Represent ObjectNull
        /// </summary>
        ObjectNull = 6,

        /// <summary>
        /// Represent StringNullEmpty
        /// </summary>
        StringNullEmpty = 7,

        /// <summary>
        /// Represent InvalidCredentials
        /// </summary>
        InvalidCredentials = 8,

        /// <summary>
        /// Represent InvalidSession
        /// </summary>
        InvalidSession = 9
    }
}
