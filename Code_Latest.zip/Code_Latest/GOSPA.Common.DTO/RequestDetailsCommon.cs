﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOSPA.Common.DTO
{
    public class RequestDetailsCommon
    {
    }

    public class RequestModel
    {
        public long RId { get; set; }
        public int iSheetID { get; set; }
        public int iRequestedById { get; set; }
        public int iRStatus { get; set; }
        public Nullable<DateTime> dRequestedOn { get; set; }
        public Nullable<DateTime> dUpdatedOn { get; set; }
        public int iRejectionCount { get; set; }
        public string vComments { get; set; }

    }

    public class GosSheetModel
    {
        public int iSheetID { get; set; }
        public int iTimeLineID { get; set; }
        public int iVSID { get; set; }
        public int iWeekID { get; set; }
        public string vcCreatedBy { get; set; }
    }
}
