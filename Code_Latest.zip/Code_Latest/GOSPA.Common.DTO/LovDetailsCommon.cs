﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOSPA.Common.DTO
{
    public class LovDetailsCommon
    {

    }

    public class GetGriddata
    {
        public int iWGDID { get; set; }
        public int iTimelineID { get; set; }
        public int iVSID { get; set; }
        public int iLOVID { get; set; }
        public int iMonth { get; set; }
        public int iYear { get; set; }
        public string vcTypeName { get; set; }
        public string vcLovName { get; set; }
        public Nullable<double> iplan { get; set; }
        public Nullable<double> iLE_HFM { get; set; }
        public Nullable<double> iPriorPA { get; set; }
        public Nullable<double> iMTD { get; set; }
        public Nullable<double> iActuals { get; set; }
        public Nullable<double> iEST { get; set; }
        public Nullable<double> iVP { get; set; }
        public Nullable<double> iVartoLEHFM { get; set; }
        public Nullable<double> iVartoPriorPA { get; set; }
        public string Comments { get; set; }
        public Nullable<int> iIsMonthData { get; set; }
        public Nullable<int> iQuarterID { get; set; }
        public Nullable<int> iWeekID { get; set; }
        public string UOM { get; set; }
    }

    public class GetValueStreamList
    {
        public long vSId { get; set; }
        public string vcValueStream { get; set; }
    }


    public class GetValueStreamDetails_consolidated    {
        public int iVSID { get; set; }
        public string vcValueStream { get; set; }
    }

    public partial class GetOpsUserValueStreamList
    {
        public int iID { get; set; }
        public int iRoleID { get; set; }
        public int iVSID { get; set; }
        public string vcValueStream { get; set; }
    }


    public class GetLovDetList
    {
        public long LovId { get; set; }
        public long LovTypeId { get; set; }
        public string vcTypeName { get; set; }
        public string vcLovName { get; set; }
        public string vcIUMeasure { get; set; }
        public Nullable<DateTime> dCreatedDate { get; set; }
        public string vcCreatedBy { get; set; }
        public Nullable<int> LovStatus { get; set; }

        public long iLTYPEID { get; set; }

        public int iTotal { get; set; }

        public int iLISActive { get; set; }

        public string vcLOVName { get; set; }

        public int iISActive { get; set; }

        public int iSTotal { get; set; }

        public int iOrder { get; set; }

    }

    public class GetWeekList
    {
        public int weekId { get; set; }
        public string vcWeekName { get; set; }
    }

    public class ConsolidatedData
    {
        public string vcTypeName { get; set; }
        public string vcLovName { get; set; }
        public string UoMeasure { get; set; }
        public string Jan_act { get; set; }
        public string Jan_plan { get; set; }
        public string Jan_LeHFM { get; set; }
        public string Jan_priorPA { get; set; }
        public string Jan_MTD { get; set; }
        public string Jan_est { get; set; }
        public string Jan_iVP { get; set; }
        public string Jan_iVartoLEHFM { get; set; }
        public string Jan_iVartoPriorPA { get; set; }
        public string Jan_isActuals { get; set; }
        public string Feb_act { get; set; }
        public string Feb_plan { get; set; }
        public string Feb_LeHFM { get; set; }
        public string FEB_iVartoPriorPA { get; set; }
        public string Feb_priorPA { get; set; }
        public string Feb_MTD { get; set; }
        public string Feb_est { get; set; }
        public string Feb_iVP { get; set; }
        public string Feb_iVartoLEHFM { get; set; }
        public string Feb_isActuals { get; set; }
        public string Mar_act { get; set; }
        public string Mar_plan { get; set; }
        public string Mar_LeHFM { get; set; }
        public string Mar_priorPA { get; set; }
        public string Mar_MTD { get; set; }
        public string Mar_est { get; set; }
        public string Mar_iVP { get; set; }
        public string Mar_iVartoLEHFM { get; set; }
        public string Mar_iVartoPriorPA { get; set; }
        public string Mar_isActuals { get; set; }
        public string Apr_act { get; set; }
        public string Apr_plan { get; set; }
        public string Apr_LeHFM { get; set; }
        public string Apr_priorPA { get; set; }
        public string Apr_MTD { get; set; }
        public string Apr_est { get; set; }
        public string Apr_iVP { get; set; }
        public string Apr_iVartoLEHFM { get; set; }
        public string Apr_iVartoPriorPA { get; set; }
        public string Apr_isActuals { get; set; }
        public string May_act { get; set; }
        public string May_plan { get; set; }
        public string May_LeHFM { get; set; }
        public string May_priorPA { get; set; }
        public string May_MTD { get; set; }
        public string May_est { get; set; }
        public string May_iVP { get; set; }
        public string May_iVartoLEHFM { get; set; }
        public string May_iVartoPriorPA { get; set; }
        public string May_isActuals { get; set; }
        public string Jun_act { get; set; }
        public string Jun_plan { get; set; }
        public string Jun_LeHFM { get; set; }
        public string Jun_priorPA { get; set; }
        public string Jun_MTD { get; set; }
        public string Jun_est { get; set; }
        public string Jun_iVP { get; set; }
        public string Jun_iVartoLEHFM { get; set; }
        public string Jun_iVartoPriorPA { get; set; }
        public string Jun_isActuals { get; set; }
        public string Jul_act { get; set; }
        public string Jul_plan { get; set; }
        public string Jul_LeHFM { get; set; }
        public string Jul_priorPA { get; set; }
        public string Jul_MTD { get; set; }
        public string Jul_est { get; set; }
        public string Jul_iVP { get; set; }
        public string Jul_iVartoLEHFM { get; set; }
        public string Jul_iVartoPriorPA { get; set; }
        public string Jul_isActuals { get; set; }
        public string Aug_act { get; set; }
        public string Aug_plan { get; set; }
        public string Aug_LeHFM { get; set; }
        public string Aug_priorPA { get; set; }
        public string Aug_MTD { get; set; }
        public string Aug_est { get; set; }
        public string Aug_iVP { get; set; }
        public string Aug_iVartoLEHFM { get; set; }
        public string Aug_iVartoPriorPA { get; set; }
        public string Aug_isActuals { get; set; }
        public string Sep_act { get; set; }
        public string Sep_plan { get; set; }
        public string Sep_LeHFM { get; set; }
        public string Sep_priorPA { get; set; }
        public string Sep_MTD { get; set; }
        public string Sep_est { get; set; }
        public string Sep_iVP { get; set; }
        public string Sep_iVartoLEHFM { get; set; }
        public string Sep_iVartoPriorPA { get; set; }
        public string Sep_isActuals { get; set; }
        public string Oct_act { get; set; }
        public string Oct_plan { get; set; }
        public string Oct_LeHFM { get; set; }
        public string Oct_priorPA { get; set; }
        public string Oct_MTD { get; set; }
        public string Oct_est { get; set; }
        public string Oct_iVP { get; set; }
        public string Oct_iVartoLEHFM { get; set; }
        public string Oct_iVartoPriorPA { get; set; }
        public string Oct_isActuals { get; set; }
        public string Nov_act { get; set; }
        public string Nov_plan { get; set; }
        public string Nov_LeHFM { get; set; }
        public string Nov_priorPA { get; set; }
        public string Nov_MTD { get; set; }
        public string Nov_est { get; set; }
        public string Nov_iVP { get; set; }
        public string Nov_iVartoLEHFM { get; set; }
        public string Nov_iVartoPriorPA { get; set; }
        public string Nov_isActuals { get; set; }
        public string Dec_act { get; set; }
        public string Dec_plan { get; set; }
        public string Dec_LeHFM { get; set; }
        public string Dec_priorPA { get; set; }
        public string Dec_MTD { get; set; }
        public string Dec_est { get; set; }
        public string Dec_iVP { get; set; }
        public string Dec_iVartoLEHFM { get; set; }
        public string Dec_iVartoPriorPA { get; set; }
        public string Dec_isActuals { get; set; }
        public string Q1Plan { get; set; }
        public string Q1Est { get; set; }
        public string Q1Variance { get; set; }
        public string Q1_act { get; set; }
        public string Q1_isActuals { get; set; }
        public string Q2Plan { get; set; }
        public string Q2Est { get; set; }
        public string Q2Variance { get; set; }
        public string Q2_act { get; set; }
        public string Q2_isActuals { get; set; }
        public string Q3Plan { get; set; }
        public string Q3Est { get; set; }
        public string Q3Variance { get; set; }
        public string Q3_act { get; set; }
        public string Q3_isActuals { get; set; }
        public string Q4Plan { get; set; }
        public string Q4Est { get; set; }
        public string Q4Variance { get; set; }
        public string Q4_act { get; set; }
        public string Q4_isActuals { get; set; }
        public string Comments { get; set; }
    }

    public class LeadingIndicatorUomeasure
    {

        public string UoMeasure { get; set; }
        public string iOrder { get; set; }
        public string vcLOVName { get; set; }
        public string Jan_Evacs_Actuals { get; set; }
        public string Jan_Seats_Actuals { get; set; }
        public string Jan_Lighting_Actuals { get; set; }
        public string Jan_Actuation_Actuals { get; set; }
        public string Jan_Avionics_Actuals { get; set; }
        public string Jan_Water_Actuals { get; set; }
        public string Jan_TotalActuals { get; set; }
        public string Feb_Evacs_LeHFM { get; set; }
        public string Feb_Seats_LeHFM { get; set; }
        public string Feb_Lighting_LeHFM { get; set; }
        public string Feb_Actuation_LeHFM { get; set; }
        public string Feb_Avionics_LeHFM { get; set; }
        public string Feb_Water_LeHFM { get; set; }
        public string Feb_TotalLeHFM { get; set; }
        public string Feb_Evacs_Est { get; set; }
        public string Feb_Seats_Est { get; set; }
        public string Feb_Lighting_Est { get; set; }
        public string Feb_Actuation_Est { get; set; }
        public string Feb_Avionics_Est { get; set; }
        public string Feb_Water_Est { get; set; }
        public string Feb_TotalEstimate { get; set; }
        public string Feb_Evacs_PriorPa { get; set; }
        public string Feb_Seats_PriorPa { get; set; }
        public string Feb_Lighting_PriorPa { get; set; }
        public string Feb_Actuation_PriorPa { get; set; }
        public string Feb_Avionics_PriorPa { get; set; }
        public string Feb_Water_PriorPa { get; set; }
        public string Feb_TotalPriorPA { get; set; }
        public string Mar_Evacs_LeHFM { get; set; }
        public string Mar_Seats_LeHFM { get; set; }
        public string Mar_Lighting_LeHFM { get; set; }
        public string Mar_Actuation_LeHFM { get; set; }
        public string Mar_Avionics_LeHFM { get; set; }
        public string Mar_Water_LeHFM { get; set; }
        public string Mar_TotalLeHFM { get; set; }
        public string Mar_Evacs_Est { get; set; }
        public string Mar_Seats_Est { get; set; }
        public string Mar_Lighting_Est { get; set; }
        public string Mar_Actuation_Est { get; set; }
        public string Mar_Avionics_Est { get; set; }
        public string Mar_Water_Est { get; set; }
        public string Mar_TotalEstimate { get; set; }
        public string Mar_Evacs_PriorPa { get; set; }
        public string Mar_Seats_PriorPa { get; set; }
        public string Mar_Lighting_PriorPa { get; set; }
        public string Mar_Actuation_PriorPa { get; set; }
        public string Mar_Avionics_PriorPa { get; set; }
        public string Mar_Water_PriorPa { get; set; }
        public string Mar_TotalPriorPA { get; set; }
        public string Apr_Evacs_LeHFM { get; set; }
        public string Apr_Seats_LeHFM { get; set; }
        public string Apr_Lighting_LeHFM { get; set; }
        public string Apr_Actuation_LeHFM { get; set; }
        public string Apr_Avionics_LeHFM { get; set; }
        public string Apr_Water_LeHFM { get; set; }
        public string Apr_TotalLeHFM { get; set; }
        public string Apr_Evacs_Est { get; set; }
        public string Apr_Seats_Est { get; set; }
        public string Apr_Lighting_Est { get; set; }
        public string Apr_Actuation_Est { get; set; }
        public string Apr_Avionics_Est { get; set; }
        public string Apr_Water_Est { get; set; }
        public string Apr_TotalEstimate { get; set; }
        public string Apr_Evacs_PriorPa { get; set; }
        public string Apr_Seats_PriorPa { get; set; }
        public string Apr_Lighting_PriorPa { get; set; }
        public string Apr_Actuation_PriorPa { get; set; }
        public string Apr_Avionics_PriorPa { get; set; }
        public string Apr_Water_PriorPa { get; set; }
        public string Apr_TotalPriorPA { get; set; }
        public string May_Evacs_LeHFM { get; set; }
        public string May_Seats_LeHFM { get; set; }
        public string May_Lighting_LeHFM { get; set; }
        public string May_Actuation_LeHFM { get; set; }
        public string May_Avionics_LeHFM { get; set; }
        public string May_Water_LeHFM { get; set; }
        public string May_TotalLeHFM { get; set; }
        public string May_Evacs_Est { get; set; }
        public string May_Seats_Est { get; set; }
        public string May_Lighting_Est { get; set; }
        public string May_Actuation_Est { get; set; }
        public string May_Avionics_Est { get; set; }
        public string May_Water_Est { get; set; }
        public string May_TotalEstimate { get; set; }
        public string May_Evacs_PriorPa { get; set; }
        public string May_Seats_PriorPa { get; set; }
        public string May_Lighting_PriorPa { get; set; }
        public string May_Actuation_PriorPa { get; set; }
        public string May_Avionics_PriorPa { get; set; }
        public string May_Water_PriorPa { get; set; }
        public string May_TotalPriorPA { get; set; }
        public string Jun_Evacs_LeHFM { get; set; }
        public string Jun_Seats_LeHFM { get; set; }
        public string Jun_Lighting_LeHFM { get; set; }
        public string Jun_Actuation_LeHFM { get; set; }
        public string Jun_Avionics_LeHFM { get; set; }
        public string Jun_Water_LeHFM { get; set; }
        public string Jun_TotalLeHFM { get; set; }
        public string Jun_Evacs_Est { get; set; }
        public string Jun_Seats_Est { get; set; }
        public string Jun_Lighting_Est { get; set; }
        public string Jun_Actuation_Est { get; set; }
        public string Jun_Avionics_Est { get; set; }
        public string Jun_Water_Est { get; set; }
        public string Jun_TotalEstimate { get; set; }
        public string Jun_Evacs_PriorPa { get; set; }
        public string Jun_Seats_PriorPa { get; set; }
        public string Jun_Lighting_PriorPa { get; set; }
        public string Jun_Actuation_PriorPa { get; set; }
        public string Jun_Avionics_PriorPa { get; set; }
        public string Jun_Water_PriorPa { get; set; }
        public string Jun_TotalPriorPA { get; set; }
        public string Jul_Evacs_LeHFM { get; set; }
        public string Jul_Seats_LeHFM { get; set; }
        public string Jul_Lighting_LeHFM { get; set; }
        public string Jul_Actuation_LeHFM { get; set; }
        public string Jul_Avionics_LeHFM { get; set; }
        public string Jul_Water_LeHFM { get; set; }
        public string Jul_TotalLeHFM { get; set; }
        public string Jul_Evacs_Est { get; set; }
        public string Jul_Seats_Est { get; set; }
        public string Jul_Lighting_Est { get; set; }
        public string Jul_Actuation_Est { get; set; }
        public string Jul_Avionics_Est { get; set; }
        public string Jul_Water_Est { get; set; }
        public string Jul_TotalEstimate { get; set; }
        public string Jul_Evacs_PriorPa { get; set; }
        public string Jul_Seats_PriorPa { get; set; }
        public string Jul_Lighting_PriorPa { get; set; }
        public string Jul_Actuation_PriorPa { get; set; }
        public string Jul_Avionics_PriorPa { get; set; }
        public string Jul_Water_PriorPa { get; set; }
        public string Jul_TotalPriorPA { get; set; }
        public string Aug_Evacs_LeHFM { get; set; }
        public string Aug_Seats_LeHFM { get; set; }
        public string Aug_Lighting_LeHFM { get; set; }
        public string Aug_Actuation_LeHFM { get; set; }
        public string Aug_Avionics_LeHFM { get; set; }
        public string Aug_Water_LeHFM { get; set; }
        public string Aug_TotalLeHFM { get; set; }
        public string Aug_Evacs_Est { get; set; }
        public string Aug_Seats_Est { get; set; }
        public string Aug_Lighting_Est { get; set; }
        public string Aug_Actuation_Est { get; set; }
        public string Aug_Avionics_Est { get; set; }
        public string Aug_Water_Est { get; set; }
        public string Aug_TotalEstimate { get; set; }
        public string Aug_Evacs_PriorPa { get; set; }
        public string Aug_Seats_PriorPa { get; set; }
        public string Aug_Lighting_PriorPa { get; set; }
        public string Aug_Actuation_PriorPa { get; set; }
        public string Aug_Avionics_PriorPa { get; set; }
        public string Aug_Water_PriorPa { get; set; }
        public string Aug_TotalPriorPA { get; set; }
        public string Sep_Evacs_LeHFM { get; set; }
        public string Sep_Seats_LeHFM { get; set; }
        public string Sep_Lighting_LeHFM { get; set; }
        public string Sep_Actuation_LeHFM { get; set; }
        public string Sep_Avionics_LeHFM { get; set; }
        public string Sep_Water_LeHFM { get; set; }
        public string Sep_TotalLeHFM { get; set; }
        public string Sep_Evacs_Est { get; set; }
        public string Sep_Seats_Est { get; set; }
        public string Sep_Lighting_Est { get; set; }
        public string Sep_Actuation_Est { get; set; }
        public string Sep_Avionics_Est { get; set; }
        public string Sep_Water_Est { get; set; }
        public string Sep_TotalEstimate { get; set; }
        public string Sep_Evacs_PriorPa { get; set; }
        public string Sep_Seats_PriorPa { get; set; }
        public string Sep_Lighting_PriorPa { get; set; }
        public string Sep_Actuation_PriorPa { get; set; }
        public string Sep_Avionics_PriorPa { get; set; }
        public string Sep_Water_PriorPa { get; set; }
        public string Sep_TotalPriorPA { get; set; }
        public string Oct_Evacs_LeHFM { get; set; }
        public string Oct_Seats_LeHFM { get; set; }
        public string Oct_Lighting_LeHFM { get; set; }
        public string Oct_Actuation_LeHFM { get; set; }
        public string Oct_Avionics_LeHFM { get; set; }
        public string Oct_Water_LeHFM { get; set; }
        public string Oct_TotalLeHFM { get; set; }
        public string Oct_Evacs_Est { get; set; }
        public string Oct_Seats_Est { get; set; }
        public string Oct_Lighting_Est { get; set; }
        public string Oct_Actuation_Est { get; set; }
        public string Oct_Avionics_Est { get; set; }
        public string Oct_Water_Est { get; set; }
        public string Oct_TotalEstimate { get; set; }
        public string Oct_Evacs_PriorPa { get; set; }
        public string Oct_Seats_PriorPa { get; set; }
        public string Oct_Lighting_PriorPa { get; set; }
        public string Oct_Actuation_PriorPa { get; set; }
        public string Oct_Avionics_PriorPa { get; set; }
        public string Oct_Water_PriorPa { get; set; }
        public string Oct_TotalPriorPA { get; set; }
        public string Nov_Evacs_LeHFM { get; set; }
        public string Nov_Seats_LeHFM { get; set; }
        public string Nov_Lighting_LeHFM { get; set; }
        public string Nov_Actuation_LeHFM { get; set; }
        public string Nov_Avionics_LeHFM { get; set; }
        public string Nov_Water_LeHFM { get; set; }
        public string Nov_TotalLeHFM { get; set; }
        public string Nov_Evacs_Est { get; set; }
        public string Nov_Seats_Est { get; set; }
        public string Nov_Lighting_Est { get; set; }
        public string Nov_Actuation_Est { get; set; }
        public string Nov_Avionics_Est { get; set; }
        public string Nov_Water_Est { get; set; }
        public string Nov_TotalEstimate { get; set; }
        public string Nov_Evacs_PriorPa { get; set; }
        public string Nov_Seats_PriorPa { get; set; }
        public string Nov_Lighting_PriorPa { get; set; }
        public string Nov_Actuation_PriorPa { get; set; }
        public string Nov_Avionics_PriorPa { get; set; }
        public string Nov_Water_PriorPa { get; set; }
        public string Nov_TotalPriorPA { get; set; }
        public string Dec_Evacs_LeHFM { get; set; }
        public string Dec_Seats_LeHFM { get; set; }
        public string Dec_Lighting_LeHFM { get; set; }
        public string Dec_Actuation_LeHFM { get; set; }
        public string Dec_Avionics_LeHFM { get; set; }
        public string Dec_Water_LeHFM { get; set; }
        public string Dec_TotalLeHFM { get; set; }
        public string Dec_Evacs_Est { get; set; }
        public string Dec_Seats_Est { get; set; }
        public string Dec_Lighting_Est { get; set; }
        public string Dec_Actuation_Est { get; set; }
        public string Dec_Avionics_Est { get; set; }
        public string Dec_Water_Est { get; set; }
        public string Dec_TotalEstimate { get; set; }
        public string Dec_Evacs_PriorPa { get; set; }
        public string Dec_Seats_PriorPa { get; set; }
        public string Dec_Lighting_PriorPa { get; set; }
        public string Dec_Actuation_PriorPa { get; set; }
        public string Dec_Avionics_PriorPa { get; set; }
        public string Dec_Water_PriorPa { get; set; }
        public string Dec_TotalPriorPA { get; set; }

    }


}
