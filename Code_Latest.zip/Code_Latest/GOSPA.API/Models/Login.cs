﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GOSPA.API.Models
{
    public class Login
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public bool Status { get; set; }
    }
}