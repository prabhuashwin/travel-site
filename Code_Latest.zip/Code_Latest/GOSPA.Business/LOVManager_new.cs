﻿using System;
using System.Web;
using GOSPA.Common.DTO;
using GOSPA.ExceptionHandler.Exception;
using SAP.Framework.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using GOSPA.DataAccess;
using GOSPA.ExceptionHandler.Utilities;
using GOSPA.DataAccess.Infrastructure;
using GOSPA.Business.DTO;

namespace GOSPA.Business
{
    public class LOVManager
    {
        public OperationResult GetUserDetails()
        {
            try
            {
                //bool isSuccess;

                List<UserDetailsCommon> usrdet = new List<UserDetailsCommon>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrdet = userDB.GetManageUserDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetInActiveUserDetails()
        {
            try
            {
                List<UserDetailsCommon> inActusrdet = new List<UserDetailsCommon>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    inActusrdet = userDB.GetManageUserDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = inActusrdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetUserDetails1()
        {
            try
            {
                List<GetUserList> usrdet = new List<GetUserList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrdet = userDB.GetManageUserDet1();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetGridData(int ValueStream, int Weekid)
        {
            try
            {
                List<GetGriddata> usrdet = new List<GetGriddata>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrdet = userDB.GetGridDataDet(ValueStream, Weekid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetValueStreamData()
        {
            try
            {
                List<string> vsdet = new List<string>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    vsdet = lovDB.GetValueStreamDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = vsdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetValueStreamData1(int UserId)
        {
            try
            {
                List<string> vsdet = new List<string>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    vsdet = lovDB.GetValueStreamDet1(UserId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = vsdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertDemandData(string vcTypeName, string vcLovName, int weekid, int LEFHM, int PriorA, int MTD, int Userid)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.InsertDemandDet(vcTypeName, vcLovName, weekid, LEFHM, PriorA, MTD, Userid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Demand details Saved successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetLovDetails()
        {
            try
            {
                List<GetLovDetList> lovdet = new List<GetLovDetList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    lovdet = lovDB.GetManageLOVDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = lovdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateLeadingIndicators(int LovId, string LovName, string UMeasure,
                                                       int? LovStatus, int UserId)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.UpdateLeadingIndicators(LovId, LovName, UMeasure,
                                                              LovStatus, UserId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Leading Indicators Updated successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateDemandDet(int iWGDId, double iLE_HFM, double iPriorPA, double iMTD, int UserId)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.UpdateDemandDetails(iWGDId, iLE_HFM, iPriorPA, iMTD, UserId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "User Activated successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertIntoRequest(int TimelineId, int VsId, int? Weekid, string UserName, int UserId, int RStatus)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.InsertRequestTable(TimelineId, VsId, Weekid, UserName, UserId, RStatus);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "User registered successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult ValidateReqSheet(int TimelineId, int VsId, int? Weekid)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.ValidateRequestSheet(TimelineId, VsId, Weekid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "User registered successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertIntoReqHistory(int TimelineId, int VsId, int? Weekid, string UserName, int UserId, int RoleId)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.InsertIntoReqHistoryTable(TimelineId, VsId, Weekid, UserName, UserId ,RoleId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Details inserted successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetFCLTUserDetails(int roleid)
        {
            try
            {
                //List<GetUserList> usrdet = new List<GetUserList>();
                List<string> fcLTdet = new List<string>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    fcLTdet = lovDB.GetFCLTDetails(roleid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = fcLTdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetVSData()
        {
            try
            {
                List<string> vsdet = new List<string>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    vsdet = lovDB.GetValueStreamDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched value stream details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = vsdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateSubmitRequest(int TimelineId, int VsId, int? Weekid, string UserName, int UserId, int RStatus, int RoleId)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.UpdateSubmitRequestTable(TimelineId, VsId, Weekid, UserName, UserId, RStatus, RoleId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Details updated successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateLOVTotals(int? Weekid, int VsId, int TimelineId, string LovType)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.UpdateLOVT(Weekid, VsId, TimelineId, LovType);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Details updated successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult CheckSubmitReqStatus(int ValueStream, int Weekid)
        {
            try
            {
                //List<GetGriddata> usrdet = new List<GetGriddata>();

                int ReqStatus = 100;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    ReqStatus = userDB.CheckSubmitReqStatusDet(ValueStream, Weekid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = ReqStatus
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}
