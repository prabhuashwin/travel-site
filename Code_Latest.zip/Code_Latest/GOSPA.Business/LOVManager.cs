﻿using System;
using System.Web;
using GOSPA.Common.DTO;
using GOSPA.ExceptionHandler.Exception;
using SAP.Framework.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using GOSPA.DataAccess;
using GOSPA.ExceptionHandler.Utilities;
using GOSPA.DataAccess.Infrastructure;
using GOSPA.Business.DTO;

namespace GOSPA.Business
{
    public class LOVManager
    {
        public OperationResult GetUserDetails()
        {
            try
            {
                //bool isSuccess;

                List<UserDetailsCommon> usrdet = new List<UserDetailsCommon>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrdet = userDB.GetManageUserDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetInActiveUserDetails()
        {
            try
            {
                List<UserDetailsCommon> inActusrdet = new List<UserDetailsCommon>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    inActusrdet = userDB.GetManageUserDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = inActusrdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetRolebased_UserList()
        {
            try
            {
                List<GetUserList> usrdet = new List<GetUserList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    //usrdet = userDB.GetManageUserDet1();
                    usrdet = userDB.GetRolebased_UserList();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult GetUserDetails1()
        {
            try
            {
                List<GetUserList> usrdet = new List<GetUserList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrdet = userDB.GetManageUserDet1();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetGridData(int ValueStream, int Weekid, int TimelineId)
        {
            try
            {
                List<GetGriddata> usrdet = new List<GetGriddata>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrdet = userDB.GetGridDataDet(ValueStream, Weekid, TimelineId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetGridDataActuals(int ValueStream, int Weekid)
        {
            try
            {
                List<GetGriddata> usrdet = new List<GetGriddata>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrdet = userDB.GetGridDataDetActuals(ValueStream, Weekid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetValueStreamData()
        {
            try
            {
                List<GetValueStreamList> vsdet = new List<GetValueStreamList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    vsdet = lovDB.GetValueStreamDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = vsdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetValueStreamData1()
        {
            try
            {
                List<string> vsdet = new List<string>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    vsdet = lovDB.GetValueStreamDet1();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = vsdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetValueStreamData2()
        {
            try
            {
                List<GetValueStreamDetails_consolidated> vsdet = new List<GetValueStreamDetails_consolidated>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    vsdet = lovDB.GetValueStreamDet2();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = vsdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertDemandData(string vcTypeName, string vcLovName, int weekid, int LEFHM, int PriorA, int MTD, int Userid)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.InsertDemandDet(vcTypeName, vcLovName, weekid, LEFHM, PriorA, MTD, Userid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Demand details Saved successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetLovDetails()
        {
            try
            {
                List<GetLovDetList> lovdet = new List<GetLovDetList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    lovdet = lovDB.GetManageLOVDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = lovdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetDynLovDetails()
        {
            try
            {
                List<GetLovDetList> lovdet = new List<GetLovDetList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    lovdet = lovDB.GetManageDynLOVDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = lovdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateLeadingIndicators(int LovId, string LovName, string UMeasure,
                                                       int? LovStatus, int UserId)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.UpdateLeadingIndicators(LovId, LovName, UMeasure,
                                                              LovStatus, UserId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Leading Indicators Updated successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateDemandDet(int iWGDId, double iLE_HFM, double iMTD, double iEST,double iActuals, string Comments, int UserId)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.UpdateDemandDetails(iWGDId, iLE_HFM, iMTD, iEST, iActuals, Comments, UserId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "User Activated successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertIntoRequest(int TimelineId, int VsId, int? Weekid, string UserName, int UserId, int RStatus)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.InsertRequestTable(TimelineId, VsId, Weekid, UserName, UserId, RStatus);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "User registered successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult ValidateReqSheet(int TimelineId, int VsId, int? Weekid)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.ValidateRequestSheet(TimelineId, VsId, Weekid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "User registered successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertIntoReqHistory(int TimelineId, int VsId, int? Weekid, string UserName, int UserId, int RoleId)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.InsertIntoReqHistoryTable(TimelineId, VsId, Weekid, UserName, UserId, RoleId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Details inserted successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetFCLTUserDetails(int roleid)
        {
            try
            {
                //List<GetUserList> usrdet = new List<GetUserList>();
                List<string> fcLTdet = new List<string>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    fcLTdet = lovDB.GetFCLTDetails(roleid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = fcLTdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetVSData()
        {
            try
            {
                List<GetValueStreamList> vsdet = new List<GetValueStreamList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    vsdet = lovDB.GetValueStreamDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched value stream details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = vsdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetFCVSData(int UserId)
        {
            try
            {
                List<GetValueStreamList> vsdet = new List<GetValueStreamList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    vsdet = lovDB.GetFCValueStreamDet(UserId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched value stream details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = vsdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateSubmitRequest(int TimelineId, int VsId, int? Weekid, string UserName, int UserId, int RStatus, int RoleId)
        {
            try
            {
                //bool isSuccess;
                int Reqid = 0;
                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    Reqid = lovDB.UpdateSubmitRequestTable(TimelineId, VsId, Weekid, UserName, UserId, RStatus, RoleId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Details updated successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = Reqid
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateLOVTotals(int? Weekid, int VsId, int TimelineId, string LovType)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.UpdateLOVT(Weekid, VsId, TimelineId, LovType);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Details updated successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult CheckSubmitReqStatus(int ValueStream, int WeekId, int TimelineId)
        {
            try
            {
                //List<GetGriddata> usrdet = new List<GetGriddata>();

                int ReqStatus = 100;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    ReqStatus = userDB.CheckSubmitReqStatusDet(ValueStream, WeekId, TimelineId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = ReqStatus
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult FetchTimelineDetails(int Year, int MonthId)
        {
            try
            {
                int TimelineId = 0;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    TimelineId = userDB.FetchTimelineDet(Year, MonthId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched timeline details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = TimelineId
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetWeekData(DateTime currentDate, int vsid)
        {
            try
            {
                List<GetWeekList> wkdet = new List<GetWeekList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    wkdet = lovDB.GetWeekDataDet(currentDate, vsid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched week data details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = wkdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetTimeLine()
        {
            try
            {
                List<int> yearDetails = new List<int>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    yearDetails = lovDB.GetTimeLine();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched week data details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = yearDetails
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
  public OperationResult FetchLOVTypes()
        {
            try
            {
                List<GetValueStreamList> vsdet = new List<GetValueStreamList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    vsdet = lovDB.GetValueStreamDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = vsdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetMonthValue(int TimelineId)
        {
            try
            {
                int MonthVal = 0;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    MonthVal = userDB.GetMonthDet(TimelineId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = MonthVal
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult CheckLovTypeExistance(string vcTypeName, int iTotal)
        {
            try
            {
                int LovStatus = 100;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    LovStatus = userDB.CheckLovTypeExistanceDet(vcTypeName, iTotal);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched Lov Status details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = LovStatus
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult InsertLovType(string vcTypeName, int iTotal, string UserName)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.InsertLovTypeTable(vcTypeName, iTotal, UserName);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Lov Type inserted successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateLOVTypeDetails(int iLTYPEID, string vcTypeName,
                                                    int iTotal, int iLISActive, int UserId)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.UpdateLOVTypeDet(iLTYPEID, vcTypeName,
                                                       iTotal, iLISActive, UserId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Leading Indicators Updated successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        //public OperationResult GetLovSubTypeDetails(int iTypeId)
        //{
        //    try
        //    {
        //        List<GetLovDetList> lovsubtyepdet = new List<GetLovDetList>();

        //        using (UnitOfWork uow = new UnitOfWork())
        //        {
        //            var lovDB = uow.GetDbInterface<LovDB>();
        //            lovsubtyepdet = lovDB.GetManageLOVSubTypDet(iTypeId);
        //        }

        //        return new OperationResult()
        //        {
        //            Success = true,
        //            Message = "Fetched lov sub type details successfully",
        //            MCode = MessageCode.OperationSuccessful,
        //            Data = lovsubtyepdet
        //        };
        //    }
        //    catch (GOSPAException exception)
        //    {
        //        LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
        //        return exception.Result;
        //    }
        //    catch (Exception exception)
        //    {
        //        LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
        //        throw;
        //    }
        //}

        #region Rejection

        public OperationResult GetOpsUserDetails(int TimelineId, int VsId, int? Weekid)
        {
            try
            {
                List<GetUserList> usrlist = new List<GetUserList>();
                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrlist = userDB.GetOpsUserDet(TimelineId, VsId, Weekid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched user details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrlist
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }


        public OperationResult GetRejectFCUserDetails(int TimelineId, int VsId, int? Weekid)
        {
            try
            {
                List<GetUserList> usrlist = new List<GetUserList>();
                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrlist = userDB.GetRejectFcUserDet(TimelineId, VsId, Weekid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched user details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrlist
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        public OperationResult UpdateRejectStatus(int TimelineId, int VsId, int? Weekid, string UserName, int RoleId)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    isSuccess = lovDB.UpdateRejectStatusTable(TimelineId, VsId, Weekid, UserName, RoleId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Details updated successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }


        #endregion


        #region consolidated sheet

        public OperationResult GetValueStreamDetails_consolidated(int roleid, int iUserID)
        {
            try
            {
                List<GetValueStreamDetails_consolidated> vsdet = new List<GetValueStreamDetails_consolidated>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var lovDB = uow.GetDbInterface<LovDB>();
                    //vsdet = lovDB.GetValueStreamDet();
                    vsdet = lovDB.GetValueStreamDetails(roleid, iUserID);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched value stream details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = vsdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
        #endregion

        #region consolidatedsheet


        #endregion consolidated sheet



    }
}
