﻿using GOSPA.Common.DTO;
using GOSPA.ExceptionHandler.Exception;
using SAP.Framework.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using GOSPA.DataAccess;
using GOSPA.ExceptionHandler.Utilities;
using GOSPA.DataAccess.Infrastructure;

namespace GOSPA.Business
{
    public class UserManager
    {
        public OperationResult RegisterUser(string Name, string EmailId, int RoleId, string Title, string WindowsId)
        {
            try
            {
                bool isSuccess;
                Name.GuardNullEmpty("Name");
                EmailId.GuardNullEmpty("EmailId");
                Title.GuardNullEmpty("Title");
                WindowsId.GuardNullEmpty("WindowsId");

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    isSuccess = userDB.RegisterUser(Name, EmailId, RoleId, Title, WindowsId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "User registered successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public UserDetailsCommon GetUserDetailsWindows(string WindowsId)
        {
            try
            {
                UserDetailsCommon usrdet = new UserDetailsCommon();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrdet = userDB.GetManageUserDet(WindowsId);
                }

                //return new OperationResult()
                //{
                //    Success = true,
                //    Message = "Fetched User details successfully",
                //    MCode = MessageCode.OperationSuccessful,
                //    Data = usrdet
                //};
                return usrdet;
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult ApproveInActiveUsers(int userId, string updatedBy)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    isSuccess = userDB.UpdateUser(userId, updatedBy);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "User Activated successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<int> GetUserRoles(int userId)
        {
            try
            {
                //UserDetailsCommon usrdet = new UserDetailsCommon();

                List<int> usrdet = new List<int>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrdet = userDB.GetUserRole(userId);
                }

                //return new OperationResult()
                //{
                //    Success = true,
                //    Message = "Fetched User details successfully",
                //    MCode = MessageCode.OperationSuccessful,
                //    Data = usrdet
                //};
                return usrdet;
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult UpdateUserActiveRole(int userId, int roleid)
        {
            try
            {
                bool isSuccess;

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    isSuccess = userDB.UpdateUserRole(userId, roleid);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "User Role Update Successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OperationResult GetOpsUSerValueStream(int UserId,int RoleId)
        {
            try
            {
                List<GetOpsUserList> usrdet = new List<GetOpsUserList>();

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrdet = userDB.GetOpsUSerValueStreamDet(UserId, RoleId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrdet
                };
            }
            catch (GOSPAException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}
