﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    BaseDto.cs
* File Desc   :    This file contains code pertaining to DTO for base class.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Globalization;

namespace SAP.Business.DTO
{
    /// <summary>
    /// 
    /// </summary>
    public class BaseDto
    {

        /// <summary>
        /// Gets the modified date time string.
        /// </summary>
        /// <value>
        /// The modified date time string.
        /// </value>
        public string ModifiedDateTimeStr =>
            ModifiedDateTime.ToString("yyyy MM dd HH mm ss", CultureInfo.InvariantCulture);


        /// <summary>
        /// Gets the created date time string.
        /// </summary>
        /// <value>
        /// The created date time string.
        /// </value>
        public string CreatedDateTimeStr =>
            CreatedDateTime.ToString("yyyy MM dd HH mm ss", CultureInfo.InvariantCulture);


        /// <summary>
        /// Gets or sets the modified date time.
        /// </summary>
        /// <value>
        /// The modified date time.
        /// </value>
        public DateTime ModifiedDateTime { get; set; }


        /// <summary>
        /// Gets or sets the created date time.
        /// </summary>
        /// <value>
        /// The created date time.
        /// </value>
        public DateTime CreatedDateTime { get; set; }
    }
}