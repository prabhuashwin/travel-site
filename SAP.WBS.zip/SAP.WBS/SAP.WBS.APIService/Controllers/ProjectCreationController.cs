﻿using SAP.Business;
using SAP.Business.DTO;
using SAP.DTO;
using SAP.Framework.Exception;
using SAP.Framework.Logging;
using SAP.Framework.Utilities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;

namespace SAP.WBS.APIService.Controllers
{
    public class ProjectCreationController : BaseApiController
    {
        [HttpGet]
        [Route("api/user/CreateWBSID/")]
        public HttpResponseMessage CreateProject([FromBody]ProjectCreationDTO obj)

        {
            try
            {

                string billingInformation = "D9569-C0186-002";
                string projectDefinition = billingInformation.RemoveTextAfterLastChar('-');

                obj = new ProjectCreationDTO();
                obj.UserName = "RFC_GECI";
                obj.Password = "Q174bca$";
                obj.RequestId = 282;
                obj.BillingInformation = billingInformation;
                obj.ProjectDefinition = projectDefinition;
                obj.ProjectName = "Project Net Ele Creation507876";

                #region Add this in WBS Tool

                ///Fetch all the distinct Tasks based on the project name.
                #region FetchingTaskList
                ///Connect to DB and based on Project Name get the Unique Task Description from the Task Table
                ///
                
                SqlConnection connn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString);
                SqlCommand cmd = new SqlCommand("GetSAPProjectTaskWorkCenter", connn);
                cmd.Parameters.AddWithValue("ProjectName", "BAE-HAWK-OHR-D6861-E61YL-0449-101");//Change this to ProjectName at later stage
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet dSet = new DataSet();
                connn.Open();
                cmd.ExecuteNonQuery();                
                adp.Fill(dSet);
                connn.Close();

                //Add a row with Project Name 
                DataRow drProjectName = dSet.Tables[0].NewRow();
                drProjectName["TaskDescription"] = obj.ProjectName;
                drProjectName["WorkCenter"] = "";
                dSet.Tables[0].Rows.Add(drProjectName);
                
                // define the INSERT statement using **PARAMETERS**
                string insertStmt = "INSERT INTO dbo.tbl_SAP_WBSNetwork(RequestId, ProjectDefinition, ChargeCodeDescription, WorkCenter, UpdatedOn) " +
                                    "VALUES(@RequestId, @ProjectDefinition, @ChargeCodeDescription, @WorkCenter, @UpdatedOn)";

                // set up connection and command objects in ADO.NET
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                using (SqlCommand cmdInsrt = new SqlCommand(insertStmt, conn))
                {
                    // define parameters - ReportID is the same for each execution, so set value here
                    cmdInsrt.Parameters.Add("@RequestId", SqlDbType.Int).Value = obj.RequestId;
                    cmdInsrt.Parameters.Add("@ProjectDefinition", SqlDbType.NVarChar);
                    cmdInsrt.Parameters.Add("@ChargeCodeDescription", SqlDbType.NVarChar);
                    cmdInsrt.Parameters.Add("@WorkCenter", SqlDbType.NVarChar);
                    cmdInsrt.Parameters.Add("@UpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                    conn.Open();

                    //// iterate over all Reqeuest Id's and execute the INSERT statement for each of them
                    foreach (DataRow dr in dSet.Tables[0].Rows)
                    {
                        cmdInsrt.Parameters["@ProjectDefinition"].Value = obj.ProjectDefinition;
                        cmdInsrt.Parameters["@ChargeCodeDescription"].Value = dr["TaskDescription"].ToString();
                        cmdInsrt.Parameters["@WorkCenter"].Value = dr["WorkCenter"].ToString();

                        cmdInsrt.ExecuteNonQuery();
                    }
                    conn.Close();
                }

                //string[] Gh = new string[dSet.Tables[0].Rows.Count];
                #endregion
                
                #region Temporary region for Work Centers QUETANJE

                string strWorkCenter = "QUETANJE";
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET WorkCenter='" + strWorkCenter + "' Where RequestId ='" + obj.RequestId + "'";
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
                #endregion
                
                #endregion

                OperationResult operationResult = new OperationResult();
                //Business Logic
                var userInfo = (ProjectCreationDTO)operationResult.Data;

                //operationResult = new ProjectCreationManager().CreateProject(obj.UserName, obj.Password);
                operationResult = new ProjectCreationManager().CreateProject(obj.UserName, obj.Password, obj.RequestId, obj.BillingInformation, obj.ProjectDefinition, obj.ProjectName);

                return this.Request.CreateResponse(HttpStatusCode.OK, operationResult, "text/json");
            }
            catch (SAPException exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return this.Request.CreateResponse(HttpStatusCode.OK, exception.Result, "text/json");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return this.GetExceptionAsJsonResponse(exception);
            }
        }
    }
}