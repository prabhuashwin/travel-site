﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    ProjectCreationController.cs
* File Desc   :    This file contains code pertaining to API for Project Creation Controller.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/


using System;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;
using SAP.Business;
using SAP.Business.DTO;
using SAP.Framework.Exception;
using SAP.Framework.Logging;

namespace SAP.WBS.APIService.Controllers
{
    /// <summary>
    /// API for SAP Project Creation
    /// </summary>
    /// <seealso cref="SAP.WBS.APIService.Controllers.BaseApiController" />
    public class ProjectCreationController : BaseApiController
    {
        /// <summary>
        /// Creates the project.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        [HttpPost]
        [EnableCors("*", "*", "*")]
        [Route("api/user/CreateWBSElement/")]
        public HttpResponseMessage CreateWbsElement([FromBody] ProjectCreationDto obj)
        {
            //if (obj == null)
            //{
            //    operationResult = new OperationResult
            //    {
            //        Success = true,
            //        Message = "No Data Available",
            //        MCode = MessageCode.OperationSuccessful,
            //        Data = "No Data"
            //    };
            //    return Request.CreateResponse(HttpStatusCode.OK, operationResult, "text/json");
            //}

            //const string insertStmt = "INSERT INTO dbo.tbl_SAP_WBSNetwork(RequestId, ProjectDefinition, ChargeCodeDescription, WorkCenter, UpdatedOn) " +
            //                          "VALUES(@RequestId, @ProjectDefinition, @ChargeCodeDescription, @WorkCenter, @UpdatedOn)";
            try
            {
                #region Commented Code

                //obj = new ProjectCreationDto
                //{
                //    UserName = "RFC_GECI",
                //    Password = "Q174bca$",
                //    RequestId = 338,
                //    BillingInformation = billingInformation,
                //    ProjectDefinition = projectDefinition,
                //    ProjectName = "Project Net Ele Creation 338"
                //};

                //#region Add this in WBS Tool

                /////Fetch all the distinct Tasks based on the project name.

                //#region FetchingTaskList

                /////Connect to DB and based on Project Name get the Unique Task Description from the Task Table
                /////

                //var sqlconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString);
                //var cmd = new SqlCommand("GetSAPProjectTaskWorkCenter", sqlconnection);
                //cmd.Parameters.AddWithValue("ProjectName", obj.ProjectName); //Change this to ProjectName at later stage
                //cmd.CommandType = CommandType.StoredProcedure;
                //var adp = new SqlDataAdapter(cmd);
                //var dSet = new DataSet();
                //sqlconnection.Open();
                //cmd.ExecuteNonQuery();
                //adp.Fill(dSet);
                //sqlconnection.Close();

                ////Add a row with Project Name 
                //var drProjectName = dSet.Tables[0].NewRow();
                //drProjectName["TaskDescription"] = obj.ProjectName;
                //drProjectName["WorkCenter"] = "";
                //dSet.Tables[0].Rows.Add(drProjectName);

                //// define the INSERT statement using **PARAMETERS**
                //// set up connection and command objects in ADO.NET
                //using (var conn =
                //    new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                //using (var commandInsert = new SqlCommand(insertStmt, conn))
                //{
                //    // define parameters - ReportID is the same for each execution, so set value here
                //    commandInsert.Parameters.Add("@RequestId", SqlDbType.Int).Value = obj.RequestId;
                //    commandInsert.Parameters.Add("@ProjectDefinition", SqlDbType.NVarChar);
                //    commandInsert.Parameters.Add("@ChargeCodeDescription", SqlDbType.NVarChar);
                //    commandInsert.Parameters.Add("@WorkCenter", SqlDbType.NVarChar);
                //    commandInsert.Parameters.Add("@UpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                //    conn.Open();

                //    //// iterate over all Reqeuest Id's and execute the INSERT statement for each of them
                //    foreach (DataRow dr in dSet.Tables[0].Rows)
                //    {
                //        commandInsert.Parameters["@ProjectDefinition"].Value = obj.ProjectDefinition;
                //        commandInsert.Parameters["@ChargeCodeDescription"].Value = dr["TaskDescription"].ToString();
                //        commandInsert.Parameters["@WorkCenter"].Value = dr["WorkCenter"].ToString();

                //        commandInsert.ExecuteNonQuery();
                //    }

                //    conn.Close();
                //}

                ////string[] Gh = new string[dSet.Tables[0].Rows.Count];

                //#endregion

                //#region Temporary region for Work Centers QUETANJE

                //const string strWorkCenter = "QUETANJE";
                //using (var connection =
                //    new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                //using (var command = connection.CreateCommand())
                //{
                //    command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET WorkCenter='" + strWorkCenter +
                //                          "' Where RequestId ='" + obj.RequestId + "'";
                //    connection.Open();
                //    command.ExecuteNonQuery();
                //    connection.Close();
                //}

                //#endregion

                //#endregion

                //Business Logic
                //operationResult = new ProjectCreationManager().CreateProject(obj.UserName, obj.Password);

                #endregion

                //DateTime date = DateTime.ParseExact(obj.ProjectStartDate.ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
                var operationResult = new ProjectCreationManager().CreateWbsId(obj.UserName, obj.Password, obj.RequestId,
                    obj.BillingInformation, obj.ProjectDefinition, obj.ProjectName);

                //operationResult = new ProjectCreationManager().CreateWBSId(CreationObject.UserName, CreationObject.Password, CreationObject.RequestId,
                //    CreationObject.BillingInformation, CreationObject.ProjectDefinition, CreationObject.ProjectName);

                return Request.CreateResponse(HttpStatusCode.OK, operationResult, "text/json");
            }
            catch (SapException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return Request.CreateResponse(HttpStatusCode.OK, exception.Result, "text/json");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return GetExceptionAsJsonResponse(exception);
            }
        }

        /// <summary>
        /// Creates the network identifier.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        [HttpPost]
        [EnableCors("*", "*", "*")]
        [Route("api/user/CreateNetworkElement/")]
        public HttpResponseMessage CreateNetworkId([FromBody] ProjectCreationDto obj)
        {
           
            try
            {
                //const string billingInformation = "D9569-C0186-002";
                //var projectDefinition = billingInformation.RemoveTextAfterLastChar('-');

                //Business Logic
                //operationResult = new ProjectCreationManager().CreateProject(obj.UserName, obj.Password);

                var operationResult = new ProjectCreationManager().CreateNetworkId(obj.UserName, obj.Password,
                    obj.RequestId,
                    obj.ProjectDefinition, obj.ProjectName, obj.WbsElement, obj.ProjectStartDate, obj.ProjectEndDate);

                //operationResult = new ProjectCreationManager().CreateNetworkId(CreationObject.UserName, CreationObject.Password, CreationObject.RequestId,
                //    CreationObject.ProjectDefinition, CreationObject.ProjectName, GlobalVariables.WBSElement);

                return Request.CreateResponse(HttpStatusCode.OK, operationResult, "text/json");
            }
            catch (SapException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return Request.CreateResponse(HttpStatusCode.OK, exception.Result, "text/json");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return GetExceptionAsJsonResponse(exception);
            }
        }

        /// <summary>
        /// Creates the network activity.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns></returns>
        [HttpPost]
        [EnableCors("*", "*", "*")]
        [Route("api/user/CreateNetworkActivity/")]
        public HttpResponseMessage CreateNetworkActivity([FromBody] ProjectCreationDto obj)
        {
            try
            {
                //const string billingInformation = "D9569-C0186-002";
                //var projectDefinition = billingInformation.RemoveTextAfterLastChar('-');

                //Business Logic
                //operationResult = new ProjectCreationManager().CreateProject(obj.UserName, obj.Password);

                var operationResult = new ProjectCreationManager().CreateNetworkActivity(obj.UserName, obj.Password,
                    obj.RequestId,
                    obj.ProjectDefinition, obj.ProjectName, obj.WbsElement, obj.NetworkId);

                //operationResult = new ProjectCreationManager().CreateNetworkActivity(CreationObject.UserName, CreationObject.Password, CreationObject.RequestId,
                //    CreationObject.ProjectDefinition, CreationObject.ProjectName, GlobalVariables.WBSElement, GlobalVariables.NetworkId);

                return Request.CreateResponse(HttpStatusCode.OK, operationResult, "text/json");
            }
            catch (SapException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return Request.CreateResponse(HttpStatusCode.OK, exception.Result, "text/json");
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return GetExceptionAsJsonResponse(exception);
            }
        }
    }
}