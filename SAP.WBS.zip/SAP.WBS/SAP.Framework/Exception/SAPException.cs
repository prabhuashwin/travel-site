﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    SapException.cs
* File Desc   :    This file contains code pertaining to class for SapException.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using SAP.DTO;

namespace SAP.Framework.Exception
{
    /// <summary />
    /// <seealso cref="System.Exception" />
    public class SapException : System.Exception
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="SapException" /> class.
        /// </summary>
        public SapException()
        {
            Result = new OperationResult();
        }
        
        /// <summary>
        ///     Initializes a new instance of the <see cref="SapException" /> class.
        /// </summary>
        /// <param name="code">The code.</param>
        /// <param name="message">The message.</param>
        public SapException(MessageCode code, string message)
            : base(message)
        {
            Result = new OperationResult {Success = false, MCode = code, Message = message};
        }
        
        /// <summary>
        ///     Gets or sets the result.
        /// </summary>
        /// <value>
        ///     The result.
        /// </value>
        public OperationResult Result { get; set; }
    }
}