﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAP.Framework.Constants
{
    public class SAPConstants
    {
        /// <summary>
        /// Gets or sets the GenericGaurdMsg.
        /// </summary>
        /// <value>
        /// The GenericGaurdMsg.
        /// </value>
        public const string GenericGaurdMsg = "{0}: Please provide proper value.";
                
        /// <summary>
        /// The push notification token separator
        /// </summary>
        public const string PushNotTokenSeperator = "PushNotTokenSeperator";

        public const string MsgForUserRegistration = "Your registration was a success";

        public const string COSTING_SHEET = "Z97700";

        public const string PLANT = "2930";

        public const string ACC_ASSIGNMENT = "X";

        public const string RESP_COSTCENTER = "9569P00004";//Need to check with Thiru

        public const string CONTROLLING_AREA = "9500";

        public const int LEVEL_ONE = 1;

        public const int LEVEL_TWO = 2;

        public const string PARENT_LEVEL_ONE = "1";
    }
}
