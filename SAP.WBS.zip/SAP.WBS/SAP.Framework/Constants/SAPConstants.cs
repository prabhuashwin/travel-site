﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    SapConstants.cs
* File Desc   :    This file contains code pertaining to class for Constants.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

namespace SAP.Framework.Constants
{
    /// <summary>
    /// 
    /// </summary>
    public class SapConstants
    {
        /// <summary>
        /// The MSG for user registration
        /// </summary>
        public const string MsgForUserRegistration = "Your registration was a success";


        /// <summary>
        /// The costing sheet
        /// </summary>
        public const string CostingSheet = "Z97700";


        /// <summary>
        /// The plant
        /// </summary>
        public const string Plant = "2930";


        /// <summary>
        /// The acc assignment
        /// </summary>
        public const string AccAssignment = "X";


        /// <summary>
        /// The resp costcenter
        /// </summary>
        public const string RespCostcenter = "9569P00004"; //Need to check with Thiru


        /// <summary>
        /// The controlling area
        /// </summary>
        public const string ControllingArea = "9500";


        /// <summary>
        /// The level one
        /// </summary>
        public const int LevelOne = 1;


        /// <summary>
        /// The level two
        /// </summary>
        public const int LevelTwo = 2;


        /// <summary>
        /// The parent level one
        /// </summary>
        public const string ParentLevelOne = "1";


        /// <summary>
        /// The project type
        /// </summary>
        public const string ProjectType = "G1";//GLOBAL CONTRACT R&D


        /// <summary>
        /// The priority
        /// </summary>
        public const string Priority = "E";//Experimental Revenue and Cost of Sales
    }
}