﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    LoggingCategory.cs
* File Desc   :    This file contains code pertaining to enumeration for Logging Category.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

namespace SAP.Framework.Logging
{
    /// <summary>
    /// 
    /// </summary>
    public enum LoggingCategory
    {
        /// <summary>
        /// Error Category.
        /// </summary>
        Error,

        /// <summary>
        /// Event Category.
        /// </summary>
        Event,

        /// <summary>
        /// The performance parameter logger.
        /// </summary>
        PerformanceParam
    }
}