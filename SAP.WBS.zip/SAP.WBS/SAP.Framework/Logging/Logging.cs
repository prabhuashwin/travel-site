﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    Logging.cs
* File Desc   :    This file contains code pertaining to class for Logging.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Collections.Generic;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Logging;

namespace SAP.Framework.Logging
{
    /// <summary>
    /// 
    /// </summary>
    public class Logging
    {
        /// <summary>
        /// Static LogWriter for defaultWriter.
        /// </summary>
        private static readonly LogWriter DefaultWriter = EnterpriseLibraryContainer.Current.GetInstance<LogWriter>();

        /// <summary>
        /// Logs a new log entry with a specific category, priority, event Id, and severity title. If the LogCategory is
        /// "Event", it logs into Event.log else it logs into Error.log.
        /// </summary>
        /// <param name="logEntry">The log entry.</param>
        public static void DoLog(LogEntry logEntry)
        {
            if (DefaultWriter.IsLoggingEnabled())
            {
                var properties = new Dictionary<string, object>();
                if (!string.IsNullOrEmpty(logEntry.MethodName) || !string.IsNullOrEmpty(logEntry.ClassName))
                    properties.Add(logEntry.MethodName, logEntry.ClassName);

                var logEntity = new Microsoft.Practices.EnterpriseLibrary.Logging.LogEntry
                {
                    Categories = new[] {logEntry.LogCategory.ToString()},
                    Message = logEntry.MessageDetails,
                    Priority = (int) logEntry.LogPriority,
                    Severity = logEntry.LogEventType,
                    TimeStamp = DateTime.Now,
                    ExtendedProperties = properties
                };
                DefaultWriter.Write(logEntity);
            }
        }
    }
}