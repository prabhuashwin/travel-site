﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    LogEntry.cs
* File Desc   :    This file contains code pertaining to class for LogEntry.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System.Diagnostics;

namespace SAP.Framework.Logging
{
    /// <summary>
    /// 
    /// </summary>
    public class LogEntry
    {
        /// <summary>
        /// Gets or sets the message details.
        /// </summary>
        /// <value>
        /// The message details.
        /// </value>
        public string MessageDetails { get; set; }

        /// <summary>
        /// Gets or sets the log category.
        /// </summary>
        /// <value>
        /// The log category.
        /// </value>
        public LoggingCategory LogCategory { get; set; }

        /// <summary>
        /// Gets or sets the network identifier.
        /// </summary>
        /// <value>
        /// The network identifier.
        /// </value>
        public int NetworkId { get; set; }

        /// <summary>
        /// Gets or sets the log priority.
        /// </summary>
        /// <value>
        /// The log priority.
        /// </value>
        public LogPriorityId LogPriority { get; set; }

        /// <summary>
        /// Gets or sets the type of the log event.
        /// </summary>
        /// <value>
        /// The type of the log event.
        /// </value>
        public TraceEventType LogEventType { get; set; }

        /// <summary>
        /// Gets or sets the name of the method.
        /// </summary>
        /// <value>
        /// The name of the method.
        /// </value>
        public string MethodName { get; set; }

        /// <summary>
        /// Gets or sets the name of the class.
        /// </summary>
        /// <value>
        /// The name of the class.
        /// </value>
        public string ClassName { get; set; }
    }
}