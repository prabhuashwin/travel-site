﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    StringExtensions.cs
* File Desc   :    This file contains code pertaining to String Extensions.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Globalization;

namespace SAP.Framework.Utilities
{
    /// <summary>
    /// 
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// Removes the text after last character.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <param name="c">The c.</param>
        /// <returns></returns>
        public static string RemoveTextAfterLastChar(this string text, char c)
        {
            int lastIndexOfSeparator;

            if (!string.IsNullOrEmpty(text) &&
                (lastIndexOfSeparator = text.LastIndexOf(c)) > -1)
                return text.Remove(lastIndexOfSeparator);
            return text;
        }

        public static void ParseStringToDate(string date, out DateTime responseDate)
        {
            string[] dateformats = new string[] { "yyyyMMdd", "yyyy/MM/dd", "yyyy-MM-dd", "M/dd/yy" };
            if (!DateTime.TryParseExact(date, dateformats, CultureInfo.InvariantCulture, DateTimeStyles.None, out responseDate))
            {
                throw new FormatException("El formato de la fecha  no es válido");
            }
        }
    }
}