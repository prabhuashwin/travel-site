﻿using SAP.Framework.Logging;
using SAP.WSDLService.SAPWSDLReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using SAP.Framework.Constants;
using SAP.WSDLService.SAPWSDLReferenceNetwork;

namespace SAP.WSDLService
{
    public class SAPService
    {
        private Z_FI_RFC_WBS_UTIL Client;
        private SAPWSDLReference.Z_FI_RFC_WBS_UTIL1 ClientRequest;
        private SAPWSDLReference.Z_FI_RFC_WBS_UTILResponse ClientResponse;
        public string ParentWBSElement;
        public string NetworkElement;


        private Z_FI_RFC_NW_UTIL NetorkClient;
        private ZFiRfcNwUtil NetworkRequest;
        private ZFiRfcNwUtilResponse NetworkResponse;

        private Z_FI_RFC_NW_UTIL NetorkClientTasks;
        private ZFiRfcNwUtil NetworkRequestTasks;
        private ZFiRfcNwUtilResponse NetworkResponseTasks;

        public SAPService()
        {
            try
            {
                Client = new Z_FI_RFC_WBS_UTIL();
                ClientRequest = new SAPWSDLReference.Z_FI_RFC_WBS_UTIL1();
                ClientResponse = new SAPWSDLReference.Z_FI_RFC_WBS_UTILResponse();

                NetorkClient = new Z_FI_RFC_NW_UTIL();
                NetworkRequest = new ZFiRfcNwUtil();
                NetworkResponse = new ZFiRfcNwUtilResponse();

                NetorkClientTasks = new Z_FI_RFC_NW_UTIL();
                NetworkRequestTasks = new ZFiRfcNwUtil();
                NetworkResponseTasks = new ZFiRfcNwUtilResponse();
            }
            catch (Exception ex)
            {

            }
        }
        
        public void ConnectToSAPWBSID(string User_Name, string Password)
        {
            //Validate the credentials
            Client.PreAuthenticate = true;
            Client.Credentials = new NetworkCredential(User_Name, Password);
        }

        public void ConnectToSAPNetwork(string User_Name, string Password)
        {
            //Validate the credentials
            NetorkClient.PreAuthenticate = true;
            NetorkClient.Credentials = new NetworkCredential(User_Name, Password);
        }

        public void ConnectToSAPNetworkForActivityCreation(string User_Name, string Password)
        {
            //Validate the credentials
            NetorkClientTasks.PreAuthenticate = true;
            NetorkClientTasks.Credentials = new NetworkCredential(User_Name, Password);
        }

        public object CreateProject(string User_Name, string Password, long RequestId, string BillingInformation, string ProjectDefinition, string ProjectName)
        {
            try
            {
                //Connect to SAP for WBS ID Service 
                ConnectToSAPWBSID(User_Name, Password);

                //Response from first web request
                ClientRequest = CreateRequest(BillingInformation, ProjectDefinition, ProjectName);
                ClientResponse = Client.CallZ_FI_RFC_WBS_UTIL(ClientRequest);

                //Need to add WBSID's to the DB in a temporary table
                if (ClientResponse.P_MSGS[0].MESSAGE_TYPE != "E")
                {
                    using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    using (SqlCommand command = connection.CreateCommand())
                    {

                        foreach (ZPS_WBS_ELEMENT data in ClientResponse.P_WBS)
                        {
                            command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET ChargeCode='" + data.WBS + "' Where ChargeCodeDescription ='" + data.DESC + "'";
                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }

                    }

                    ParentWBSElement = ClientResponse.P_WBS[0].WBS;

                    #region Commented Code
                    //connection.Close();

                    //// define the INSERT statement using **PARAMETERS**
                    //string insertStmt = "INSERT INTO dbo.tbl_SAP_WBSNetwork(RequestId, ChargeCode, ChargeCodeDescription, WorkCenter,ProjectDefinition,NetworkId,UpdatedOn) " +
                    //                    "VALUES(@RequestId, @ChargeCode,@ChargeCodeDescription,@WorkCenter,@ProjectDefinition,@NetworkId, @UpdatedOn)";

                    //// set up connection and command objects in ADO.NET
                    //using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    //using (SqlCommand cmd = new SqlCommand(insertStmt, conn))
                    //{
                    //    // define parameters - ReportID is the same for each execution, so set value here
                    //    cmd.Parameters.Add("@RequestId", SqlDbType.Int).Value = RequestId;
                    //    cmd.Parameters.Add("@ProjectDefinition", SqlDbType.NVarChar);
                    //    cmd.Parameters.Add("@ChargeCode", SqlDbType.NVarChar);
                    //    cmd.Parameters.Add("@ChargeCodeDescription", SqlDbType.NVarChar);
                    //    cmd.Parameters.Add("@WorkCenter", SqlDbType.NVarChar);
                    //    cmd.Parameters.Add("@NetworkId", SqlDbType.NVarChar);
                    //    cmd.Parameters.Add("@UpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                    //    conn.Open();

                    //    //// iterate over all Reqeuest Id's and execute the INSERT statement for each of them
                    //    foreach (ZPS_WBS_ELEMENT data in ClientResponse.P_WBS)
                    //    {
                    //        cmd.Parameters["@ProjectDefinition"].Value = data.PROJECT;
                    //        cmd.Parameters["@ChargeCode"].Value = data.WBS;
                    //        cmd.Parameters["@ChargeCodeDescription"].Value = data.DESC;
                    //        cmd.Parameters["@WorkCenter"].Value = "";
                    //        cmd.Parameters["@NetworkId"].Value = "";

                    //        cmd.ExecuteNonQuery();
                    //    }

                    //    ParentWBSElement = ClientResponse.P_WBS[0].WBS;

                    //    conn.Close();
                    //}

                    #endregion

                    //Need to call second service by passing the WBS ID along with Tasks for creating the network
                    //Connect to SAP for WBS ID Service 
                    ConnectToSAPNetwork(User_Name, Password);

                    //Create Network
                    NetworkRequest = CreateNetworkRequest(ParentWBSElement, ProjectDefinition, ProjectName);
                    NetworkResponse = NetorkClient.ZFiRfcNwUtil(NetworkRequest);

                    NetworkElement = NetworkResponse.PNetworks[0].Order;

                    //Update Network ID in DB based on Request ID

                    using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET NetworkId='" + NetworkElement + "' Where RequestId ='" + RequestId + "'";
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }


                    ConnectToSAPNetworkForActivityCreation(User_Name, Password);
                    //Creater Network tasks
                    NetworkRequestTasks = CreateNetworkRequestTasks(NetworkElement);
                    NetworkResponseTasks = NetorkClientTasks.ZFiRfcNwUtil(NetworkRequestTasks);

                    using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    using (SqlCommand command = connection.CreateCommand())
                    {

                        foreach (ZpsNwActivity data in NetworkResponseTasks.PNwActivity)
                        {
                            command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET ActivityNumber='" + data.Activity + "' Where ChargeCodeDescription ='" + data.OperationShortText + "' and WorkCenter ='" + data.WorkCenter + "' and ChargeCode ='" + data.Wbs + "'";
                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }

                    }
                }

                return ClientResponse;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        private ZFiRfcNwUtil CreateNetworkRequestTasks(string networkElement)
        {
            ZFiRfcNwUtil networkReq = new ZFiRfcNwUtil();

            ZpsNetworks[] networkArray = new ZpsNetworks[1];
            MethMessage[] pMessageField = new MethMessage[1];
            ZpsNwActivity[] pNwActivityField = new ZpsNwActivity[1];
            ZpsNetworkStatus[] pNwStatusField = new ZpsNetworkStatus[1];


            #region FetchingNetworkListTasks
            SqlConnection connn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString);
            connn.Open();

            SqlCommand cmd = new SqlCommand("GetSAPWBSNetworkTasks", connn);
            cmd.Parameters.AddWithValue("NetworkID", networkElement);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet dSet = new DataSet();

            cmd.ExecuteNonQuery();
            adp.Fill(dSet);


            pNwActivityField = new ZpsNwActivity[dSet.Tables[0].Rows.Count];

            //Looping through the dataset to insert Tasks into the array
            foreach (var table in dSet.Tables)
            {
                int i = 0;
                int j = 0;
                foreach (DataRow row in dSet.Tables[0].Rows)
                {
                    //Adding values to the wbarray
                    ZpsNwActivity nwActivity = new ZpsNwActivity();

                    nwActivity.Order = row["NetworkId"].ToString();
                    nwActivity.Activity = "";
                    nwActivity.ControlKey = "PS01";
                    nwActivity.WorkCenter = row["WorkCenter"].ToString();
                    nwActivity.Plant = SAPConstants.PLANT;
                    nwActivity.OperationShortText = row["ChargeCodeDescription"].ToString();
                    nwActivity.ActivityType = "EXP";
                    nwActivity.Wbs = row["ChargeCode"].ToString();

                    pNwActivityField[j] = nwActivity;

                    i++;
                    j++;
                }
            }

            networkReq.PNetworks = networkArray;
            networkReq.PMsgs = pMessageField;
            networkReq.PNwActivity = pNwActivityField;
            networkReq.PNwStatus = pNwStatusField;

            return networkReq;


            #endregion

        }

        //public static SAPWSDLReference.Z_FI_RFC_WBS_UTIL1 CreateRequest()
        //{
        //    SAPWSDLReference.Z_FI_RFC_WBS_UTIL1 clientReq = new SAPWSDLReference.Z_FI_RFC_WBS_UTIL1();

        //    BAPI_WBS_HIERARCHIE hierarchy = new BAPI_WBS_HIERARCHIE();
        //    BAPI_WBS_HIERARCHIE[] hierarchyArry = new BAPI_WBS_HIERARCHIE[1];

        //    BAPI_WBS_MNT_SYSTEM_STATUS pstatus = new BAPI_WBS_MNT_SYSTEM_STATUS();
        //    BAPI_WBS_MNT_SYSTEM_STATUS[] pstatusArry = new BAPI_WBS_MNT_SYSTEM_STATUS[1];

        //    BAPI_WBS_MNT_USER_STATUS ustatus = new BAPI_WBS_MNT_USER_STATUS();
        //    BAPI_WBS_MNT_USER_STATUS[] ustatusArry = new BAPI_WBS_MNT_USER_STATUS[1];

        //    BAPI_METH_MESSAGE mssg = new BAPI_METH_MESSAGE();
        //    BAPI_METH_MESSAGE[] mssgArry = new BAPI_METH_MESSAGE[1];

        //    ///Connect to DB and based on Project Name get the Unique Task Description from the Task Table

        //    ZPS_WBS_ELEMENT wbs = new ZPS_WBS_ELEMENT();

        //    wbs.LEVEL = 1;
        //    wbs.PARENT = "D9569-C0186-001";
        //    wbs.PROJECT = "D9569-C0186";
        //    wbs.DESC = "B/E Migration Project Test 180";
        //    wbs.COSTING_SHEET = "Z97700";
        //    wbs.PLANT = "2930";
        //    wbs.ACC_ASSIGNMENT = "X";
        //    wbs.RESP_COSTCENTER = "9569P00004";//need to get correct cost center and controlling area
        //    wbs.CONTRLLING_AREA = "9500";

        //    ZPS_WBS_ELEMENT[] wbsarray;
        //    wbsarray = new ZPS_WBS_ELEMENT[1];
        //    wbsarray[0] = wbs;
        //    clientReq.P_WBS = wbsarray;
        //    clientReq.P_HIERARCHY = hierarchyArry;
        //    clientReq.P_SYS_STATUS = pstatusArry;
        //    clientReq.P_USR_STATUS = ustatusArry;
        //    clientReq.P_MSGS = mssgArry;

        //    return clientReq;
        //}

        public static SAPWSDLReference.Z_FI_RFC_WBS_UTIL1 CreateRequest(string BillingInformation, string ProjectDefinition, string ProjectName)
        {
            SAPWSDLReference.Z_FI_RFC_WBS_UTIL1 clientReq = new SAPWSDLReference.Z_FI_RFC_WBS_UTIL1();

            BAPI_WBS_HIERARCHIE hierarchy = new BAPI_WBS_HIERARCHIE();
            BAPI_WBS_HIERARCHIE[] hierarchyArry = new BAPI_WBS_HIERARCHIE[1];

            BAPI_WBS_MNT_SYSTEM_STATUS pstatus = new BAPI_WBS_MNT_SYSTEM_STATUS();
            BAPI_WBS_MNT_SYSTEM_STATUS[] pstatusArry = new BAPI_WBS_MNT_SYSTEM_STATUS[1];

            BAPI_WBS_MNT_USER_STATUS ustatus = new BAPI_WBS_MNT_USER_STATUS();
            BAPI_WBS_MNT_USER_STATUS[] ustatusArry = new BAPI_WBS_MNT_USER_STATUS[1];

            BAPI_METH_MESSAGE mssg = new BAPI_METH_MESSAGE();
            BAPI_METH_MESSAGE[] mssgArry = new BAPI_METH_MESSAGE[1];


            ZPS_WBS_ELEMENT wbs = new ZPS_WBS_ELEMENT();
            ZPS_WBS_ELEMENT[] wbsarray;

            //Parent Element Details
            wbs.LEVEL = SAPConstants.LEVEL_ONE;//Static Data
            wbs.PARENT = BillingInformation;////Needs to come from DB
            wbs.PROJECT = ProjectDefinition;////Needs to come from DB
            wbs.DESC = ProjectName;//Needs to come from DB
            wbs.COSTING_SHEET = SAPConstants.COSTING_SHEET;//Static Data
            wbs.PLANT = SAPConstants.PLANT;//Static Data
            wbs.ACC_ASSIGNMENT = SAPConstants.ACC_ASSIGNMENT;//Static Data
            //wbs.RESP_COSTCENTER = SAPConstants.RESP_COSTCENTER;//need to get correct cost center and controlling area - Static Data
            //wbs.CONTRLLING_AREA = SAPConstants.CONTROLLING_AREA;//Static Data

            ////Task-1 Details
            //wbs.LEVEL = 2;
            //wbs.PARENT = "1";
            //wbs.PROJECT = "D9569-C0186";
            //wbs.DESC = "Task1";
            //wbs.COSTING_SHEET = "";
            //wbs.PLANT = "";
            //wbs.ACC_ASSIGNMENT = "";
            //wbs.RESP_COSTCENTER = "";//need to get correct cost center and controlling area
            //wbs.CONTRLLING_AREA = "";

            ///Fetch all the distinct Tasks based on the project name.
            #region FetchingTaskList
            ///Connect to DB and based on Project Name get the Unique Task Description from the Task Table
            ///
            SqlConnection connn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString);
            connn.Open();

            SqlCommand cmd = new SqlCommand("GetSAPDistinctProjectTasks", connn);
            cmd.Parameters.AddWithValue("ProjectName", "BAE-HAWK-OHR-D6861-E61YL-0449-101");//Change this to ProjectName at later stage
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet dSet = new DataSet();

            cmd.ExecuteNonQuery();
            adp.Fill(dSet);

            //string[] Gh = new string[dSet.Tables[0].Rows.Count];
            #endregion

            wbsarray = new ZPS_WBS_ELEMENT[dSet.Tables[0].Rows.Count + 1];

            ///Assigning the parent element data to the wbarray
            wbsarray[0] = wbs;

            //Looping through the dataset to insert Tasks into the array
            foreach (var table in dSet.Tables)
            {
                int i = 0;
                int j = 1;
                foreach (DataRow row in dSet.Tables[0].Rows)
                {
                    //Adding values to the wbarray
                    ZPS_WBS_ELEMENT wbs1 = new ZPS_WBS_ELEMENT();

                    wbs1.LEVEL = SAPConstants.LEVEL_TWO;
                    wbs1.PARENT = SAPConstants.PARENT_LEVEL_ONE;
                    wbs1.PROJECT = ProjectDefinition;
                    wbs1.DESC = row["TaskDescription"].ToString();
                    wbs1.COSTING_SHEET = SAPConstants.COSTING_SHEET;
                    wbs1.PLANT = SAPConstants.PLANT;
                    wbs1.ACC_ASSIGNMENT = SAPConstants.ACC_ASSIGNMENT;
                    //wbs1.RESP_COSTCENTER = "";//need to get correct cost center and controlling area
                    //wbs1.CONTRLLING_AREA = "";

                    wbsarray[j] = wbs1;

                    i++;
                    j++;
                }
            }

            clientReq.P_WBS = wbsarray;
            clientReq.P_HIERARCHY = hierarchyArry;
            clientReq.P_SYS_STATUS = pstatusArry;
            clientReq.P_USR_STATUS = ustatusArry;
            clientReq.P_MSGS = mssgArry;


            return clientReq;
        }

        public static ZFiRfcNwUtil CreateNetworkRequest(string WBSElement, string ProjectDefinition, string ProjectName)
        {
            ZFiRfcNwUtil networkReq = new ZFiRfcNwUtil();

            MethMessage[] pMessageField = new MethMessage[1];


            ZpsNwActivity[] pNwActivityField = new ZpsNwActivity[1];
            ZpsNetworkStatus[] pNwStatusField = new ZpsNetworkStatus[1];

            ///Connect to DB and based on Project Name get the Unique Task Description from the Task Table

            ZpsNetworks networkItem = new ZpsNetworks();
            networkItem.Order = "";
            networkItem.OrderType = "ZS02";
            networkItem.ShortText = ProjectName;
            networkItem.Plant = "2930";
            networkItem.WbsElement = WBSElement;
            networkItem.ProjectDefinition = ProjectDefinition;
            networkItem.MrpController = "G99";
            networkItem.SchedulingType = "2";

            ZpsNetworks[] networkArray;
            networkArray = new ZpsNetworks[1];
            networkArray[0] = networkItem;
            networkReq.PNetworks = networkArray;
            networkReq.PMsgs = pMessageField;
            networkReq.PNwActivity = pNwActivityField;
            networkReq.PNwStatus = pNwStatusField;

            return networkReq;
        }
    }
}
