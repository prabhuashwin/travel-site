﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAP.DTO
{
    public static class GlobalVariables
    {
        public static string WBSElement { get; set; }

        public static string NetworkId { get; set; }
    }

    public static class CreationObject
    {
        /// <summary>
        /// Gets or sets the name of the user.
        /// </summary>
        /// <value>
        /// The name of the user.
        /// </value>
        public static string UserName { get; set; }

        /// <summary>
        /// Gets or sets the password.
        /// </summary>
        /// <value>
        /// The password.
        /// </value>
        public static string Password { get; set; }

        /// <summary>
        /// Gets or sets the request identifier.
        /// </summary>
        /// <value>
        /// The request identifier.
        /// </value>
        public static long RequestId { get; set; }

        /// <summary>
        /// Gets or sets the billing information.
        /// </summary>
        /// <value>
        /// The billing information.
        /// </value>
        public static string BillingInformation { get; set; }

        /// <summary>
        /// Gets or sets the project definition.
        /// </summary>
        /// <value>
        /// The project definition.
        /// </value>
        public static string ProjectDefinition { get; set; }

        /// <summary>
        /// Gets or sets the name of the project.
        /// </summary>
        /// <value>
        /// The name of the project.
        /// </value>
        public static string ProjectName { get; set; }
    }
}
