﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UserType.cs
* File Desc   :    This file contains code pertaining to enum for User Type.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

namespace SAP.DTO
{
    /// <summary>
    /// 
    /// </summary>
    public enum UserType
    {
        /// <summary>
        /// Customer Types
        /// </summary>
        Customer = 1,

        /// <summary>
        /// Administrator Types
        /// </summary>
        Administrator = 2,

        /// <summary>
        /// Administrator Types
        /// </summary>
        Anonymous = 3
    }
}