﻿using SAP.DTO;
using SAP.Framework.Exception;
using SAP.Framework.Logging;
using SAP.WSDLService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace SAP.Business
{
    public class ProjectCreationManager
    {
        public OperationResult CreateProject(string User_Name, string Password, long RequestId, string BillingInformation, string ProjectDefinition, string ProjectName)
        {
            try
            {
                var isResult = new SAPService().CreateProject(User_Name, Password, RequestId, BillingInformation, ProjectDefinition, ProjectName);

                return new OperationResult()
                {
                    Success = true,
                    Message = "Project Created successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = isResult
                };
            }
            catch (SAPException exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

    }
}
