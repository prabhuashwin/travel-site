﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    ProjectCreationManager.cs
* File Desc   :    This file contains code pertaining to Project Creation Manager.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 14-Sep-2019        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Reflection;
using SAP.DTO;
using SAP.Framework.Exception;
using SAP.Framework.Logging;
using SAP.WSDLService;

namespace SAP.Business
{
    /// <summary>
    /// Class for Create Project
    /// </summary>
    public class ProjectCreationManager
    {
        /// <summary>
        /// Creates the project.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="billingInformation">The billing information.</param>
        /// <param name="projectDefinition">The project definition.</param>
        /// <param name="projectName">Name of the project.</param>
        /// <returns></returns>
        public OperationResult CreateWbsId(string userName, string password, long requestId, string billingInformation,
            string projectDefinition, string projectName)
        {
            try
            {
                var isResult = new SapService().CreateWbsId(userName, password, requestId, billingInformation,
                    projectDefinition, projectName);

                return new OperationResult
                {
                    Success = true,
                    Message = isResult.ToString(),
                    MCode = MessageCode.OperationSuccessful,
                    Data = isResult
                };
            }
            catch (SapException exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// Creates the network identifier.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="projectDefinition">The project definition.</param>
        /// <param name="projectName">Name of the project.</param>
        /// <param name="wbsElement">The WBS element.</param>
        /// <param name="projectStartDate">The project start date.</param>
        /// <param name="projectEndDate">The project end date.</param>
        /// <returns></returns>
        public OperationResult CreateNetworkId(string userName, string password, long requestId,
            string projectDefinition, string projectName, string wbsElement, DateTime projectStartDate,
            DateTime projectEndDate)
        {
            try
            {
                var isResult = new SapService().CreateNetworkId(userName, password, requestId, projectDefinition,
                    projectName, wbsElement, projectStartDate, projectEndDate);

                return new OperationResult
                {
                    Success = true,
                    Message = isResult.ToString(),
                    MCode = MessageCode.OperationSuccessful,
                    Data = isResult
                };
            }
            catch (SapException exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        /// Creates the network activity.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="projectDefinition">The project definition.</param>
        /// <param name="projectName">Name of the project.</param>
        /// <param name="wbsElement">The WBS element.</param>
        /// <param name="networkId">The network identifier.</param>
        /// <returns></returns>
        public OperationResult CreateNetworkActivity(string userName, string password, long requestId,
            string projectDefinition, string projectName, string wbsElement, string networkId)
        {
            try
            {
                var isResult = new SapService().CreateNetworkActivity(userName, password, requestId, projectDefinition,
                    projectName, wbsElement, networkId);

                return new OperationResult
                {
                    Success = true,
                    Message = isResult.ToString(),
                    MCode = MessageCode.OperationSuccessful,
                    Data = isResult
                };
            }
            catch (SapException exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType?.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}