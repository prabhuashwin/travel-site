﻿namespace SAP.Framework.Constants
{
    /// <summary>
    /// 
    /// </summary>
    public class SapConstants
    {
        /// <summary>
        /// Gets or sets the GenericGaurdMsg.
        /// </summary>
        /// <value>
        /// The GenericGaurdMsg.
        /// </value>
        public const string GenericGaurdMsg = "{0}: Please provide proper value.";

        /// <summary>
        /// The push notification token separator
        /// </summary>
        public const string PushNotTokenSeperator = "PushNotTokenSeperator";

        /// <summary>
        /// The MSG for user registration
        /// </summary>
        public const string MsgForUserRegistration = "Your registration was a success";

        /// <summary>
        /// The costing sheet
        /// </summary>
        public const string CostingSheet = "Z97700";

        /// <summary>
        /// The plant
        /// </summary>
        public const string Plant = "2930";

        /// <summary>
        /// The acc assignment
        /// </summary>
        public const string AccAssignment = "X";

        /// <summary>
        /// The resp costcenter
        /// </summary>
        public const string RespCostcenter = "9569P00004"; //Need to check with Thiru

        /// <summary>
        /// The controlling area
        /// </summary>
        public const string ControllingArea = "9500";

        /// <summary>
        /// The level one
        /// </summary>
        public const int LevelOne = 1;

        /// <summary>
        /// The level two
        /// </summary>
        public const int LevelTwo = 2;

        /// <summary>
        /// The parent level one
        /// </summary>
        public const string ParentLevelOne = "1";
    }
}