﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Reflection;
using SAP.Framework.Constants;
using SAP.Framework.Logging;
using SAP.WSDLService.SAPWSDLReference;
using SAP.WSDLService.SAPWSDLReferenceNetwork;
using SAP.Framework.Exception;

namespace SAP.WSDLService
{
    /// <summary>
    /// </summary>
    public class SapService
    {
        /// <summary>
        ///     The client
        /// </summary>
        private readonly Z_FI_RFC_WBS_UTIL _client;

        /// <summary>
        ///     The client request
        /// </summary>
        private Z_FI_RFC_WBS_UTIL1 _clientRequest;

        /// <summary>
        ///     The client response
        /// </summary>
        private Z_FI_RFC_WBS_UTILResponse _clientResponse;

        /// <summary>
        ///     The parent WBS element
        /// </summary>
        private string _parentWbsElement;

        /// <summary>
        ///     The network element
        /// </summary>
        private string _networkElement;


        /// <summary>
        ///     The netork client
        /// </summary>
        private readonly Z_FI_RFC_NW_UTIL _networkClient;

        /// <summary>
        ///     The network request
        /// </summary>
        private ZFiRfcNwUtil _networkRequest;

        /// <summary>
        ///     The network response
        /// </summary>
        private ZFiRfcNwUtilResponse _networkResponse;

        /// <summary>
        ///     The netork client tasks
        /// </summary>
        private readonly Z_FI_RFC_NW_UTIL _networkClientTasks;

        /// <summary>
        ///     The network request tasks
        /// </summary>
        private ZFiRfcNwUtil _networkRequestTasks;

        /// <summary>
        ///     The network response tasks
        /// </summary>
        private ZFiRfcNwUtilResponse _networkResponseTasks;

        /// <summary>
        ///     Initializes a new instance of the <see cref="SapService" /> class.
        /// </summary>
        public SapService()
        {
            try
            {
                _client = new Z_FI_RFC_WBS_UTIL();
                _clientRequest = new Z_FI_RFC_WBS_UTIL1();
                _clientResponse = new Z_FI_RFC_WBS_UTILResponse();

                _networkClient = new Z_FI_RFC_NW_UTIL();
                _networkRequest = new ZFiRfcNwUtil();
                _networkResponse = new ZFiRfcNwUtilResponse();

                _networkClientTasks = new Z_FI_RFC_NW_UTIL();
                _networkRequestTasks = new ZFiRfcNwUtil();
                _networkResponseTasks = new ZFiRfcNwUtilResponse();
            }
            catch (SapException exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        /// <summary>
        ///     Connects to sapwbsid.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        public void ConnectToSapwbs(string userName, string password)
        {
            //Validate the credentials
            _client.PreAuthenticate = true;
            _client.Credentials = new NetworkCredential(userName, password);
        }

        /// <summary>
        ///     Connects to sap network.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        public void ConnectToSapNetwork(string userName, string password)
        {
            //Validate the credentials
            _networkClient.PreAuthenticate = true;
            _networkClient.Credentials = new NetworkCredential(userName, password);
        }

        /// <summary>
        ///     Connects to sap network for activity creation.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        public void ConnectToSapNetworkForActivityCreation(string userName, string password)
        {
            //Validate the credentials
            _networkClientTasks.PreAuthenticate = true;
            _networkClientTasks.Credentials = new NetworkCredential(userName, password);
        }

        /// <summary>
        ///     Creates the project.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="billingInformation">The billing information.</param>
        /// <param name="projectDefinition">The project definition.</param>
        /// <param name="projectName">Name of the project.</param>
        /// <returns></returns>
        public object CreateProject(string userName, string password, long requestId, string billingInformation,
            string projectDefinition, string projectName)
        {
            try
            {
                //Connect to SAP for WBS ID Service 
                ConnectToSapwbs(userName, password);

                //Response from first web request
                _clientRequest = CreateRequest(billingInformation, projectDefinition, projectName);
                _clientResponse = _client.CallZ_FI_RFC_WBS_UTIL(_clientRequest);

                //Need to add WBSID's to the DB in a temporary table
                if (_clientResponse.P_MSGS[0].MESSAGE_TYPE != "E")
                {
                    using (var connection =
                        new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    using (var command = connection.CreateCommand())
                    {
                        foreach (var data in _clientResponse.P_WBS)
                        {
                            command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET ChargeCode='" + data.WBS +
                                                  "' Where ChargeCodeDescription ='" + data.DESC + "'";
                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                    }

                    _parentWbsElement = _clientResponse.P_WBS[0].WBS;

                    #region Commented Code

                    //connection.Close();

                    //// define the INSERT statement using **PARAMETERS**
                    //string insertStmt = "INSERT INTO dbo.tbl_SAP_WBSNetwork(RequestId, ChargeCode, ChargeCodeDescription, WorkCenter,ProjectDefinition,NetworkId,UpdatedOn) " +
                    //                    "VALUES(@RequestId, @ChargeCode,@ChargeCodeDescription,@WorkCenter,@ProjectDefinition,@NetworkId, @UpdatedOn)";

                    //// set up connection and command objects in ADO.NET
                    //using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    //using (SqlCommand cmd = new SqlCommand(insertStmt, conn))
                    //{
                    //    // define parameters - ReportID is the same for each execution, so set value here
                    //    cmd.Parameters.Add("@RequestId", SqlDbType.Int).Value = RequestId;
                    //    cmd.Parameters.Add("@ProjectDefinition", SqlDbType.NVarChar);
                    //    cmd.Parameters.Add("@ChargeCode", SqlDbType.NVarChar);
                    //    cmd.Parameters.Add("@ChargeCodeDescription", SqlDbType.NVarChar);
                    //    cmd.Parameters.Add("@WorkCenter", SqlDbType.NVarChar);
                    //    cmd.Parameters.Add("@NetworkId", SqlDbType.NVarChar);
                    //    cmd.Parameters.Add("@UpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                    //    conn.Open();

                    //    //// iterate over all Reqeuest Id's and execute the INSERT statement for each of them
                    //    foreach (ZPS_WBS_ELEMENT data in ClientResponse.P_WBS)
                    //    {
                    //        cmd.Parameters["@ProjectDefinition"].Value = data.PROJECT;
                    //        cmd.Parameters["@ChargeCode"].Value = data.WBS;
                    //        cmd.Parameters["@ChargeCodeDescription"].Value = data.DESC;
                    //        cmd.Parameters["@WorkCenter"].Value = "";
                    //        cmd.Parameters["@NetworkId"].Value = "";

                    //        cmd.ExecuteNonQuery();
                    //    }

                    //    ParentWBSElement = ClientResponse.P_WBS[0].WBS;

                    //    conn.Close();
                    //}

                    #endregion

                    //Need to call second service by passing the WBS ID along with Tasks for creating the network
                    //Connect to SAP for WBS ID Service 
                    ConnectToSapNetwork(userName, password);

                    //Create Network
                    _networkRequest = CreateNetworkRequest(_parentWbsElement, projectDefinition, projectName);
                    _networkResponse = _networkClient.ZFiRfcNwUtil(_networkRequest);

                    _networkElement = _networkResponse.PNetworks[0].Order;

                    //Update Network ID in DB based on Request ID

                    using (var connection =
                        new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET NetworkId='" + _networkElement +
                                              "' Where RequestId ='" + requestId + "'";
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }


                    ConnectToSapNetworkForActivityCreation(userName, password);
                    //Creater Network tasks
                    _networkRequestTasks = CreateNetworkRequestTasks(_networkElement);
                    _networkResponseTasks = _networkClientTasks.ZFiRfcNwUtil(_networkRequestTasks);

                    using (var connection =
                        new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
                    using (var command = connection.CreateCommand())
                    {
                        foreach (var data in _networkResponseTasks.PNwActivity)
                        {
                            command.CommandText = "UPDATE dbo.tbl_SAP_WBSNetwork SET ActivityNumber='" + data.Activity +
                                                  "' Where ChargeCodeDescription ='" + data.OperationShortText +
                                                  "' and WorkCenter ='" + data.WorkCenter + "' and ChargeCode ='" +
                                                  data.Wbs + "'";
                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                    }
                }

                return _clientResponse;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityID.High,
                    MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        /// <summary>
        ///     Creates the network request tasks.
        /// </summary>
        /// <param name="networkElement">The network element.</param>
        /// <returns></returns>
        private ZFiRfcNwUtil CreateNetworkRequestTasks(string networkElement)
        {
            var networkReq = new ZFiRfcNwUtil();

            var networkArray = new ZpsNetworks[1];
            var pMessageField = new MethMessage[1];
            var pNwActivityField = new ZpsNwActivity[1];
            var pNwStatusField = new ZpsNetworkStatus[1];


            #region FetchingNetworkListTasks

            SqlCommand cmd;
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString))
            {
                conn.Open();

                cmd = new SqlCommand("GetSAPWBSNetworkTasks", conn);
                cmd.Parameters.AddWithValue("NetworkID", networkElement);
                cmd.CommandType = CommandType.StoredProcedure;
            }

            var adp = new SqlDataAdapter(cmd);
            var dSet = new DataSet();

            cmd.ExecuteNonQuery();
            adp.Fill(dSet);


            pNwActivityField = new ZpsNwActivity[dSet.Tables[0].Rows.Count];

            //Looping through the dataset to insert Tasks into the array
            foreach (var table in dSet.Tables)
            {
                var i = 0;
                var j = 0;
                foreach (DataRow row in dSet.Tables[0].Rows)
                {
                    //Adding values to the wbarray
                    var nwActivity = new ZpsNwActivity
                    {
                        Order = row["NetworkId"].ToString(),
                        Activity = "",
                        ControlKey = "PS01",
                        WorkCenter = row["WorkCenter"].ToString(),
                        Plant = SapConstants.Plant,
                        OperationShortText = row["ChargeCodeDescription"].ToString(),
                        ActivityType = "EXP",
                        Wbs = row["ChargeCode"].ToString()
                    };


                    pNwActivityField[j] = nwActivity;

                    i++;
                    j++;
                }
            }

            networkReq.PNetworks = networkArray;
            networkReq.PMsgs = pMessageField;
            networkReq.PNwActivity = pNwActivityField;
            networkReq.PNwStatus = pNwStatusField;

            return networkReq;

            #endregion
        }

        //public static SAPWSDLReference.Z_FI_RFC_WBS_UTIL1 CreateRequest()
        //{
        //    SAPWSDLReference.Z_FI_RFC_WBS_UTIL1 clientReq = new SAPWSDLReference.Z_FI_RFC_WBS_UTIL1();

        //    BAPI_WBS_HIERARCHIE hierarchy = new BAPI_WBS_HIERARCHIE();
        //    BAPI_WBS_HIERARCHIE[] hierarchyArry = new BAPI_WBS_HIERARCHIE[1];

        //    BAPI_WBS_MNT_SYSTEM_STATUS pstatus = new BAPI_WBS_MNT_SYSTEM_STATUS();
        //    BAPI_WBS_MNT_SYSTEM_STATUS[] pstatusArry = new BAPI_WBS_MNT_SYSTEM_STATUS[1];

        //    BAPI_WBS_MNT_USER_STATUS ustatus = new BAPI_WBS_MNT_USER_STATUS();
        //    BAPI_WBS_MNT_USER_STATUS[] ustatusArry = new BAPI_WBS_MNT_USER_STATUS[1];

        //    BAPI_METH_MESSAGE mssg = new BAPI_METH_MESSAGE();
        //    BAPI_METH_MESSAGE[] mssgArry = new BAPI_METH_MESSAGE[1];

        //    ///Connect to DB and based on Project Name get the Unique Task Description from the Task Table

        //    ZPS_WBS_ELEMENT wbs = new ZPS_WBS_ELEMENT();

        //    wbs.LEVEL = 1;
        //    wbs.PARENT = "D9569-C0186-001";
        //    wbs.PROJECT = "D9569-C0186";
        //    wbs.DESC = "B/E Migration Project Test 180";
        //    wbs.COSTING_SHEET = "Z97700";
        //    wbs.PLANT = "2930";
        //    wbs.ACC_ASSIGNMENT = "X";
        //    wbs.RESP_COSTCENTER = "9569P00004";//need to get correct cost center and controlling area
        //    wbs.CONTRLLING_AREA = "9500";

        //    ZPS_WBS_ELEMENT[] wbsarray;
        //    wbsarray = new ZPS_WBS_ELEMENT[1];
        //    wbsarray[0] = wbs;
        //    clientReq.P_WBS = wbsarray;
        //    clientReq.P_HIERARCHY = hierarchyArry;
        //    clientReq.P_SYS_STATUS = pstatusArry;
        //    clientReq.P_USR_STATUS = ustatusArry;
        //    clientReq.P_MSGS = mssgArry;

        //    return clientReq;
        //}

        /// <summary>
        ///     Creates the request.
        /// </summary>
        /// <param name="billingInformation">The billing information.</param>
        /// <param name="projectDefinition">The project definition.</param>
        /// <param name="projectName">Name of the project.</param>
        /// <returns></returns>
        public static Z_FI_RFC_WBS_UTIL1 CreateRequest(string billingInformation, string projectDefinition,
            string projectName)
        {
            var clientReq = new Z_FI_RFC_WBS_UTIL1();

            var hierarchy = new BAPI_WBS_HIERARCHIE();
            var hierarchyArray = new BAPI_WBS_HIERARCHIE[1];

            var pstatusArray = new BAPI_WBS_MNT_SYSTEM_STATUS[1];

            var ustatusArry = new BAPI_WBS_MNT_USER_STATUS[1];

            var mssgArry = new BAPI_METH_MESSAGE[1];


            var wbs = new ZPS_WBS_ELEMENT
            {
                LEVEL = SapConstants.LevelOne,
                PARENT = billingInformation,
                PROJECT = projectDefinition,
                DESC = projectName,
                COSTING_SHEET = SapConstants.CostingSheet,
                PLANT = SapConstants.Plant,
                ACC_ASSIGNMENT = SapConstants.AccAssignment
            };

            //Parent Element Details
            //Static Data
            ////Needs to come from DB
            ////Needs to come from DB
            //Needs to come from DB
            //Static Data
            //Static Data
            //Static Data

            ///Fetch all the distinct Tasks based on the project name.

            #region FetchingTaskList

            ///Connect to DB and based on Project Name get the Unique Task Description from the Task Table
            ///
            var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ProjectWBS"].ConnectionString);
            connection.Open();

            var cmd = new SqlCommand("GetSAPDistinctProjectTasks", connection);
            cmd.Parameters.AddWithValue("ProjectName",
                "BAE-HAWK-OHR-D6861-E61YL-0449-101"); //Change this to ProjectName at later stage
            cmd.CommandType = CommandType.StoredProcedure;
            var adp = new SqlDataAdapter(cmd);
            var dSet = new DataSet();

            cmd.ExecuteNonQuery();
            adp.Fill(dSet);

            //string[] Gh = new string[dSet.Tables[0].Rows.Count];

            #endregion

            var wbsarray = new ZPS_WBS_ELEMENT[dSet.Tables[0].Rows.Count + 1];

            ///Assigning the parent element data to the wbarray
            wbsarray[0] = wbs;

            //Looping through the dataset to insert Tasks into the array
            foreach (var table in dSet.Tables)
            {
                var i = 0;
                var j = 1;
                foreach (DataRow row in dSet.Tables[0].Rows)
                {
                    //Adding values to the wbarray
                    var wbs1 = new ZPS_WBS_ELEMENT
                    {
                        LEVEL = SapConstants.LevelTwo,
                        PARENT = SapConstants.ParentLevelOne,
                        PROJECT = projectDefinition,
                        DESC = row["TaskDescription"].ToString(),
                        COSTING_SHEET = SapConstants.CostingSheet,
                        PLANT = SapConstants.Plant,
                        ACC_ASSIGNMENT = SapConstants.AccAssignment
                    };


                    wbsarray[j] = wbs1;

                    i++;
                    j++;
                }
            }

            clientReq.P_WBS = wbsarray;
            clientReq.P_HIERARCHY = hierarchyArray;
            clientReq.P_SYS_STATUS = pstatusArray;
            clientReq.P_USR_STATUS = ustatusArry;
            clientReq.P_MSGS = mssgArry;


            return clientReq;
        }

        /// <summary>
        ///     Creates the network request.
        /// </summary>
        /// <param name="wbsElement">The WBS element.</param>
        /// <param name="projectDefinition">The project definition.</param>
        /// <param name="projectName">Name of the project.</param>
        /// <returns></returns>
        public static ZFiRfcNwUtil CreateNetworkRequest(string wbsElement, string projectDefinition, string projectName)
        {
            var networkReq = new ZFiRfcNwUtil();

            var pMessageField = new MethMessage[1];


            var pNwActivityField = new ZpsNwActivity[1];
            var pNwStatusField = new ZpsNetworkStatus[1];

            ///Connect to DB and based on Project Name get the Unique Task Description from the Task Table

            var networkItem = new ZpsNetworks
            {
                Order = "",
                OrderType = "ZS02",
                ShortText = projectName,
                Plant = "2930",
                WbsElement = wbsElement,
                ProjectDefinition = projectDefinition,
                MrpController = "G99",
                SchedulingType = "2"
            };

            var networkArray = new ZpsNetworks[1];
            networkArray[0] = networkItem;
            networkReq.PNetworks = networkArray;
            networkReq.PMsgs = pMessageField;
            networkReq.PNwActivity = pNwActivityField;
            networkReq.PNwStatus = pNwStatusField;

            return networkReq;
        }
    }
}