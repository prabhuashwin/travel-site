﻿namespace SAP.DTO
{
    /// <summary>
    /// 
    /// </summary>
    public enum UserType
    {
        /// <summary>
        /// Customer Types
        /// </summary>
        Customer = 1,

        /// <summary>
        /// Administrator Types
        /// </summary>
        Administrator = 2,

        /// <summary>
        /// Administrator Types
        /// </summary>
        Anonymous = 3
    }
}