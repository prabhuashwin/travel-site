﻿namespace SAP.Business.DTO
{
    /// <summary />
    /// <seealso cref="SAP.Business.DTO.BaseDto" />
    public class ProjectCreationDto : BaseDto
    {
        /// <summary>
        /// Gets or sets the name of the user.
        /// </summary>
        /// <value>
        /// The name of the user.
        /// </value>
        public string UserName { get; set; }

        /// <summary>
        /// Gets or sets the password.
        /// </summary>
        /// <value>
        /// The password.
        /// </value>
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets the request identifier.
        /// </summary>
        /// <value>
        /// The request identifier.
        /// </value>
        public long RequestId { get; set; }

        /// <summary>
        /// Gets or sets the billing information.
        /// </summary>
        /// <value>
        /// The billing information.
        /// </value>
        public string BillingInformation { get; set; }

        /// <summary>
        /// Gets or sets the project definition.
        /// </summary>
        /// <value>
        /// The project definition.
        /// </value>
        public string ProjectDefinition { get; set; }

        /// <summary>
        /// Gets or sets the name of the project.
        /// </summary>
        /// <value>
        /// The name of the project.
        /// </value>
        public string ProjectName { get; set; }

    }
}
