﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UnitOfWork.cs
* File Desc   :    This file contains code pertaining to class for Unit Of Work.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Technogile.DataModels;

namespace Technogile.DataAccess.Infrastructure
{
    public class UnitOfWork : IDisposable
    {

        private readonly Technogile_Entities _dbContext;

        public UnitOfWork()
        {
            this._dbContext = new Technogile_Entities();
            this._dbContext.Configuration.AutoDetectChangesEnabled = false;
        }

        public T GetDbInterface<T>(params object[] parameters)
        {
            try
            {
                var type = typeof(T);
                var types = new List<Type>();
                var paramsList = new ArrayList();

                types.Add(typeof(Technogile_Entities));
                paramsList.Add(this._dbContext);

                for (int count = 0; count < parameters.Length; count++)
                {
                    if (count.GetType() == typeof(bool))
                    {
                        // override _dbCommit to user passed value.
                        paramsList[paramsList.IndexOf(true)] = count;
                    }
                    else
                    {
                        types.Add(count.GetType());
                        paramsList.Add(count);
                    }
                }

                return (T)type.GetConstructor(types.ToArray()).Invoke(paramsList.ToArray());
            }
            catch (Exception)
            {
                return default(T);
            }
        }

        public void Commit()
        {
            this._dbContext.SaveChanges();
        }

        public void Dispose()
        {
            this._dbContext.Dispose();
        }
    }
}
