﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UnitOfWork.cs
* File Desc   :    This file contains code pertaining to class for Unit Of Work.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Technogile.DataModels;

namespace Technogile.DataAccess.Infrastructure
{
    public class UnitOfWork : IDisposable
    {

        private Technogile_Entities dbContext;

        public UnitOfWork()
        {
            this.dbContext = new Technogile_Entities();
            this.dbContext.Configuration.AutoDetectChangesEnabled = false;
        }

        public T GetDbInterface<T>(params object[] parameters)
        {
            try
            {
                Type type = typeof(T);
                List<Type> types = new List<Type>();
                ArrayList paramsList = new ArrayList();

                types.Add(typeof(Technogile_Entities));
                paramsList.Add(this.dbContext);

                for (int count = 0; count < parameters.Length; count++)
                {
                    if (parameters[count].GetType() == typeof(bool))
                    {
                        // override _dbCommit to user passed value.
                        paramsList[paramsList.IndexOf(true)] = parameters[count];
                    }
                    else
                    {
                        types.Add(parameters[count].GetType());
                        paramsList.Add(parameters[count]);
                    }
                }

                return (T)type.GetConstructor(types.ToArray()).Invoke(paramsList.ToArray());
            }
            catch (Exception)
            {
                return default(T);
            }
        }

        public void Commit()
        {
            this.dbContext.SaveChanges();
        }

        public void Dispose()
        {
            this.dbContext.Dispose();
        }
    }
}
