﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UserDB.cs
* File Desc   :    This file contains code pertaining to class for UserDB.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Technogile.Common.DTO.User;
using Technogile.Common.Logging;
using Technogile.DataAccess.Interfaces;
using Technogile.DataModels;

namespace Technogile.DataAccess
{
    public class UserDB : IUserDB
    {
        private Technogile_Entities dbContext;
        public UserDB(Technogile_Entities dbContext)
        {
            this.dbContext = dbContext;
        }
        public tbl_User GetUser(string userName)
        {
            throw new NotImplementedException();
        }

        public bool RegisterUser(string Name, string EmailId)
        {
            try
            {
                tbl_User userInfoDB = new tbl_User();
                userInfoDB.vcName = Name;
                userInfoDB.vcEmail = EmailId;
                userInfoDB.dCreatedBy = Name;
                userInfoDB.dCreatedDate = DateTime.Now.ToUniversalTime();
                userInfoDB.dStatus = false;                

                this.dbContext.Entry(userInfoDB).State = System.Data.Entity.EntityState.Added;
                return this.dbContext.SaveChanges() > 0;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<UserDetailsCommon> GetManageUserDet()
        {
            try
            {             
                List<UserDetailsCommon> returnResult = new List<UserDetailsCommon>();
                var userlist = dbContext.tbl_User.ToList();

                if (userlist != null)
                {
                    foreach (var item in userlist)
                    {
                        UserDetailsCommon res = new UserDetailsCommon();
                        res.vcName = item.vcName;
                        res.vcEmail = item.vcEmail;
                        res.dStatus = item.dStatus;
                        res.iID = item.iID;
                        returnResult.Add(res);
                    }
                }
                
                return returnResult;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}
