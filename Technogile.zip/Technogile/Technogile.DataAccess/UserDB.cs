﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UserDB.cs
* File Desc   :    This file contains code pertaining to class for UserDB.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Technogile.Common.DTO.User;
using Technogile.Common.Logging;
using Technogile.DataAccess.Interfaces;
using Technogile.DataModels;

namespace Technogile.DataAccess
{
    public class UserDb : IUserDb
    {
        private readonly Technogile_Entities _dbContext;
        public UserDb(Technogile_Entities dbContext)
        {
            this._dbContext = dbContext;
        }
        public tbl_User GetUser(string userName)
        {
            throw new NotImplementedException();
        }

        public bool RegisterUser(string name, string emailId)
        {
            try
            {
                var userInfoDb = new tbl_User
                {
                    vcName = name,
                    vcEmail = emailId,
                    dCreatedBy = name,
                    dCreatedDate = DateTime.Now.ToUniversalTime(),
                    dStatus = false
                };


                this._dbContext.Entry(userInfoDb).State = System.Data.Entity.EntityState.Added;
                return this._dbContext.SaveChanges() > 0;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public List<UserDetailsCommon> GetManageUserDet()
        {
            try
            {
                var userdetailsList = _dbContext.tbl_User.ToList();

                return userdetailsList.Select(item => new UserDetailsCommon {vcName = item.vcName, vcEmail = item.vcEmail, dStatus = item.dStatus, iID = item.iID}).ToList();
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}
