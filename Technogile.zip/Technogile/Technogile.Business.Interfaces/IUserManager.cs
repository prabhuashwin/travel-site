﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    IUserManager.cs
* File Desc   :    This file contains code pertaining to class for IUserManager.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using Technogile.Common.DTO;

namespace Technogile.Business.Interfaces
{
    public interface IUserManager
    {
        OperationResult RegisterUser(string Name, string EmailId);
    }
}
