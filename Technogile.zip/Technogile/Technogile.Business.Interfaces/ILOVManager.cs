﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    ILOVManager.cs
* File Desc   :    This file contains code pertaining to class for ILOVManager.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using Technogile.Common.DTO;

namespace Technogile.Business.Interfaces
{
    public interface ILovManager
    {
        OperationResult GetUserDetails();
    }
}
