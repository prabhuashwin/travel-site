﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UserDetailsCommon.cs
* File Desc   :    This file contains code pertaining to class for UserDetailsCommon.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;

namespace Technogile.Common.DTO.User
{
    public class UserDetailsCommon
    {
        public int iID { get; set; }
        public string vcName { get; set; }
        public string vcEmail { get; set; }
        public Nullable<System.DateTime> dCreatedDate { get; set; }
        public string dCreatedBy { get; set; }
        public Nullable<bool> dStatus { get; set; }
    }
}
