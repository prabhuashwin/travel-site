﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    OperationResult.cs
* File Desc   :    This file contains code pertaining to DTO for Operation Result class.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 28-Oct-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

namespace Technogile.Common.DTO
{
    public class OperationResult
    {
        /// <summary>
        /// Gets or sets a value indicating whether the item is true or not.
        /// </summary>
        /// <value>
        ///   <c>true</c> if success; otherwise, <c>false</c>.
        /// </value>
        public bool Success { get; set; }

        /// <summary>
        /// Gets or sets the name of the MCode
        /// </summary>
        /// <value>
        /// The m code.
        /// </value>
        public MessageCode MCode { get; set; }

        /// <summary>
        /// Gets or sets the name of the Message, it return message string
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the name of the Data, it return data object value.
        /// </summary>
        /// <value>
        /// The data.
        /// </value>
        public object Data { get; set; }
    }
}
