﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    TechnogileConstants.cs
* File Desc   :    This file contains code pertaining to class for Constants.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

namespace Technogile.Common.Constants
{
    public class TechnogileConstants
    {
        public const string GenericGaurdMsg = "{0}: Please provide proper value.";

        public const string UserRegistration = "User registered successfully";
    }
}
