﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    TechnogileException.cs
* File Desc   :    This file contains code pertaining to class for TechnogileException.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using Technogile.Common.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 

namespace Technogile.Common.Exception
{
    public class TechnogileException : System.Exception
    {
        public TechnogileException()
        {
            Result = new OperationResult();
        }

        public TechnogileException(MessageCode code, string message)
            : base(message)
        {
            Result = new OperationResult { Success = false, MCode = code, Message = message };
        }

        public OperationResult Result { get; set; }
    }
}
