﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    IUserDB.cs
* File Desc   :    This file contains code pertaining to class for IUserDB.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Technogile.Common.DTO.User;
using Technogile.DataModels;

namespace Technogile.DataAccess.Interfaces
{
    public interface IUserDB
    {
        tbl_User GetUser(string userName);
        bool RegisterUser(string EmailId, string Name);
        List<UserDetailsCommon> GetManageUserDet();
    }
}
