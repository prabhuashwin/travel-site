﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    UserManager.cs
* File Desc   :    This file contains code pertaining to class for User Manager.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Reflection;
using Technogile.Business.Interfaces;
using Technogile.Common.Constants;
using Technogile.Common.DTO;
using Technogile.Common.Exception;
using Technogile.Common.Logging;
using Technogile.Common.Utilities;
using Technogile.DataAccess;
using Technogile.DataAccess.Infrastructure;

namespace Technogile.Business
{
    public class UserManager : IUserManager
    {
        public OperationResult RegisterUser(string Name, string EmailId)
        {
            try
            {
                bool isSuccess;
                Name.GuardNullEmpty("Name");
                EmailId.GuardNullEmpty("EmailId");

                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    isSuccess = userDB.RegisterUser(Name, EmailId);
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = TechnogileConstants.UserRegistration,
                    MCode = MessageCode.OperationSuccessful,
                    Data = isSuccess
                };
            }
            catch (TechnogileException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}
