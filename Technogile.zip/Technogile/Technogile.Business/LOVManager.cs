﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name   :    LOVManager.cs
* File Desc   :    This file contains code pertaining to class for LOV Manager.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 26-Nov-2020        Ashwin Prabhu            Initial Creation
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Technogile.Business.Interfaces;
using Technogile.Common.DTO;
using Technogile.Common.DTO.User;
using Technogile.Common.Exception;
using Technogile.Common.Logging;
using Technogile.DataAccess;
using Technogile.DataAccess.Infrastructure;

namespace Technogile.Business
{
    public class LOVManager : ILOVManager
    {
        public OperationResult GetUserDetails()
        {
            try
            {
                //bool isSuccess;

                List<UserDetailsCommon> usrdet = new List<UserDetailsCommon>();


                using (UnitOfWork uow = new UnitOfWork())
                {
                    var userDB = uow.GetDbInterface<UserDB>();
                    usrdet = userDB.GetManageUserDet();
                }

                return new OperationResult()
                {
                    Success = true,
                    Message = "Fetched User details successfully",
                    MCode = MessageCode.OperationSuccessful,
                    Data = usrdet
                };
                //return userlist;
            }
            catch (TechnogileException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                return exception.Result;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}
