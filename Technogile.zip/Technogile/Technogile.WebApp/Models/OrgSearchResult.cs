﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
*
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name          :             OrgSearchResult.cs
* File Desc          :             This file contains code pertaining to LDAP Search.
*                    
*
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 19-Nov-2020        Ashwin            Initial Creation
*********************************************************************************************/
namespace Technogile.WebApp.Models
{
    public class OrgSearchResult
    {        
        public string SearchId { get; set; }
        
        public string Name { get; set; }
        
        public string WindowsId { get; set; }
        
        public string Email { get; set; }
        
        public string Title { get; set; }
    }
}