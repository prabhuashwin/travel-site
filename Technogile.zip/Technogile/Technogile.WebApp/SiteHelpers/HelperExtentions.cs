﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Technogile.Common.DTO.User;

namespace Technogile.WebApp.SiteHelpers
{
    public static class HelperExtentions
    {
        public static UserDetailsCommon GetCurrentUser(this HttpSessionStateBase currentSession)
        {
            return (currentSession["CurrentUser"] as UserDetailsCommon);
        }
    }
}