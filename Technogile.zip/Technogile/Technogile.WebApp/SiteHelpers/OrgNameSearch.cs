﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
*
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name          :             OrgNameSearch.cs
* File Desc          :             This file contains code pertaining to LDAP Search.
*                    
*
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 19-Nov-2020        Ashwin                   Initial Creation
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Technogile.Common.ActiveDirectoryHelper;
using Technogile.WebApp.Models;

namespace Technogile.WebApp.SiteHelpers
{
    public class OrgNameSearch
    {        
        public List<OrgSearchResult> SearchAllUserDetails(string fn, string ln)
        {
            try
            {
                ActiveDirectoryHelper helper = new ActiveDirectoryHelper();

                if (string.IsNullOrEmpty(fn) && string.IsNullOrEmpty(ln))
                {
                    throw new Exception("No string to search");
                }

                List<OrgSearchResult> lst = new List<OrgSearchResult>();

                var usrDetails = helper.GetUserByName(fn, ln);

                if (usrDetails != null)
                {
                    foreach (var item in usrDetails)
                    {
                        OrgSearchResult res = new OrgSearchResult();

                        res.Name = item.FirstName + " " + item.LastName;
                        res.WindowsId = item.LoginNameWithDomain;
                        res.Title = item.LoginName;
                        res.Email = item.EmailAddress;

                        lst.Add(res);
                    }
                }

                return lst;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public OrgSearchResult SearchUserDetails(string name)
        {
            try
            {
                ActiveDirectoryHelper helper = new ActiveDirectoryHelper();

                if (string.IsNullOrEmpty(name))
                {
                    throw new Exception("No string to search");
                }

                OrgSearchResult lst = new OrgSearchResult();

                var usrDetails = helper.GetUserByLoginName(name);

                if (usrDetails != null)
                {

                    OrgSearchResult res = new OrgSearchResult();

                    lst.Name = usrDetails.FirstName + " " + usrDetails.LastName;
                    lst.WindowsId = usrDetails.LoginNameWithDomain;
                    lst.Title = usrDetails.LoginName;
                    lst.Email = usrDetails.EmailAddress;
                }

                return lst;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
                
        private string getDatainTags(string s, string starttag, string endtag)
        {
            var startTag = starttag;
            int startIndex = s.IndexOf(startTag) + startTag.Length;
            int endIndex = s.IndexOf(endtag, startIndex);
            return s.Substring(startIndex, endIndex - startIndex);
        }
    }
}