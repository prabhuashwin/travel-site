﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
*
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name          :             OrgNameSearch.cs
* File Desc          :             This file contains code pertaining to LDAP Search.
*                    
*
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 19-Nov-2020        Ashwin                   Initial Creation
*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using Technogile.Common.ActiveDirectoryHelper;
using Technogile.Common.Exception;
using Technogile.Common.Logging;
using Technogile.WebApp.Models;

namespace Technogile.WebApp.SiteHelpers
{
    public class OrgNameSearch
    {        
        public List<OrgSearchResult> SearchAllUserDetails(string fn, string ln)
        {
            try
            {
                var helper = new ActiveDirectoryHelper();

                if (string.IsNullOrEmpty(fn) && string.IsNullOrEmpty(ln))
                {
                    throw new Exception("No string to search");
                }

                var lst = new List<OrgSearchResult>();

                var usrDetails = helper.GetUserByName(fn, ln);

                if (usrDetails != null)
                {
                    lst.AddRange(usrDetails.Select(item => new OrgSearchResult {Name = item.FirstName + " " + item.LastName,
                                                                                                  WindowsId = item.LoginNameWithDomain, Title = item.LoginName,
                                                                                                  Email = item.EmailAddress}));
                }

                return lst;
            }
            catch (TechnogileException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }

        public OrgSearchResult SearchUserDetails(string name)
        {
            try
            {
                var helper = new ActiveDirectoryHelper();

                if (string.IsNullOrEmpty(name)) throw new Exception("No string to search");

                var lst = new OrgSearchResult();

                var usrDetails = helper.GetUserByLoginName(name);

                if (usrDetails == null) return lst;
                var res = new OrgSearchResult();
                lst.Name = usrDetails.FirstName + " " + usrDetails.LastName;
                lst.WindowsId = usrDetails.LoginNameWithDomain;
                lst.Title = usrDetails.LoginName;
                lst.Email = usrDetails.EmailAddress;

                return lst;
            }
            catch (TechnogileException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}