﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name          :             HomeController.cs
* File Desc          :             This file contains code pertaining to LDAP.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 03-Feb-2020        Ashwin/Govind           Prod Go Live

*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using Technogile.Business;
using Technogile.Common.DTO;
using Technogile.Common.DTO.User;
using Technogile.Common.Exception;
using Technogile.Common.Logging;
using Technogile.WebApp.SiteHelpers;

namespace Technogile.WebApp.Controllers
{
    public class HomeController : BaseController
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        /// <summary>
        /// Logins the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult Login(string id)
        {
            try
            {
                //ViewData["UserId"] = id;
                //var usr = UserService.Find(x => x.WindowsId.Equals(User.Identity.Name.ToUpper())).SingleOrDefault();

                //OperationResult operationResult = new OperationResult();

                //operationResult = new UserManager().RegisterUser(user.EmailId, user.Name);

                return View();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Searches the user.
        /// </summary>
        /// <param name="firstName">The first name.</param>
        /// <param name="lastName">The last name.</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SearchUser(string firstName, string lastName)
        {
            try
            {
                OrgNameSearch srch = new SiteHelpers.OrgNameSearch();
                return Json(srch.SearchAllUserDetails(firstName, lastName));
            }
            catch (Exception ex)
            {
                return Json(ex.ToString());
            }
        }

        /// <summary>
        /// Gets the windows user identifier.
        /// </summary>
        /// <returns></returns>
        //[AllowAnonymous]
        [HttpPost]
        public ActionResult GetWindowsUserId()
        {
            return Json(User.Identity.Name);
        }

        [HttpPost]
        public ActionResult Register(UserDetailsCommon model)
        {
            try
            {
                var s = @"utcain\";
                var r = s.Substring(s.IndexOf(@"\") + 1);
                OperationResult operationResult = new OperationResult();
                //operationResult = new UserManager().RegisterUser(usrModel.Name, usrModel.Email);
                OrgNameSearch srch = new SiteHelpers.OrgNameSearch();
                var result = srch.SearchUserDetails(model.vcName.Substring(s.IndexOf(@"\") + 1));
                operationResult = new UserManager().RegisterUser(result.Name, result.Email);

                if (operationResult.Success == true)
                {
                    TempData["RegSuccess"] = "Success";
                }
                return new EmptyResult();
            }
            catch (TechnogileException exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                //return exception.Result;
                throw;
            }
            catch (Exception exception)
            {
                LogUtilities.LogException(exception, LogPriorityId.High, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name);
                throw;
            }
        }
    }
}