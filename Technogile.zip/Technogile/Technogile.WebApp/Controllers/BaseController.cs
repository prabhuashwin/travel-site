﻿/*===========================================================================================
* Copyright (c) Collins Aerospace Services Pvt Ltd
* Unpublished - All Rights Reserved
*
* COLLINS AEROSPACE PROPRIETARY
* 
* This source code does not contain export controlled technical data/technology
=============================================================================================
* File Name          :             BaseController.cs
* File Desc          :             This file contains code pertaining to LDAP.
*                    
* 
*============================================================================================
* File History
*
* Date               Name                    Description
* ---------          ----------------------  -----------------------------------------------------
* 03-Feb-2020        Ashwin/Govind           Prod Go Live

*********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Security.Principal;
using Technogile.WebApp.SiteHelpers;
using Technogile.Common.DTO.User;

namespace Technogile.WebApp.Controllers
{
    public class BaseController : Controller
    {
        protected UserDetailsCommon currentUser;


        private MyIdentity myIdentity;


        private MyPrincipal myPrincipal;


        protected String UserId;



        public BaseController()
        {
            currentUser = Session != null ? Session.GetCurrentUser() : null;
        }

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <value>
        /// The user.
        /// </value>
        /// Added for impersonation
        new public IPrincipal User
        { // override User for impersonation
            get
            {
                if ((!string.IsNullOrEmpty(this.UserId)) || (Session["UserId"] != null))
                {
                    if (Session["UserId"] == null)
                        Session["UserId"] = this.UserId;
                    if (this.UserId == null)
                        this.UserId = Session["UserId"].ToString();

                    myIdentity = new MyIdentity(this.UserId, "", true, new Guid());
                    myPrincipal = new MyPrincipal(myIdentity);

                    return myPrincipal;
                }
                else
                {
                    return base.User;
                }
            }
        }
        public ActionResult ExceptionPage(Exception exception, int errorType)
        {
            return View(exception);
        }
    }
}